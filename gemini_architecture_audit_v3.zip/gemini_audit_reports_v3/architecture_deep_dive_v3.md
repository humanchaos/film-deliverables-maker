# Series B Architecture Audit: Deep Dive & Repair Plan (v3.0)
**Date:** December 22, 2025
**Assessment:** 🔴 CRITICAL (Deterministic Failure Found + Structural Risks)

## 1. Executive Summary
This audit validates the "High 7" hypothesis: **The system currently sends an empty configuration for every job**, ensuring that even if the backend runs, it skips all analysis modules. Beyond this immediate bug, the architecture requires a "Phase 2" refactor to safely handle large files by moving ingestion and upload logic strictly server-side.

## 2. Confirmed Root Causes (Ranked)

### 🔴 CRITICAL 1: Missing Analysis Config (The "Facepalm Bug")
- **Evidence:** `services/analysisCoordinator.ts` calls `BackendApiService.createJob(uri, type, duration)` but **drops** the `analysisConfig` object.
- **Result:** `BackendApiService` sends `{ analysisConfig: {} }` to the API.
- **Impact:** The backend worker checks `if (config.synopsis)` -> `undefined` -> `false`. **All modules are skipped.** Methods run purely as empty shells.
- **Fix:** Update `BackendApiService.createJob` to accept the config object and pass it.

### 🔴 CRITICAL 2: Large-File Path (The "Reliability Trap")
- **Mechanism:** The backend downloads the *master* video to Cloud Run's `/tmp` (Ephemeral Disk) before uploading to Gemini.
- **Risk:**
  - **Disk Limits:** Gen 2 instances have limited local SSD. Multi-GB files fill this, causing crash/restart.
  - **Timeouts:** Download + Upload > Request Timeout (even with 60m, I/O is slow).
  - **Memory:** Node streams help, but GC pressure on large buffers is high.
- **Verdict:** Materializing masters in Cloud Run is unsustainable.

### 🔴 CRITICAL 3: Browser-Coupled Uploads
- **Mechanism:** Client uploads to GCS using a client-side token, then polls.
- **Risk:**
  - **Fragile State:** If the tab closes or laptop sleeps during upload, the process dies.
  - **Auth Leaks:** Requires vending tokens to the client.
- **Verdict:** Shift to Server-Side Signed URLs (`status=uploading`).

## 3. Optimized Repair Plan (The 'Series B' Protocol)

### Phase 1: The "Hotfix" (Immediate Reliability)
*Goal: Make the current system work for standard files (<500MB).*
1.  **Refactor `BackendApiService`**: Add `analysisConfig` argument to `createJob`.
2.  **Refactor `AnalysisCoordinator`**: Pass the config from frontend state.
3.  **Deploy Config Fix**: This unblocks the "Nothing Happens" bug.

### Phase 2: Server-Side Ingestion (Deep Repair)
*Goal: Detach job lifecycle from browser tab durability.*
1.  **Signed URL Endpoint**: `POST /api/jobs/init` -> Returns `{ uploadUrl, jobId }`.
2.  **Client-Side Upload**: Browser pushes bytes to `uploadUrl` (GCS directly).
3.  **Webhook Trigger**: GCS `object.finalize` triggers Cloud Function -> Enqueues Worker.
    *   *Result:* Browser can close immediately after upload finishes.

### Phase 3: The "Proxy-First" Strategy (Large File Support)
*Goal: Stop downloading 4GB files to Cloud Run.*
1.  **Transcode Step**: Cloud Run Worker (or Transcoder API) generates a **Proxy (720p/360p)**.
2.  **Upload Proxy**: Only the small proxy file is sent to Gemini (faster, safer for /tmp).
3.  **Metadata Alignment**: Analysis timestamps map 1:1 to master.

### Phase 4: Atomic Reliability
*Goal: Zero lost jobs.*
1.  **Transactional Claims**: Worker uses Firestore Transaction to state "I am working on Job X".
2.  **Lease/Heartbeat**: Worker updates `lastHeartbeat` every minute. If dead > 5m, another worker steals it.
3.  **Result Storage**: Move Module JSONs to GCS Sub-paths (`gs://.../jobs/{id}/synopsis.json`), keeping Firestore light.

## 4. Next Actions
1.  **Approve Phase 1 Fix**: I will patch the code to pass `analysisConfig` immediately.
2.  **Schedule Phase 2/3**: I will create a detailed `implementation_plan_series_b.md` for the server-side architecture.
