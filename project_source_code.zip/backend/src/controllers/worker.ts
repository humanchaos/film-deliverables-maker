import { Request, Response } from 'express';
import { db } from '../config/firebase';
import { logger } from '../utils/logger';
import { Timestamp } from 'firebase-admin/firestore';
import { JobDocument } from '../types';
import { performAnalysis } from '../services/analysisCoordinator';

export const processJob = async (req: Request, res: Response) => {
    const { jobId } = req.body;

    if (!jobId) {
        logger.error('Worker received request without jobId');
        return res.status(400).send('Missing jobId');
    }

    logger.info(`Worker starting job: ${jobId}`, { jobId });

    try {
        const jobRef = db.collection('jobs').doc(jobId);
        const jobDoc = await jobRef.get();

        if (!jobDoc.exists) {
            logger.error(`Job ${jobId} not found`);
            return res.status(404).send('Job not found');
        }

        const job = jobDoc.data() as JobDocument;

        if (job.status === 'processing') {
            logger.warn('Job already processing, skipping duplicate task', { jobId });
            return res.status(200).send('Already processing');
        }

        if (job.status === 'completed') {
            logger.warn('Job already completed, skipping duplicate task', { jobId });
            return res.status(200).send('Already completed');
        }

        // 1. Set Status to Processing and add startedAt
        await jobRef.update({
            status: 'processing',
            startedAt: Timestamp.now(), // Track when processing actually began
            updatedAt: Timestamp.now(),
            'progress.currentStage': 'Processing started (Mock)'
        });

        // 2. Simulate Work (10 seconds)
        // NOTE: In Cloud Run, we must keep the request open OR simpler:
        // Ideally, for long jobs, we acknowledge the task and process async?
        // Cloud Tasks waits for the response. If we respond 200, it assumes success.
        // Cloud Run has a max timeout (e.g. 60m). We can hold the connection.
        // 2. Perform Real Analysis
        logger.info(`Starting Analysis Coordination for Job ${jobId}`);

        // This runs the full analysis pipeline defined in Phase 4
        // Note: performAnalysis handles its own progress updates
        const results = await performAnalysis(jobId, job);

        // 3. Complete Job
        await jobRef.update({
            status: 'completed',
            'progress.overall': 100,
            'progress.currentStage': 'Analysis Complete',
            updatedAt: Timestamp.now(),
            results: results // Store the aggregated results
        });

        logger.info(`Worker completed job: ${jobId}`);
        res.status(200).send('Job processed successfully');

    } catch (error) {
        logger.error(`Worker failed processing job: ${jobId}`, error);

        // Mark as failed in DB so frontend knows
        await db.collection('jobs').doc(jobId).update({
            status: 'failed',
            error: {
                code: 'WORKER_ERROR',
                message: error instanceof Error ? error.message : 'Unknown worker error'
            },
            updatedAt: Timestamp.now()
        }).catch(e => logger.error('Failed to update job status to failed', e));

        // Determine retry logic
        // Returning 500 tells Cloud Tasks to RETRY.
        // Returning 200 tells Cloud Tasks "Done/Don't Retry".
        // For now, let's not retry to avoid loops in testing.
        res.status(200).send('Job failed (terminal)');
    }
};
