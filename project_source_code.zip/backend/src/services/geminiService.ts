import { GoogleGenerativeAI, SchemaType as Type } from "@google/generative-ai";
import { config } from '../config/env';
import {
    AnalysisResult,
    Synopsis,
    SynopsisConfig,
    GraphicsAnalysisResult,
    SpeciesSighting,
    TranscriptionResult,
    TranscriptionSegment,
    Bio,
    ERROR_IDS
} from '../types'; // Check if this path is correct relative to service
import { retryWithBackoff } from '../utils/retryUtils';

// Initialize the SDK
// Ensure API Key is available
if (!config.geminiApiKey) {
    console.warn("GEMINI_API_KEY is not set. Gemini Service will fail.");
}
const genAI = new GoogleGenerativeAI(config.geminiApiKey || '');

// Utility for JSON parsing
function repairJson(jsonString: string): string {
    let fixed = jsonString.trim();
    fixed = fixed.replace(/^```(json)?|```$/g, '');
    const jsonMatch = fixed.match(/(\{[\s\S]*\}|\[[\s\S]*\])/);
    if (jsonMatch) fixed = jsonMatch[0];
    fixed = fixed.replace(/,(\s*[}\]])/g, '$1');
    fixed = fixed.replace(/}(\s*){/g, '},$1{');
    fixed = fixed.replace(/](\s*)\[/g, '],$1[');
    return fixed;
}

function safeJsonParse<T>(jsonString: string): T {
    try {
        const cleanString = repairJson(jsonString);
        if (!cleanString) throw new Error("Empty JSON response");
        return JSON.parse(cleanString);
    } catch (e) {
        console.warn("Initial JSON parse failed, attempting aggressive repair...", e);
        try {
            let aggressiveFix = jsonString.replace(/,(\s*)/g, ',$1');
            aggressiveFix = aggressiveFix.replace(/([}\]])[\s\S]*$/, '$1');
            return JSON.parse(repairJson(aggressiveFix));
        } catch (e2) {
            console.error("Failed to parse JSON response:", jsonString, e2);
            throw new Error("Invalid API Response");
        }
    }
}

function formatDuration(seconds: number): string {
    if (isNaN(seconds) || seconds < 0) return "00:00:00";
    const totalSeconds = Math.floor(seconds);
    const h = Math.floor(totalSeconds / 3600), m = Math.floor((totalSeconds % 3600) / 60), s = totalSeconds % 60;
    return [h, m, s].map(v => String(v).padStart(2, '0')).join(':');
}

// ═══════════════════════════════════════════════════════════════════════════════
// SYNOPSIS GENERATION
// ═══════════════════════════════════════════════════════════════════════════════

export const analyzeVideoContent = async (
    fileUri: string,
    mimeType: string,
    cacheName?: string
): Promise<AnalysisResult> => {
    try {
        console.log(`Analyzing video content for URI: ${fileUri}`);

        const prompt = `
      You are an expert video analysis AI. Analyze the provided video file.
      Your task is to synthesize all information into a final, cohesive analysis in JSON format.
      - Transcribe spoken words if present.
      - Summarize the entire video in one sentence.
      - Create a single, chronological list of the most important key events.
      - Infer any potential dialogue or important sounds based on visual cues if audio is unclear.
      
      **CRITICAL:** Base all descriptions strictly on the video content. Do not invent details not present in the video.
    `;

        const modelConfig: any = {
            model: 'gemini-2.5-pro',
            generationConfig: {
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        summary: { type: Type.STRING, description: "A brief, one-sentence summary of the video's content." },
                        events: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    timestamp: { type: Type.STRING, description: "Approximate time or sequence of the event (e.g., '00:05', 'Beginning', 'Middle')." },
                                    description: { type: Type.STRING, description: "A detailed description of what is happening in the event." },
                                },
                                required: ['timestamp', 'description'],
                            },
                        },
                        inferred_dialogue: { type: Type.STRING, description: "An inferred transcription of what might be said, based on visual cues." },
                        transcription: { type: Type.STRING, description: "A transcription of the spoken content from the audio track. If no audio was provided, state that." },
                    },
                    required: ['summary', 'events', 'inferred_dialogue', 'transcription'],
                },
            }
        };

        if (cacheName) modelConfig.cachedContent = cacheName;

        const model = genAI.getGenerativeModel(modelConfig);
        const contents = cacheName
            ? [{ role: 'user', parts: [{ text: prompt }] }]
            : [{ role: 'user', parts: [{ fileData: { fileUri, mimeType } }, { text: prompt }] }];

        const result = await retryWithBackoff(async () => {
            return await model.generateContent({ contents });
        }, 3, 2000);

        const rawText = result.response.text() || '';
        return safeJsonParse<AnalysisResult>(rawText);

    } catch (error) {
        console.error("Error analyzing video with Gemini:", error);
        throw new Error("Analysis Failed");
    }
};

// ═══════════════════════════════════════════════════════════════════════════════
// DETAILED SYNOPSIS (FROM ANALYSIS)
// ═══════════════════════════════════════════════════════════════════════════════

export const generateSynopsisFromAnalysis = async (
    analysis: AnalysisResult,
    writer: string,
    director: string,
    language: string,
    keywords: string,
    synopsisConfig: SynopsisConfig
): Promise<Synopsis> => {
    try {
        const prompt = `
          You are a master screenwriter and film marketing expert. Your task is to transform raw video analysis data into a compelling, professional film synopsis and marketing profile. Your writing should be evocative and ready for a pitch deck.

          **Content to Generate:**
          1.  **Title:** A creative, fitting title for the video.
          2.  **One Line (Logline):** A single, powerful sentence capturing the core story.
          3.  **Paragraph (Summary):** An engaging paragraph setting the scene and narrative.
          4.  **Full Synopsis:** A detailed, multi-paragraph synopsis with a clear beginning, middle, and end.
          5.  **Key Themes:** A concise summary of the central themes and ideas.
          6.  **Target Audience:** A description of the ideal viewer for this content.

          **Your Constraints:**
          - **Language:** Generate all content in: ${language}.
          - **Title:** Maximum ${synopsisConfig.titleMaxChars} characters.
          - **One Line (Logline):** Approximately ${synopsisConfig.loglineMaxWords} words.
          - **Paragraph (Summary):** Approximately ${synopsisConfig.summaryMaxWords} words.
          - **Key Themes:** Approximately ${synopsisConfig.keyThemesMaxWords} words.
          - **Target Audience:** Approximately ${synopsisConfig.targetAudienceMaxWords} words.
          - **Full Synopsis:** Comprehensive and well-structured.

          ${keywords ? `**Guiding Keywords:** ${keywords}` : ''}

          **Video Analysis Data:**
          - Transcription: "${analysis.transcription}"
          - Summary: "${analysis.summary}"
          - Key Events: ${JSON.stringify(analysis.events.map(e => e.description))}
          - Inferred Dialogue: "${analysis.inferred_dialogue}"

          Your output must be a single JSON object with keys: "title", "oneLine", "paragraph", "fullSynopsis", "keyThemes", "targetAudience".
      `;

        const response = await retryWithBackoff(async () => {
            const model = genAI.getGenerativeModel({
                model: 'gemini-2.5-pro',
                generationConfig: {
                    responseMimeType: 'application/json',
                    responseSchema: {
                        type: Type.OBJECT,
                        properties: {
                            title: { type: Type.STRING },
                            oneLine: { type: Type.STRING },
                            paragraph: { type: Type.STRING },
                            fullSynopsis: { type: Type.STRING },
                            keyThemes: { type: Type.STRING },
                            targetAudience: { type: Type.STRING }
                        },
                        required: ['title', 'oneLine', 'paragraph', 'fullSynopsis', 'keyThemes', 'targetAudience']
                    }
                }
            });
            return await model.generateContent({
                contents: [{ role: 'user', parts: [{ text: prompt }] }]
            });
        }, 3, 2000);

        const aiGeneratedContent = safeJsonParse<any>(response.response.text() || '');
        return {
            ...aiGeneratedContent,
            writtenBy: writer,
            directedBy: director,
        };

    } catch (error) {
        console.error("Error generating synopsis:", error);
        throw new Error("Synopsis Generation Failed");
    }
};

// ═══════════════════════════════════════════════════════════════════════════════
// BIO GENERATION
// ═══════════════════════════════════════════════════════════════════════════════

export const extractTalentFromVideo = async (fileUri: string, mimeType: string, cacheName?: string): Promise<string[]> => {
    const prompt = `Analyze the video. Identify any people introduced with text on the screen, commonly known as a 'lower third'. Extract their full names. Return the result as a valid JSON object with a single key 'names' which is an array of strings. For example: {"names": ["Lisa Hywood", "Ellen Connelly"]}. If no names are found, return an empty array. Do not include titles or roles, only full names.`;

    try {
        const response = await retryWithBackoff(async () => {
            const modelConfig: any = {
                model: 'gemini-2.5-flash',
                generationConfig: { temperature: 0.1, responseMimeType: 'application/json' },
            };
            if (cacheName) modelConfig.cachedContent = cacheName;

            const model = genAI.getGenerativeModel(modelConfig);
            const parts = cacheName
                ? [{ text: prompt }]
                : [{ fileData: { fileUri, mimeType } }, { text: prompt }];

            return await model.generateContent({ contents: [{ role: 'user', parts }] });
        }, 3, 1000);

        const parsed = safeJsonParse<{ names: any }>(response.response.text() || '');
        if (parsed.names && Array.isArray(parsed.names)) {
            return [...new Set<string>(parsed.names.filter((name: any): name is string => typeof name === 'string' && name.trim() !== ''))];
        }
        return [];
    } catch (e) {
        console.error('Error analyzing video for talent:', e);
        throw new Error('Talent Extraction Failed');
    }
};

export const generateBio = async (talentName: string, context: string, language: string): Promise<Bio> => {
    const prompt = `You are a professional biographer. Research and write a professional biography for the person named "${talentName}". Their specific context or role is: "${context}". Use this context to find the correct person. The biography should be engaging, accurate, and suitable for promotional materials. The entire response must be written in ${language}. 
  
  **CRITICAL OUTPUT RULE:**
  - You must return a SINGLE, VALID JSON object.
  - Do NOT output any markdown.
  
  **JSON Structure:**
  {
    "fullName": "Name",
    "title": "Role/Title",
    "biography": "The biography text...",
    "found": boolean
  }
  
  **If you are NOT 100% sure:**
  - Return JSON with "found": false, or provide your **best educated guess** based on visual appearance and context.
  - If guessing, explicitly state in the biography: "Likely [Name], pending verification."
  
  **If you cannot find sufficient information:**
  Return exactly: {"fullName": "${talentName}", "title": "Information Not Found", "biography": "Could not find sufficient information to generate a biography.", "found": false}`;

    try {
        const response = await retryWithBackoff(async () => {
            const model = genAI.getGenerativeModel({
                model: 'gemini-2.5-pro',
                tools: [{ googleSearch: {} } as any],
                generationConfig: { temperature: 0.2 },
            });
            return await model.generateContent({
                contents: [{ role: 'user', parts: [{ text: prompt }] }]
            });
        }, 3, 2000);

        const parsed = safeJsonParse<any>(response.response.text() || '');

        // Extract Grounding Sources
        // Extract Grounding Sources
        const sources: string[] = [];
        const candidate = response.response.candidates?.[0] as any;
        // Handle potential SDK typo (groundingChuncks)
        const metadata = candidate?.groundingMetadata;
        if (metadata) {
            const chunks = metadata.groundingChunks || metadata.groundingChuncks;
            if (chunks && Array.isArray(chunks)) {
                chunks.forEach((chunk: any) => {
                    if (chunk.web?.uri) sources.push(chunk.web.uri);
                });
            }
        }

        return { ...parsed, sources: [...new Set(sources)] } as Bio;
    } catch (e) {
        console.error(`Error generating bio for ${talentName}:`, e);
        throw new Error(`Bio Generation Failed for "${talentName}"`);
    }
};

// ═══════════════════════════════════════════════════════════════════════════════
// GRAPHICS & LOWER THIRDS ANALYSIS
// ═══════════════════════════════════════════════════════════════════════════════

export async function analyzeGraphicsAndLowerThirds(
    fileUri: string, mimeType: string, duration: number, filmTitle: string, cacheName?: string
): Promise<GraphicsAnalysisResult> {
    const prompt = `You are a post-production assistant with excellent OCR skills. Analyze the provided video file. Your task is to identify and transcribe all on-screen graphics (e.g., title cards, location indicators) and lower thirds (text identifying a person or place, usually at the bottom of the screen). 
  
  **CRITICAL RULES:**
  - Be extremely accurate. 
  - Output ONLY text that is clearly visible on screen. 
  - Do NOT correct spelling errors in the source text. Transcribe exactly what you see.
  - Do NOT invent text that is not there.
  
  Output must be a single, valid JSON object strictly adhering to the schema.`;

    try {
        const result = await retryWithBackoff(async () => {
            const modelConfig: any = {
                model: 'gemini-2.5-flash',
                generationConfig: {
                    responseMimeType: 'application/json',
                    temperature: 0.2,
                    responseSchema: {
                        type: Type.OBJECT,
                        properties: {
                            programTitle: { type: Type.STRING },
                            runtime: { type: Type.STRING },
                            graphics: {
                                type: Type.ARRAY,
                                items: {
                                    type: Type.OBJECT, properties: {
                                        description: { type: Type.STRING },
                                        timecodeIn: { type: Type.STRING },
                                        timecodeOut: { type: Type.STRING },
                                        cleanTimecodeIn: { type: Type.STRING },
                                        cleanTimecodeOut: { type: Type.STRING },
                                    },
                                    required: ["description", "timecodeIn", "timecodeOut"],
                                },
                            },
                            lowerThirds: {
                                type: Type.ARRAY,
                                items: {
                                    type: Type.OBJECT, properties: {
                                        text: { type: Type.STRING },
                                        timecodeIn: { type: Type.STRING },
                                        timecodeOut: { type: Type.STRING }
                                    },
                                    required: ["text", "timecodeIn", "timecodeOut"],
                                },
                            },
                        },
                        required: ["programTitle", "runtime", "graphics", "lowerThirds"],
                    },
                }
            };
            if (cacheName) modelConfig.cachedContent = cacheName;

            const model = genAI.getGenerativeModel(modelConfig);
            const parts = cacheName
                ? [{ text: prompt }]
                : [{ fileData: { fileUri, mimeType } }, { text: prompt }];

            return await model.generateContent({ contents: [{ role: 'user', parts }] });
        }, 3, 2000);

        const rawText = result.response.text() || '';
        const parsedResult = safeJsonParse<GraphicsAnalysisResult>(rawText);
        parsedResult.programTitle = filmTitle;
        parsedResult.runtime = formatDuration(duration);
        return parsedResult;
    } catch (e) {
        console.error("Error analyzing graphics:", e);
        throw new Error("Graphics Analysis Failed");
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// FAUNA FINDER
// ═══════════════════════════════════════════════════════════════════════════════

export async function analyzeVideoForSpecies(
    fileUri: string,
    mimeType: string,
    primaryLanguage: string,
    secondaryLanguage: string,
    videoDuration: number = 0,
    cacheName?: string
): Promise<Omit<SpeciesSighting, 'id' | 'thumbnail'>[]> {

    const SEGMENT_LENGTH = 300;
    const segments: { start: number; end: number }[] = [];

    if (videoDuration > SEGMENT_LENGTH) {
        for (let t = 0; t < videoDuration; t += SEGMENT_LENGTH) {
            segments.push({ start: t, end: Math.min(t + SEGMENT_LENGTH, videoDuration) });
        }
    } else {
        segments.push({ start: 0, end: videoDuration });
    }

    const allSightings: Omit<SpeciesSighting, 'id' | 'thumbnail'>[] = [];
    const fmtTime = (s: number) => {
        if (s === 0 && segments.length === 1 && segments[0].end === 0) return "";
        const m = Math.floor(s / 60);
        const sec = Math.floor(s % 60);
        return `${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
    };

    for (let i = 0; i < segments.length; i++) {
        const { start, end } = segments[i];
        const isSegmented = segments.length > 1;

        const timeInstruction = isSegmented
            ? `**CRITICAL FOCUS:** Analyze ONLY the video segment from ${fmtTime(start)} to ${fmtTime(end)}. Ignore anything outside this timeframe.`
            : `Analyze the entire video.`;

        const prompt = `Analyze this video. Your task is to identify **every single animal sighting**. 
    ${timeInstruction}
    For each sighting, provide: commonName in ${primaryLanguage}, latinName, germanName (${secondaryLanguage}), timecode, category, confidence, behavior, iucnStatus.
    
    The final output must be a valid JSON object with a single key "sightings" containing the list of sightings.`;

        try {
            const response = await retryWithBackoff(async () => {
                const modelConfig: any = {
                    model: 'gemini-2.5-flash',
                    generationConfig: {
                        responseMimeType: "application/json",
                        responseSchema: {
                            type: Type.OBJECT,
                            properties: {
                                sightings: {
                                    type: Type.ARRAY,
                                    items: {
                                        type: Type.OBJECT,
                                        properties: {
                                            commonName: { type: Type.STRING },
                                            latinName: { type: Type.STRING },
                                            germanName: { type: Type.STRING },
                                            timecode: { type: Type.STRING },
                                            category: { type: Type.STRING },
                                            confidence: { type: Type.NUMBER },
                                            behavior: { type: Type.STRING },
                                            iucnStatus: { type: Type.STRING },
                                            encounterGroup: { type: Type.STRING },
                                        },
                                        required: ["commonName", "latinName", "timecode", "category", "confidence"],
                                    },
                                },
                            },
                            required: ["sightings"],
                        },
                    },
                };
                if (cacheName) modelConfig.cachedContent = cacheName;

                const model = genAI.getGenerativeModel(modelConfig);
                const parts = cacheName
                    ? [{ text: prompt }]
                    : [{ fileData: { fileUri, mimeType } }, { text: prompt }];

                return await model.generateContent({ contents: [{ role: 'user', parts }] });
            }, 3, 2000);

            const parsed = safeJsonParse<any>(response.response.text() || '');
            let segmentSightings: any[] = [];
            if (Array.isArray(parsed)) segmentSightings = parsed;
            else if (parsed?.sightings) segmentSightings = parsed.sightings;

            if (segmentSightings.length > 0) allSightings.push(...segmentSightings);

        } catch (e) {
            console.error(`Error analyzing fauna segment ${i}:`, e);
        }
    }
    return allSightings;
}

// ═══════════════════════════════════════════════════════════════════════════════
// TRANSCRIPTION
// ═══════════════════════════════════════════════════════════════════════════════

export async function transcribeMedia(
    fileUri: string, mimeType: string, cacheName?: string
): Promise<TranscriptionResult> {
    const prompt = `You are an expert audio transcription AI. Transcribe the provided media, identifying different speakers as SPEAKER_00, SPEAKER_01, etc. Provide the output as a time-coded transcript in a JSON object adhering to the schema.`;

    try {
        const response = await retryWithBackoff(async () => {
            const modelConfig: any = {
                model: 'gemini-2.5-flash',
                generationConfig: {
                    responseMimeType: 'application/json',
                    responseSchema: {
                        type: Type.OBJECT,
                        properties: {
                            segments: {
                                type: Type.ARRAY,
                                items: {
                                    type: Type.OBJECT,
                                    properties: {
                                        startTime: { type: Type.STRING },
                                        endTime: { type: Type.STRING },
                                        speaker: { type: Type.STRING },
                                        transcript: { type: Type.STRING },
                                    },
                                    required: ["startTime", "endTime", "speaker", "transcript"],
                                },
                            },
                        },
                        required: ["segments"],
                    },
                },
            };
            if (cacheName) modelConfig.cachedContent = cacheName;

            const model = genAI.getGenerativeModel(modelConfig);
            const parts = cacheName
                ? [{ text: prompt }]
                : [{ fileData: { fileUri, mimeType } }, { text: prompt }];

            return await model.generateContent({ contents: [{ role: 'user', parts }] });
        }, 3, 2000);

        const parsed = safeJsonParse<{ segments: TranscriptionSegment[] }>(response.response.text() || '');

        // Build Speaker Map
        const speakerMap: Record<string, string> = {};
        parsed.segments.forEach(seg => {
            if (!speakerMap[seg.speaker]) {
                speakerMap[seg.speaker] = seg.speaker;
            }
        });

        const fullText = parsed.segments.map(s => s.transcript).join(" ");
        return { segments: parsed.segments, speakerMap, text: fullText };

    } catch (e) {
        console.error("Error transcribing media:", e);
        throw new Error("Transcription Failed");
    }
}
