import dotenv from 'dotenv';

dotenv.config();

export const config = {
    port: process.env.PORT || 8080,
    projectId: process.env.GOOGLE_CLOUD_PROJECT_ID,
    location: process.env.GOOGLE_CLOUD_LOCATION || 'us-central1',
    queueName: process.env.CLOUD_TASKS_QUEUE || 'video-analysis-queue',
    workerUrl: process.env.WORKER_URL, // e.g., https://my-service-url/workers/process
    serviceAccountEmail: process.env.SERVICE_ACCOUNT_EMAIL,
    geminiApiKey: process.env.GEMINI_API_KEY
};

if (!config.projectId) {
    console.warn('Warning: GOOGLE_CLOUD_PROJECT_ID is not set.');
}
