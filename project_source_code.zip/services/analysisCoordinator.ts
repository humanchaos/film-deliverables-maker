import {
    annotateVideo,
    VideoAnnotationResults,
    Feature
} from './googleVideoIntelligenceService';
import { uploadFileToGCS } from './gcsUploadService';
import { enrichShotList, generateShotList, transcribeMedia, analyzeVideoContent, generateSynopsisFromAnalysis, generateSynopsisFromText, generateBio, extractTalentFromVideo, analyzeGraphicsAndLowerThirds, analyzeVideoForSpecies, createContextCache } from './geminiService';
import { smartUploadToGemini } from './uploadService';
import { AnalysisMode, Shot, UploadProgress, SynopsisConfig, BioConfig, GraphicsConfig, FaunaConfig, ShotListConfig, VideoMetadata, DEFAULT_SHOTLIST_CONFIG, DEFAULT_SYNOPSIS_CONFIG } from '../types';
import { secondsToTimecode, secondsToDropFrameTimecode, detectTimecodeFormat } from '../utils/tableUtils';
import { BackendApiService } from './backendApiService';

// Types for the coordinated result
export interface CoordinatedAnalysisResult {
    shots?: Omit<Shot, 'nr' | 'thumbnail'>[];
    transcription?: any; // To be defined
    metadata?: any;
    rawApiResult?: VideoAnnotationResults;
}

interface AnalysisOptions {
    file: File;
    fileUri?: string;
    mode: AnalysisMode;
    apiKey: string;
    accessToken?: string; // OAuth Token
    projectId?: string; // Quota Project ID
    bucketName?: string;
    useProMode?: boolean; // Toggle for Zero Hallucination (true) or Standard (false)
    onProgress: (message: string, percentage: number) => void;
    onMultiProgress?: (mode: AnalysisMode, message: string, percentage: number) => void; // New: For parallel job updates
    signal?: AbortSignal;
    synopsisConfig?: SynopsisConfig;
    bioConfig?: BioConfig;
    graphicsConfig?: GraphicsConfig;
    faunaConfig?: FaunaConfig;
    shotListConfig?: ShotListConfig;
    videoMetadata?: VideoMetadata | null;
}

/**
 * Orchestrates the analysis workflow based on the selected mode.
 * - For Deterministic tasks (Shots, Transcription), uses Video Intelligence API (requires GCS).
 * - For Creative tasks (Synopsis, Bio, Fauna), uses Gemini API (can use File API).
 */
export async function performAnalysis(options: AnalysisOptions): Promise<any> {
    const { file, fileUri, mode, apiKey, accessToken, projectId, bucketName, useProMode, onProgress, onMultiProgress, signal, videoMetadata } = options;

    // ═══════════════════════════════════════════════════════════════════════════════
    // STRATEGY: CLOUD RUN BACKEND (Full Analysis)
    // ═══════════════════════════════════════════════════════════════════════════════
    // We prefer the backend if:
    // 1. Mode is 'full_analysis' (Backend is optimized for this)
    // 2. We have GCS Access (Backend requires GCS URI)
    const canUseBackend = mode === 'full_analysis' && accessToken && bucketName;

    if (canUseBackend) {
        try {
            console.log("[Coordinator] Attempting Cloud Run Backend...");
            let gcsUri = fileUri;

            // 1. Ensure File is in GCS
            if (!gcsUri || !gcsUri.startsWith('gs://')) {
                onProgress('Uploading to Cloud Storage (Zero Hallucination)...', 0);
                gcsUri = await uploadFileToGCS({
                    file,
                    bucketName: bucketName!,
                    apiKey,
                    accessToken: accessToken!,
                    onProgress: (p: UploadProgress) => {
                        onProgress(p.message, p.percentage * 0.2); // First 20% is upload
                    },
                    signal
                });
            } else {
                onProgress('File already in Cloud Storage...', 20);
            }

            // 2. Submit Job
            onProgress('Dispatching to Backend Workers...', 25);
            const jobId = await BackendApiService.createJob(gcsUri, file.type, videoMetadata?.duration);
            console.log(`[Coordinator] Job Created: ${jobId}`);

            // 3. Poll for Completion using backend service
            // We manually poll here to map specific module progress to the UI
            while (true) {
                if (signal?.aborted) throw new Error('Operation Cancelled');

                const job = await BackendApiService.getJob(jobId);

                // Map Module Progress to UI
                if (job.progress?.modules) {
                    const m = job.progress.modules;
                    if (onMultiProgress) {
                        if (m.fauna) onMultiProgress('fauna', m.fauna.status === 'completed' ? 'Done' : m.fauna.status, m.fauna.progress);
                        // transcribe maps to 'transcription' in backend but 'transcribe' in frontend mode keys?
                        // Frontend AllJobs key is 'transcribe'. Backend module is 'transcription'.
                        if (m.transcription) onMultiProgress('transcribe', m.transcription.status === 'completed' ? 'Done' : 'Processing', m.transcription.progress);
                        if (m.shotList) onMultiProgress('shotlist', m.shotList.status === 'completed' ? 'Done' : 'Processing', m.shotList.progress);
                        if (m.synopsis) onMultiProgress('synopsis', m.synopsis.status === 'completed' ? 'Done' : 'Processing', m.synopsis.progress);
                        if (m.graphics) onMultiProgress('graphics', m.graphics.status === 'completed' ? 'Done' : 'Processing', m.graphics.progress);
                        // cast maps to 'bio'
                        if (m.cast) onMultiProgress('bio', m.cast.status === 'completed' ? 'Done' : 'Processing', m.cast.progress);
                    }
                }

                // Update Overall Progress
                // Map 0-100 backend progress to 25-100 frontend progress
                const overall = 25 + ((job.progress?.overall || 0) * 0.75);
                onProgress(job.progress?.currentStage || 'Processing on Cloud Run...', overall);

                if (job.status === 'completed') {
                    if (!job.results) throw new Error("Job completed but results are missing");
                    return job.results;
                }

                if (job.status === 'failed') {
                    throw new Error(job.error?.message || 'Backend processing failed');
                }

                await new Promise(resolve => setTimeout(resolve, 2000));
            }

        } catch (backendError) {
            console.warn("[Coordinator] Backend Analysis failed. Falling back to Client-Side mode.", backendError);
            onProgress('Backend unavailable, switching to local mode...', 10);
            // If Backend failed (likely Auth), forcing standard mode prevents a second GCS upload attempt
            // We can trigger this by modifying the check below
            options.useProMode = false;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════════
    // PROGRESS SMOOTHER
    // ═══════════════════════════════════════════════════════════════════════════════
    const smoothProgress = {
        current: 0,
        target: 0,
        timer: null as any,
        callback: onProgress,

        set(target: number, message?: string) {
            this.target = target;
            if (message) this.currentMessage = message;
            this.startTicker();
        },

        currentMessage: '',

        startTicker() {
            if (this.timer) return;
            this.timer = setInterval(() => {
                if (Math.abs(this.current - this.target) < 0.5) {
                    this.current = this.target;
                    this.callback(this.currentMessage, this.current);
                    clearInterval(this.timer);
                    this.timer = null;
                } else {
                    // Ease towards target (10% of remaining distance)
                    const step = (this.target - this.current) * 0.1;
                    // Ensure minimum movement of 0.1 to avoid Zeno's paradox infinite stall
                    this.current += step > 0 ? Math.max(step, 0.5) : Math.min(step, -0.5);
                    // Cap at target
                    if ((step > 0 && this.current > this.target) || (step < 0 && this.current < this.target)) {
                        this.current = this.target;
                    }
                    this.callback(this.currentMessage, this.current);
                }
            }, 50); // 20fps updates
        },

        stop() {
            if (this.timer) {
                clearInterval(this.timer);
                this.timer = null;
            }
        },

        // Immediate set without smoothing (for resets or 100%)
        setImmediate(target: number, message: string) {
            this.target = target;
            this.current = target;
            this.currentMessage = message;
            this.callback(message, target);
        }
    };

    // Use smoothProgress.set() instead of direct onProgress()
    // Helper to replace direct calls
    const updateProgress = (msg: string, pct: number) => smoothProgress.set(pct, msg);

    // Default to 24fps if metadata is unavailable
    const frameRate = videoMetadata?.frameRate || 24;

    // 1. Determine Strategy
    // Only use Video Intelligence if explicitly requested via Pro Mode AND supported mode (Shot List only now)
    // IMPORTANT: If we fell back from Backend, options.useProMode might have been disabled above.
    let needsVideoIntelligence = options.useProMode && (mode === 'shotlist' || mode === 'full_analysis');

    // 2. Logic Check: CAN we use Video Intelligence?
    // If this is a "Recent Upload" (Dummy File with size 0) and the URI is NOT already a GCS URI,
    // we cannot upload it to GCS. Thus, we must disable Pro Mode for this run.
    const isGcsUri = fileUri?.startsWith('gs://');
    const isDummyFile = file.size === 0;

    if (needsVideoIntelligence && isDummyFile && !isGcsUri) {
        console.warn("Pro Mode (Video Intelligence) unavailable for Recent Uploads (Source file not present). Falling back to Gemini.");
        needsVideoIntelligence = false;
        // Notify user via progress updates? We might want to, but console warn is minimal safety.
        // We'll let the standard fallback logic assume Gemini.
    }

    let gcsUri = fileUri;

    // Try GCS Upload if needed
    if (needsVideoIntelligence) {
        // Variable isGcsUri is already declared above
        if (!isGcsUri) {
            try {
                if (!bucketName) throw new Error('Bucket not configured');

                updateProgress('Uploading to Google Cloud Storage (Zero Hallucination)...', 0);
                gcsUri = await uploadFileToGCS({
                    file,
                    bucketName,
                    apiKey,
                    accessToken,
                    onProgress: (p: UploadProgress) => {
                        updateProgress(p.message, p.percentage * 0.3);
                    },
                    signal
                });
            } catch (error: any) {
                // Check if this is a Scope/Permission error (403)
                // If so, DO NOT fallback, because the user needs to re-auth.
                const isScopeError = error?.message?.includes('ACCESS_TOKEN_SCOPE_INSUFFICIENT') ||
                    error?.message?.includes('insufficient authentication scopes') ||
                    JSON.stringify(error).includes('PERMISSION_DENIED');

                if (isScopeError) {
                    console.error("Pro Mode Auth Error:", error);
                    throw new Error("Authentication Error: Missing 'Cloud Platform' scope. Please Sign Out and Sign In again to upgrade your permissions.");
                }

                console.warn("Zero Hallucination (GCS) unavailable. Seamlessly falling back to Standard AI Analysis.");
                updateProgress("Pro Mode Unavailable (Access Denied). Switching to Standard Mode...", 5);
                needsVideoIntelligence = false; // Fallback to Gemini 1.5 Pro
            }
        } else {
            updateProgress('File already in GCS. Starting analysis...', 35);
        }
    }

    // 3. OPTIONAL: Video Intelligence API (Structure/Skeleton)
    let apiResult: any = null;
    if (needsVideoIntelligence && gcsUri) {
        // Don't reset to 35 if we are already there, just start from there
        if (smoothProgress.current < 35) smoothProgress.setImmediate(35, 'Analyzing video structure (Deterministic)...');
        else updateProgress('Analyzing video structure (Deterministic)...', 35);

        let features: Feature[] = [];
        if (mode === 'shotlist' || mode === 'full_analysis') features.push('SHOT_CHANGE_DETECTION');
        if (mode === 'full_analysis') {
            features.push('LABEL_DETECTION');
            features.push('TEXT_DETECTION');
        }

        try {
            apiResult = await annotateVideo(
                apiKey,
                gcsUri,
                features,
                (progressPercent) => {
                    const overall = 35 + (progressPercent * 0.45);
                    updateProgress(`Video Intelligence API: ${Math.round(progressPercent)}%`, overall);
                },
                signal,
                accessToken,
                projectId
            );
        } catch (error) {
            console.warn("Video Intelligence Analysis failed (likely Auth 401), proceeding with Gemini Fallback:", error);
            onMultiProgress?.('shotlist', 'Shot Detection Skipped (VI unavailable)', 0);
        }
    }

    // 4. REQUIRED: Gemini Files API (Creative Content)
    // Ensure we have a workable URI for Gemini (not gs://)
    // isGcsUri is already calculated at function start
    let geminiUri = isGcsUri ? undefined : fileUri;

    // We strictly use smartUploadToGemini for ALL files now (up to 20GB supported by API)
    // The uploadService handles chunking and reliability.
    const canUseGeminiVision = true;

    if ((!geminiUri || isGcsUri) && canUseGeminiVision) {
        updateProgress('Uploading to Gemini Files API (Visual Enrichment- this may take a while for large files)...', 45);

        try {
            geminiUri = await smartUploadToGemini({
                file,
                apiKey,
                onProgress: (p: UploadProgress) => updateProgress(p.message, 45 + (p.percentage * 0.1)),
                signal
            });
        } catch (e) {
            console.warn("Gemini Upload Failed. Proceeding in Text-Only Mode.", e);
            // Fallthrough: geminiUri will be undefined, triggering fallbacks below.
        }
    }

    const abortSignal = signal || new AbortController().signal;

    // 5. EXECUTION (Unified)
    if (mode === 'full_analysis') {
        // COST OPTIMIZATION: Context Caching "Smart Check"
        let contextCacheName: string | undefined = undefined;
        // DISABLED: Context caching caused "blind model" hallucinations.
        // Reverting to standard non-cached flow for reliability.
        const isLargeFile = false; // file.size > 10 * 1024 * 1024;
        const isLongDuration = false; // (videoMetadata?.duration || 0) > 60;

        if (isLargeFile || isLongDuration) {
            updateProgress('Creating intelligent context cache (Cost Saving)...', 60);
            contextCacheName = await createContextCache(geminiUri!, file.type, 600);
            if (contextCacheName) {
                onMultiProgress?.('full_analysis' as AnalysisMode, 'Cache Active: ~80% Cost Reduction', 0);
            }
        }

        updateProgress('Running comprehensive analysis mostly in parallel...', 65);

        // 1. Transcription (Gemini Flash - Fast & Cheap)
        // 1. Transcription (Gemini Flash - Fast & Cheap) OR Video Intel (Ground Truth)
        const transcriptionPromise = (async () => {
            // OPTION A: Use Video Intelligence Result if available (Pro Mode)
            if (apiResult?.speechTranscriptions && apiResult.speechTranscriptions.length > 0) {
                onMultiProgress?.('transcribe', 'Using Pro Mode Transcript...', 100);
                // Convert VI format to App format
                const text = apiResult.speechTranscriptions
                    .map((st: any) => st.alternatives?.[0]?.transcript || '')
                    .join(' ');

                // TODO: Map words for speaker segments if needed. For now, simple text.
                return { segments: [], speakerMap: {}, text };
            }

            // OPTION B: Gemini Flash (Standard Mode)
            if (geminiUri) {
                try {
                    return await transcribeMedia(geminiUri!, file.type, abortSignal, (msg, pct) => onMultiProgress?.('transcribe', msg, pct), contextCacheName);
                } catch (e) {
                    console.warn('Transcription failed', e);
                    onMultiProgress?.('transcribe', 'Transcription failed', 0);
                    return { segments: [], speakerMap: {}, text: '' };
                }
            }

            return { segments: [], speakerMap: {}, text: '' };
        })();

        // 2. Shot List (VI + Enrichment OR Gemini Fallback)
        const shotsPromise = (async () => {
            // Priority 1: Use Video Intelligence (Pro Mode) if available
            if (apiResult?.shotAnnotations) {
                const enrichmentUri = geminiUri || "SKIP_ENRICHMENT";
                if (enrichmentUri === "SKIP_ENRICHMENT") {
                    onMultiProgress?.('shotlist', 'Visual enrichment skipped (Video > 2GB or Upload Failed)', 100);
                }
                return processShotList(apiResult, enrichmentUri, file.type, 'English', frameRate, signal, (msg, pct) => {
                    onMultiProgress?.('shotlist', msg, pct);
                }, contextCacheName);
            }

            // Priority 2: Fallback to Gemini-only Shotlist (Standard Mode)
            onMultiProgress?.('shotlist', 'Generating Shot List (Standard Mode)...', 10);
            try {
                if (!geminiUri) throw new Error("No video URI available (Upload failed or File too large)");
                const fullConfig = options.shotListConfig || { ...DEFAULT_SHOTLIST_CONFIG };
                return await generateShotList(
                    geminiUri!,
                    file.type,
                    fullConfig.language || 'English',
                    frameRate,
                    abortSignal,
                    (msg, pct) => onMultiProgress?.('shotlist', msg, pct),
                    contextCacheName
                );
            } catch (e) {
                console.error('[GEMINI_DEBUG] Gemini Shotlist Fallback failed with error:', e);
                const errorMessage = e instanceof Error ? e.message : String(e);
                onMultiProgress?.('shotlist', `Shot List Failed: ${errorMessage}`, 0);
                return [];
            }
        })();

        // 3. Synopsis (Creative - Gemini)
        // 3. Synopsis (Creative - Gemini)
        const synopsisPromise = (async () => {
            try {
                onMultiProgress?.('synopsis', 'Generating synopsis...', 10);
                const config: SynopsisConfig = options.synopsisConfig || DEFAULT_SYNOPSIS_CONFIG;

                // STRATEGY: Visual Analysis OR Text Fallback
                let analysis: any = null;

                if (geminiUri) {
                    // Standard Mode: Use Vision
                    analysis = await analyzeVideoContent(geminiUri!, file.type, abortSignal, (msg, pct) => onMultiProgress?.('synopsis', msg, pct * 0.5), contextCacheName);
                } else {
                    // Large File Mode / Fallback: Use Transcript
                    onMultiProgress?.('synopsis', 'Waiting for transcript (Large File Mode)...', 20);
                    const transcriptResult = await transcriptionPromise; // Wait for parallel task
                    if (transcriptResult.text && transcriptResult.text.length > 50) {
                        onMultiProgress?.('synopsis', 'Generating from transcript...', 50);
                        return generateSynopsisFromText(transcriptResult.text, config);
                    } else {
                        throw new Error("No video or transcript available for synopsis.");
                    }
                }

                onMultiProgress?.('synopsis', 'Writing creative summary...', 60);
                const result = await generateSynopsisFromAnalysis(analysis, config.writer || '', config.director || '', 'English', '', abortSignal, config);

                onMultiProgress?.('synopsis', 'Synopsis complete', 100);
                return result;
            } catch (e) {
                const errorMessage = e instanceof Error ? e.message : 'Unknown error';
                console.warn("Synopsis failed:", errorMessage);
                onMultiProgress?.('synopsis', `Synopsis failed: ${errorMessage}`, 0);
                return {
                    title: 'Analysis Unavailable',
                    writtenBy: '',
                    directedBy: '',
                    oneLine: `Analysis failed: ${errorMessage}`,
                    paragraph: '',
                    fullSynopsis: '',
                    keyThemes: '',
                    targetAudience: ''
                };
            }
        })();

        // 4. Bio (Creative - Gemini)
        // 4. Bio (Creative - Gemini)
        const bioPromise = (async () => {
            if (!geminiUri) {
                onMultiProgress?.('bio', 'Bio skipped (Video > 2GB)', 100);
                return [];
            }
            try {
                onMultiProgress?.('bio', 'Scanning for talent...', 10);
                const names = await extractTalentFromVideo(geminiUri!, file.type);
                const topNames = names.slice(0, 3);
                onMultiProgress?.('bio', `Found ${topNames.length} names`, 30);

                const bioResults = [];
                for (let i = 0; i < topNames.length; i++) {
                    const name = topNames[i];
                    onMultiProgress?.('bio', `Researching ${name}...`, 30 + ((i / topNames.length) * 60));
                    bioResults.push(await generateBio(name, 'Actor/Subject', 'English'));
                }
                onMultiProgress?.('bio', 'Bio generation complete', 100);
                return bioResults;
            } catch (e) {
                onMultiProgress?.('bio', 'Bio analysis failed', 0);
                return [];
            }
        })();

        // 5. Fauna (Creative - Gemini)
        // 5. Fauna (Creative - Gemini)
        const faunaPromise = (async () => {
            if (!geminiUri) {
                onMultiProgress?.('fauna', 'Fauna skipped (Video > 2GB)', 100);
                return [];
            }
            try {
                onMultiProgress?.('fauna', 'Identifiying species...', 30);
                const result = await analyzeVideoForSpecies(geminiUri!, file.type, 'English', 'German', videoMetadata?.duration || 0);
                onMultiProgress?.('fauna', 'Fauna analysis complete', 100);
                return result;
            } catch (e) {
                onMultiProgress?.('fauna', 'Fauna analysis failed', 0);
                return [];
            }
        })();

        // 6. Graphics (Creative - Gemini)
        // 6. Graphics (Creative - Gemini)
        const graphicsPromise = (async () => {
            if (!geminiUri) {
                onMultiProgress?.('graphics', 'Graphics skipped (Video > 2GB)', 100);
                return { programTitle: '', runtime: '', graphics: [], lowerThirds: [] };
            }
            try {
                onMultiProgress?.('graphics', 'Reading on-screen text...', 30);
                const config = options.graphicsConfig || {};
                const result = await analyzeGraphicsAndLowerThirds(geminiUri!, file.type, videoMetadata?.duration || 0, file.name);
                onMultiProgress?.('graphics', 'Graphics analysis complete', 100);
                return result;
            } catch (e) {
                onMultiProgress?.('graphics', 'Graphics analysis failed', 0);
                return { programTitle: '', runtime: '', graphics: [], lowerThirds: [] };
            }
        })();

        const [transcription, shots, synopsis, bio, fauna, graphics] = await Promise.all([
            transcriptionPromise,
            shotsPromise,
            synopsisPromise,
            bioPromise,
            faunaPromise,
            graphicsPromise
        ]);

        smoothProgress.stop(); // Stop ticker

        return {
            transcription,
            shotList: shots,
            graphics,
            synopsis,
            bio,
            fauna
        };

    } else if (mode === 'shotlist') {
        const fullConfig = options.shotListConfig || { ...DEFAULT_SHOTLIST_CONFIG };
        return generateShotList(
            geminiUri!,
            file.type,
            fullConfig.language || 'English',
            frameRate,
            abortSignal,
            (msg, pct) => updateProgress(msg, 50 + (pct * 0.5))
        );
    } else if (mode === 'transcribe') {
        return transcribeMedia(
            geminiUri!,
            file.type,
            abortSignal,
            (msg, pct) => updateProgress(msg, 50 + (pct * 0.5))
        );
    } else if (mode === 'synopsis') {
        const config = options.synopsisConfig!;
        const analysis = await analyzeVideoContent(geminiUri!, file.type, abortSignal, (msg, pct) => updateProgress(msg, 20 + pct * 0.4));
        updateProgress('Generating synopsis...', 80);
        return generateSynopsisFromAnalysis(analysis, config.writer || '', config.director || '', config.language || 'English', config.keywords || '', abortSignal, config);
    } else if (mode === 'bio') {
        const config = options.bioConfig!;
        if (config.autoDetect) {
            updateProgress('Scanning for cast names...', 30);
            const names = await extractTalentFromVideo(geminiUri!, file.type);
            const results = [];
            for (let i = 0; i < names.length; i++) {
                const name = names[i];
                updateProgress(`Generating bio for ${name}...`, 50 + ((i / names.length) * 40));
                results.push(await generateBio(name, 'Actor/Subject in video', config.language || 'English'));
            }
            return results;
        } else {
            const results = [];
            for (let i = 0; i < (config.talentDetails || []).length; i++) {
                const t = config.talentDetails![i];
                updateProgress(`Generating bio for ${t.name}...`, 20 + ((i / config.talentDetails!.length) * 70));
                results.push(await generateBio(t.name || 'Unknown', t.context || '', config.language || 'English'));
            }
            return results;
        }
    } else if (mode === 'graphics') {
        const config = options.graphicsConfig!;
        return analyzeGraphicsAndLowerThirds(geminiUri!, file.type, config.videoDuration || 0, config.videoFileName || file.name);
    } else if (mode === 'fauna') {
        const config = options.faunaConfig || { primaryLanguage: 'English', secondaryLanguage: 'German' }; // Default
        return analyzeVideoForSpecies(geminiUri!, file.type, config.primaryLanguage, config.secondaryLanguage, videoMetadata?.duration || 0);
    }

    return null;
    return null;
}

// ═══════════════════════════════════════════════════════════════════════════════
// RESULT PROCESSORS
// ═══════════════════════════════════════════════════════════════════════════════

async function processShotList(
    result: VideoAnnotationResults,
    gcsUri: string,
    mimeType: string,
    language: string,
    frameRate: number,
    signal: AbortSignal | undefined,
    onProgress: (message: string, percentage: number) => void,
    cacheName?: string
): Promise<Omit<Shot, 'nr' | 'thumbnail'>[]> {

    const shotAnnotations = result.shotAnnotations || [];
    if (shotAnnotations.length === 0) return [];

    const isDropFrame = detectTimecodeFormat(frameRate) === 'DF';

    // 1. Create Deterministic Skeleton
    const deterministicShots: Omit<Shot, 'nr' | 'thumbnail'>[] = shotAnnotations.map(segment => {
        const startSeconds = parseOffset(segment.startTimeOffset);
        const endSeconds = parseOffset(segment.endTimeOffset);
        const durationSeconds = endSeconds - startSeconds;

        const formatTc = (s: number) => isDropFrame ? secondsToDropFrameTimecode(s, frameRate) : secondsToTimecode(s, frameRate);

        return {
            tcIn: formatTc(startSeconds),
            tcOut: formatTc(endSeconds),
            duration: formatTc(durationSeconds),
            description: "Analyzing...", // Placeholder
            action: "Reading...", // Placeholder
            audio: ""
        };
    });

    // 2. Enrich with Gemini 1.5 Pro (Qualitative analysis on top of quantitative skeleton)
    if (signal?.aborted) throw new Error('Operation Cancelled');

    if (gcsUri === "SKIP_ENRICHMENT") {
        return deterministicShots;
    }

    return enrichShotList(
        gcsUri,
        mimeType,
        deterministicShots,
        language,
        signal || new AbortController().signal,
        (msg, pct) => {
            // Map enrichment progress (0-100) to remaining (85-100)
            onProgress(msg, 85 + (pct * 0.15));
        },
        cacheName
    );
}



// Helper: Parse "3.5s" to 3.5
function parseOffset(offset: string): number {
    if (!offset) return 0;
    return parseFloat(offset.replace('s', ''));
}

// Helper: Standardized Timecode Formatter using tableUtils
function formatTimecodeStandard(seconds: number, frameRate: number): string {
    if (detectTimecodeFormat(frameRate) === 'DF') {
        return secondsToDropFrameTimecode(seconds, frameRate);
    }
    return secondsToTimecode(seconds, frameRate);
}
