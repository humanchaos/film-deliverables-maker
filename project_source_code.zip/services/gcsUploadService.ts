import { ERROR_IDS, UploadProgress } from '../types';

const GCS_UPLOAD_BASE_URL = 'https://storage.googleapis.com/upload/storage/v1/b';
const CHUNK_SIZE = 8 * 1024 * 1024; // 8MB
const MAX_RETRIES = 3;
const INITIAL_RETRY_DELAY_MS = 1000;

export interface GCSUploadOptions {
    file: File;
    bucketName: string;
    apiKey: string;
    accessToken?: string;
    onProgress: (progress: UploadProgress) => void;
    signal?: AbortSignal;
}

// ... helper functions ...
async function sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function formatBytes(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * Upload a file specifically to a GCS Bucket for Video Intelligence API usage
 * Returns the gs:// URI (e.g., gs://my-bucket/my-video.mp4)
 */
export async function uploadFileToGCS(options: GCSUploadOptions): Promise<string> {
    const { file, bucketName, apiKey, accessToken, onProgress, signal } = options;
    const fileName = `${Date.now()}_${file.name.replace(/\s+/g, '_')}`;

    try {
        // Phase 1: Initialize Resumable Upload
        onProgress({
            phase: 'initializing',
            message: 'Initializing GCS upload...',
            percentage: 1,
            bytesUploaded: 0,
            totalBytes: file.size,
        });

        // If using Token, we don't need API Key in query param (and shouldn't use it for auth)
        const queryParams = accessToken ? `uploadType=resumable&name=${fileName}` : `uploadType=resumable&name=${fileName}&key=${apiKey}`;
        const initUrl = `${GCS_UPLOAD_BASE_URL}/${bucketName}/o?${queryParams}`;

        const headers: Record<string, string> = {
            'Content-Type': 'application/json',
            'X-Upload-Content-Type': file.type,
            'X-Upload-Content-Length': file.size.toString(),
        };

        if (accessToken) {
            headers['Authorization'] = `Bearer ${accessToken}`;
        }

        // Check for existing resumable session
        const storageKey = `gcs_upload_session_${bucketName}_${fileName}_${file.size}`;
        let uploadUrl = localStorage.getItem(storageKey);

        if (uploadUrl) {
            console.log("Resuming GCS upload from existing session:", uploadUrl);
            // Optionally: Verify session validity with a HEAD/PUT query
        } else {
            // Start New Session
            const initResponse = await fetch(initUrl, {
                method: 'POST',
                headers,
                signal,
            });

            if (!initResponse.ok) {
                // If 403, it might be a permissions issue.
                throw new Error(`Failed to initialize GCS upload: ${initResponse.status}`);
            }

            uploadUrl = initResponse.headers.get('Location');
            if (!uploadUrl) {
                throw new Error('No upload URL returned from GCS initialization');
            }

            // Cache the URL
            localStorage.setItem(storageKey, uploadUrl);
        }

        // Phase 2: Upload Chunks
        // Note: For resumable uploads initiated with OAuth, the uploadUrl is usually sufficient and doesn't require Auth header again.
        // However, if it fails 401, we might need it. Standard GCS behavior says session URI is enough.

        // Phase 2: Upload Chunks
        const totalBytes = file.size;
        const totalChunks = Math.ceil(totalBytes / CHUNK_SIZE);
        let bytesUploaded = 0;

        // Step 2a: Query existing progress if resuming
        if (localStorage.getItem(storageKey)) {
            try {
                const statusResponse = await fetch(uploadUrl, {
                    method: 'PUT',
                    headers: { 'Content-Range': `bytes */${totalBytes}` },
                    signal
                });

                if (statusResponse.status === 308) {
                    const rangeHeader = statusResponse.headers.get('Range'); // e.g., "bytes=0-1000"
                    if (rangeHeader) {
                        const match = rangeHeader.match(/bytes=0-(\d+)/);
                        if (match && match[1]) {
                            bytesUploaded = parseInt(match[1], 10) + 1;
                            console.log(`[GCS] Resuming from offset: ${bytesUploaded}`);
                            // Determine which chunk index to start at
                            // We need to align to CHUNK_SIZE boundaries to keep logic simple, 
                            // but GCS might be at an odd offset. 
                            // If GCS is at byte 100, and our chunk size is 1000, we technically need to send 101-1000.
                            // However, simplified approach: if we are mid-chunk, we might just re-send the whole chunk 
                            // or ideally, reconstruct the flow.
                            // For simplicity/robustness: We won't excessively optimize "byte-perfect" resuming for now,
                            // we will just trust the standard flow or reset if invalid.
                            // actually, let's just use the loop and check 'start'.
                        }
                    }
                }
            } catch (e) {
                console.warn("Failed to query upload status, restarting from 0", e);
            }
        }

        for (let chunkIndex = 0; chunkIndex < totalChunks; chunkIndex++) {
            if (signal?.aborted) throw new Error(ERROR_IDS.OPERATION_CANCELLED);

            const start = chunkIndex * CHUNK_SIZE;
            const end = Math.min(start + CHUNK_SIZE, totalBytes);

            // Skip chunks we've already uploaded
            // Note: This is a coarse optimization. If bytesUploaded is 1.5 chunks, we re-upload the 2nd chunk entirely.
            if (start < bytesUploaded) {
                // If we are completely past this chunk, skip
                if (end <= bytesUploaded) {
                    continue;
                }
                // If we are partially through this chunk (rare with fix-sized chunks but possible),
                // we just re-upload the whole chunk. GCS handles overwrites fine for active sessions.
            }

            const chunk = file.slice(start, end);

            let lastError: Error | null = null;
            for (let retry = 0; retry <= MAX_RETRIES; retry++) {
                try {
                    const response = await fetch(uploadUrl, {
                        method: 'PUT',
                        headers: {
                            'Content-Range': `bytes ${start}-${end - 1}/${totalBytes}`,
                        },
                        body: chunk,
                        signal,
                    });

                    // 308 Resume Incomplete is expected for chunks. 200/201 means done.
                    if (response.status !== 308 && response.status !== 200 && response.status !== 201) {
                        // If 410 Gone, session expired. Throw specific error to trigger retry from scratch?
                        // For now/simplicity, just throw error.
                        throw new Error(`GCS Chunk upload failed: ${response.status}`);
                    }

                    // Success for this chunk
                    onProgress({
                        phase: 'uploading',
                        message: `Uploading to Cloud Storage ${formatBytes(end)} / ${formatBytes(totalBytes)}...`,
                        percentage: Math.round((end / totalBytes) * 99),
                        bytesUploaded: end,
                        totalBytes,
                        currentChunk: chunkIndex + 1,
                        totalChunks,
                    });

                    break; // Success
                } catch (error) {
                    lastError = error as Error;
                    if (signal?.aborted) throw new Error(ERROR_IDS.OPERATION_CANCELLED);

                    if (retry < MAX_RETRIES) {
                        const delay = INITIAL_RETRY_DELAY_MS * Math.pow(2, retry);
                        console.warn(`GCS Chunk retry ${retry + 1}... waiting ${delay}ms`);
                        await sleep(delay);
                    }
                }
            }
            if (lastError) throw lastError;
        }

        // Success!
        localStorage.removeItem(`gcs_upload_session_${bucketName}_${fileName}_${file.size}`);
        return `gs://${bucketName}/${fileName}`;

    } catch (error) {
        // Silent fail - App.tsx handles the fallback logging
        console.debug('GCS Upload (Pro Mode) failed, reverting to Standard Mode:', error);
        if (signal?.aborted) throw new Error(ERROR_IDS.OPERATION_CANCELLED);
        throw new Error('Failed to upload video to Google Cloud Storage. Please check your Bucket Name and API Key permissions.');
    }
}
