/**
 * Batched Shot Enrichment Service
 * 
 * Enriches shot descriptions in batches to avoid JSON truncation
 * and rate limiting issues with videos that have hundreds of shots.
 */

import { cacheManager } from './contextCacheManager';
import { withRetry, delayBetweenOperations } from './rateLimitHandler';
import { getOptimalBatchSize } from '../config/modelConfig';

// ============================================
// Types
// ============================================

export interface Shot {
  id: number;
  startTimecode: string;
  endTimecode?: string;
  durationSeconds?: number;
  shotType?: string;
  cameraMovement?: string;
  description?: string;
  thumbnail?: string;
}

export interface EnrichedShot extends Shot {
  description: string;
  subjects?: string[];
  mood?: string;
  composition?: string;
}

interface EnrichmentResult {
  id: number;
  description: string;
  subjects?: string[];
  mood?: string;
}

// ============================================
// Configuration
// ============================================

const DEFAULT_BATCH_SIZE = 50;
const BATCH_DELAY_MS = 2000;
const MAX_RETRIES_PER_BATCH = 2;

// ============================================
// Main Export
// ============================================

/**
 * Enrich shot descriptions in batches
 * 
 * @param jobId - Job ID with cached video context
 * @param shots - Array of shots to enrich
 * @param model - Gemini model to use
 * @param onProgress - Progress callback (0-100)
 */
export async function enrichShotsInBatches(
  jobId: string,
  shots: Shot[],
  model: string = 'gemini-2.5-flash',
  onProgress?: (progress: number) => void
): Promise<EnrichedShot[]> {
  if (!shots.length) {
    return [];
  }

  // Determine optimal batch size based on video (we don't have duration here, so use shot count as proxy)
  const batchSize = shots.length > 300 ? 30 : shots.length > 100 ? 50 : DEFAULT_BATCH_SIZE;
  const batches = chunkArray(shots, batchSize);

  console.log(`[ShotEnrich] Enriching ${shots.length} shots in ${batches.length} batches (size: ${batchSize})`);

  const allEnrichments: EnrichmentResult[] = [];
  let successfulBatches = 0;
  let failedBatches = 0;

  for (let i = 0; i < batches.length; i++) {
    const batch = batches[i];
    const batchNum = i + 1;
    const progress = Math.round((i / batches.length) * 100);
    
    onProgress?.(progress);
    console.log(`[ShotEnrich] Processing batch ${batchNum}/${batches.length} (shots ${batch[0].id}-${batch[batch.length - 1].id})`);

    try {
      const enrichments = await withRetry(
        () => enrichBatch(jobId, batch, model),
        {
          maxRetries: MAX_RETRIES_PER_BATCH,
          baseDelayMs: 3000,
          onRetry: (attempt) => {
            console.log(`[ShotEnrich] Batch ${batchNum} retry ${attempt + 1}`);
          },
        }
      );

      // Validate we got the right number of enrichments
      if (enrichments.length !== batch.length) {
        console.warn(`[ShotEnrich] Batch ${batchNum}: Expected ${batch.length} enrichments, got ${enrichments.length}`);
      }

      allEnrichments.push(...enrichments);
      successfulBatches++;

    } catch (error: any) {
      console.error(`[ShotEnrich] Batch ${batchNum} failed: ${error.message}`);
      failedBatches++;

      // Add placeholder enrichments for failed batch
      batch.forEach(shot => {
        allEnrichments.push({
          id: shot.id,
          description: shot.description || `[Shot ${shot.id}] ${shot.shotType || 'Shot'} at ${shot.startTimecode}`,
        });
      });
    }

    // Delay between batches (except after last)
    if (i < batches.length - 1) {
      await sleep(BATCH_DELAY_MS);
    }
  }

  onProgress?.(100);
  console.log(`[ShotEnrich] Complete: ${successfulBatches} batches succeeded, ${failedBatches} failed`);

  // Merge enrichments back to shots
  return mergeEnrichments(shots, allEnrichments);
}

// ============================================
// Internal Functions
// ============================================

/**
 * Enrich a single batch of shots
 */
async function enrichBatch(
  jobId: string,
  shots: Shot[],
  model: string
): Promise<EnrichmentResult[]> {
  // Build shot list for prompt
  const shotList = shots.map(s => {
    const parts = [`Shot ${s.id}: ${s.startTimecode}`];
    if (s.endTimecode) parts.push(`to ${s.endTimecode}`);
    if (s.shotType) parts.push(`(${s.shotType})`);
    if (s.cameraMovement) parts.push(`[${s.cameraMovement}]`);
    return `- ${parts.join(' ')}`;
  }).join('\n');

  const prompt = `For each shot listed below, provide a detailed visual description based on what is visible in the video at that exact timecode.

SHOTS TO DESCRIBE:
${shotList}

For each shot, describe:
1. Main subject(s) - what/who is in frame
2. Action - what is happening
3. Setting/environment
4. Notable visual elements (lighting, colors, composition)

Return as JSON array with exactly ${shots.length} entries, in the same order as the shots listed:
[
  {
    "id": 1,
    "description": "Wide shot of African savanna at sunset. A herd of elephants (approximately 8 individuals) walks from left to right across the frame. Golden hour lighting creates silhouettes against an orange sky.",
    "subjects": ["elephants", "savanna"],
    "mood": "serene"
  },
  {
    "id": 2,
    "description": "Close-up of elephant calf drinking water, trunk submerged in a muddy waterhole. Water droplets visible. Adult elephant partially visible in background.",
    "subjects": ["elephant calf", "waterhole"],
    "mood": "intimate"
  }
]

IMPORTANT:
- Return EXACTLY ${shots.length} entries
- Keep descriptions concise but specific (2-3 sentences)
- Use professional documentary terminology
- Return ONLY the JSON array, no other text`;

  const response = await cacheManager.generateWithCache(jobId, prompt, model);
  const parsed = safeJsonParse(response);

  // Validate response
  if (!Array.isArray(parsed)) {
    console.warn(`[ShotEnrich] Expected array, got ${typeof parsed}`);
    throw new Error('Invalid response format: expected array');
  }

  // Ensure we have valid enrichments
  return parsed.map((item, index) => ({
    id: item.id ?? shots[index].id,
    description: item.description || `Shot ${shots[index].id}`,
    subjects: item.subjects,
    mood: item.mood,
  }));
}

/**
 * Merge enrichments back into original shots
 * Uses position-based matching, not ID matching
 */
function mergeEnrichments(
  shots: Shot[],
  enrichments: EnrichmentResult[]
): EnrichedShot[] {
  // Sort enrichments by ID to ensure correct order
  const sortedEnrichments = [...enrichments].sort((a, b) => a.id - b.id);

  return shots.map((shot, index) => {
    // Position-based matching
    const enrichment = sortedEnrichments[index];

    if (!enrichment) {
      console.warn(`[ShotEnrich] No enrichment found for shot ${shot.id} at index ${index}`);
      return {
        ...shot,
        description: shot.description || `Shot ${shot.id}`,
      };
    }

    // Verify ID match (warn if mismatch)
    if (enrichment.id !== shot.id) {
      console.warn(`[ShotEnrich] ID mismatch at index ${index}: shot ${shot.id}, enrichment ${enrichment.id}`);
    }

    return {
      ...shot,
      description: enrichment.description,
      subjects: enrichment.subjects,
      mood: enrichment.mood,
    };
  });
}

// ============================================
// Utilities
// ============================================

function chunkArray<T>(array: T[], size: number): T[][] {
  const chunks: T[][] = [];
  for (let i = 0; i < array.length; i += size) {
    chunks.push(array.slice(i, i + size));
  }
  return chunks;
}

function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function safeJsonParse(text: string): any {
  // Remove markdown code blocks
  let cleaned = text
    .replace(/```json\s*/gi, '')
    .replace(/```\s*/gi, '')
    .trim();

  // Try direct parse
  try {
    return JSON.parse(cleaned);
  } catch {
    // Try to extract JSON array
    const arrayMatch = cleaned.match(/\[[\s\S]*\]/);
    if (arrayMatch) {
      try {
        return JSON.parse(arrayMatch[0]);
      } catch {
        // Continue
      }
    }

    // Aggressive repair
    cleaned = cleaned
      .replace(/,\s*}/g, '}')
      .replace(/,\s*\]/g, ']')
      .replace(/'/g, '"');

    try {
      return JSON.parse(cleaned);
    } catch {
      console.warn('[ShotEnrich] JSON parse failed completely');
      return [];
    }
  }
}

// ============================================
// Exports
// ============================================

export { chunkArray, safeJsonParse };
