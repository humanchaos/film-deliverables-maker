/**
 * Context Cache Manager for Gemini API
 * 
 * This service manages video context caching to avoid re-processing
 * the same video for each analysis module.
 * 
 * Key benefits:
 * - 80% reduction in token costs
 * - Avoids rate limits by not re-uploading video per module
 * - Enables sequential processing without re-processing overhead
 */

import { GoogleGenerativeAI, CachedContent } from '@google/generative-ai';

export interface CacheEntry {
  name: string;
  displayName: string;
  fileUri: string;
  model: string;
  createdAt: Date;
  expireTime: Date;
  tokenCount: number;
}

export interface CacheOptions {
  ttlSeconds?: number;  // Default: 3600 (1 hour)
  displayName?: string;
}

class ContextCacheManager {
  private client: GoogleGenerativeAI;
  private localCache: Map<string, CacheEntry> = new Map();

  constructor(apiKey?: string) {
    const key = apiKey || process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error('GEMINI_API_KEY is required');
    }
    this.client = new GoogleGenerativeAI(key);
  }

  /**
   * Create a context cache for a video file
   * Returns existing cache if still valid
   */
  async createVideoCache(
    jobId: string,
    fileUri: string,
    options: CacheOptions = {}
  ): Promise<CacheEntry> {
    const { ttlSeconds = 3600, displayName } = options;

    // Check for existing valid cache
    const existing = this.localCache.get(jobId);
    if (existing && new Date() < existing.expireTime) {
      console.log(`[CacheManager] Reusing existing cache for job ${jobId}`);
      return existing;
    }

    console.log(`[CacheManager] Creating new cache for job ${jobId}`);
    console.log(`[CacheManager] File URI: ${fileUri}`);
    console.log(`[CacheManager] TTL: ${ttlSeconds}s`);

    try {
      // Create cache via Gemini API
      const cacheManager = this.client.cacheManager;
      
      const cachedContent = await cacheManager.create({
        model: 'models/gemini-1.5-pro-002',
        displayName: displayName || `video-analysis-${jobId}`,
        contents: [
          {
            role: 'user',
            parts: [
              {
                fileData: {
                  fileUri: fileUri,
                  mimeType: this.getMimeType(fileUri),
                },
              },
            ],
          },
        ],
        ttlSeconds: ttlSeconds.toString(),
      });

      const entry: CacheEntry = {
        name: cachedContent.name!,
        displayName: cachedContent.displayName || `video-analysis-${jobId}`,
        fileUri: fileUri,
        model: cachedContent.model!,
        createdAt: new Date(),
        expireTime: new Date(cachedContent.expireTime!),
        tokenCount: cachedContent.usageMetadata?.totalTokenCount || 0,
      };

      this.localCache.set(jobId, entry);

      console.log(`[CacheManager] ✓ Cache created successfully`);
      console.log(`[CacheManager]   Name: ${entry.name}`);
      console.log(`[CacheManager]   Tokens: ${entry.tokenCount.toLocaleString()}`);
      console.log(`[CacheManager]   Expires: ${entry.expireTime.toISOString()}`);

      return entry;

    } catch (error: any) {
      console.error(`[CacheManager] Failed to create cache:`, error);
      throw new Error(`Cache creation failed: ${error.message}`);
    }
  }

  /**
   * Get a cached entry by job ID
   * Returns null if cache doesn't exist or is expired
   */
  getCache(jobId: string): CacheEntry | null {
    const entry = this.localCache.get(jobId);
    
    if (!entry) {
      return null;
    }

    if (new Date() >= entry.expireTime) {
      console.log(`[CacheManager] Cache expired for job ${jobId}`);
      this.localCache.delete(jobId);
      return null;
    }

    return entry;
  }

  /**
   * Generate content using a cached context
   */
  async generateWithCache(
    jobId: string,
    prompt: string,
    modelOverride?: string
  ): Promise<string> {
    const cache = this.getCache(jobId);
    
    if (!cache) {
      throw new Error(`No valid cache found for job ${jobId}. Create cache first.`);
    }

    // Use the model from cache or override
    const modelName = modelOverride || 'gemini-2.5-flash';
    
    console.log(`[CacheManager] Generating with cached context`);
    console.log(`[CacheManager]   Cache: ${cache.name}`);
    console.log(`[CacheManager]   Model: ${modelName}`);
    console.log(`[CacheManager]   Prompt length: ${prompt.length} chars`);

    const model = this.client.getGenerativeModel({
      model: modelName,
      cachedContent: cache.name,
    });

    const result = await model.generateContent(prompt);
    const response = result.response.text();

    console.log(`[CacheManager]   Response length: ${response.length} chars`);

    return response;
  }

  /**
   * Delete a specific cache
   */
  async deleteCache(jobId: string): Promise<boolean> {
    const entry = this.localCache.get(jobId);
    
    if (!entry) {
      return false;
    }

    try {
      await this.client.cacheManager.delete(entry.name);
      this.localCache.delete(jobId);
      console.log(`[CacheManager] Deleted cache for job ${jobId}`);
      return true;
    } catch (error) {
      console.warn(`[CacheManager] Failed to delete cache:`, error);
      return false;
    }
  }

  /**
   * List all active caches (from local tracking)
   */
  listCaches(): CacheEntry[] {
    const now = new Date();
    const active: CacheEntry[] = [];

    for (const [jobId, entry] of this.localCache.entries()) {
      if (now < entry.expireTime) {
        active.push(entry);
      } else {
        this.localCache.delete(jobId);
      }
    }

    return active;
  }

  /**
   * Cleanup all expired caches
   */
  async cleanupExpired(): Promise<number> {
    const now = new Date();
    let cleaned = 0;

    for (const [jobId, entry] of this.localCache.entries()) {
      if (now >= entry.expireTime) {
        try {
          await this.client.cacheManager.delete(entry.name);
        } catch {
          // Cache may already be deleted by TTL
        }
        this.localCache.delete(jobId);
        cleaned++;
      }
    }

    if (cleaned > 0) {
      console.log(`[CacheManager] Cleaned up ${cleaned} expired caches`);
    }

    return cleaned;
  }

  /**
   * Get estimated cost savings from using cache
   */
  getStats(): { totalCachedTokens: number; estimatedSavings: number } {
    let totalTokens = 0;
    const modulesPerVideo = 5; // Average modules run per video

    for (const entry of this.localCache.values()) {
      totalTokens += entry.tokenCount;
    }

    // Without caching: tokens × modules
    // With caching: tokens × 1
    const savedTokens = totalTokens * (modulesPerVideo - 1);
    const estimatedSavings = (savedTokens / 1_000_000) * 1.25; // $1.25 per M tokens

    return {
      totalCachedTokens: totalTokens,
      estimatedSavings: Math.round(estimatedSavings * 100) / 100,
    };
  }

  private getMimeType(fileUri: string): string {
    const ext = fileUri.split('.').pop()?.toLowerCase();
    const mimeTypes: Record<string, string> = {
      'mp4': 'video/mp4',
      'mov': 'video/quicktime',
      'avi': 'video/x-msvideo',
      'mkv': 'video/x-matroska',
      'webm': 'video/webm',
    };
    return mimeTypes[ext || ''] || 'video/mp4';
  }
}

// Export singleton instance
export const cacheManager = new ContextCacheManager();

// Export class for testing/custom instances
export { ContextCacheManager };
