/**
 * Sequential Video Processor
 * 
 * Processes video analysis modules sequentially for long videos
 * to avoid rate limiting, or in parallel for short videos.
 */

import { cacheManager } from './contextCacheManager';
import { 
  getModelForTask, 
  getTaskConfig,
  shouldUseSequentialProcessing,
  getOptimalBatchSize,
  estimateProcessingTime 
} from '../config/modelConfig';
import { withRetry, delayBetweenOperations } from './rateLimitHandler';
import { enrichShotsInBatches } from './shotEnrichment';

// ============================================
// Types
// ============================================

export interface ProcessingOptions {
  jobId: string;
  fileUri: string;
  videoDuration: number; // seconds
  enabledModules: string[];
  onModuleStart?: (module: string) => void;
  onModuleProgress?: (module: string, progress: number) => void;
  onModuleComplete?: (module: string, result: ModuleResult) => void;
}

export interface ModuleResult {
  module: string;
  status: 'completed' | 'failed' | 'skipped';
  data?: any;
  error?: string;
  durationMs: number;
  tokenEstimate?: number;
}

export interface ProcessingResult {
  jobId: string;
  success: boolean;
  results: ModuleResult[];
  totalDurationMs: number;
  processingMode: 'sequential' | 'parallel';
}

// ============================================
// Main Processor
// ============================================

export async function processVideo(
  options: ProcessingOptions
): Promise<ProcessingResult> {
  const {
    jobId,
    fileUri,
    videoDuration,
    enabledModules,
    onModuleStart,
    onModuleProgress,
    onModuleComplete,
  } = options;

  const startTime = Date.now();
  const results: ModuleResult[] = [];

  // Determine processing mode
  const useSequential = shouldUseSequentialProcessing(videoDuration, enabledModules.length);
  const mode = useSequential ? 'sequential' : 'parallel';

  console.log(`\n${'='.repeat(60)}`);
  console.log(`[Processor] Starting job: ${jobId}`);
  console.log(`[Processor] Video duration: ${formatDuration(videoDuration)}`);
  console.log(`[Processor] Modules: ${enabledModules.join(', ')}`);
  console.log(`[Processor] Processing mode: ${mode.toUpperCase()}`);

  // Estimate processing time
  const estimate = estimateProcessingTime(videoDuration, enabledModules);
  console.log(`[Processor] Estimated time: ${formatDuration(estimate.totalSeconds)}`);
  console.log(`${'='.repeat(60)}\n`);

  // Step 1: Create context cache
  console.log(`[Processor] Creating context cache...`);
  const cacheTtl = useSequential ? 7200 : 3600; // 2 hours for long, 1 hour for short
  
  try {
    const cache = await cacheManager.createVideoCache(jobId, fileUri, {
      ttlSeconds: cacheTtl,
      displayName: `job-${jobId}`,
    });
    console.log(`[Processor] ✓ Cache ready (${cache.tokenCount.toLocaleString()} tokens)\n`);
  } catch (error) {
    console.error(`[Processor] ✗ Failed to create cache:`, error);
    return {
      jobId,
      success: false,
      results: [{
        module: 'cache',
        status: 'failed',
        error: String(error),
        durationMs: Date.now() - startTime,
      }],
      totalDurationMs: Date.now() - startTime,
      processingMode: mode,
    };
  }

  // Step 2: Process modules
  if (useSequential) {
    // Sequential processing with delays
    for (let i = 0; i < enabledModules.length; i++) {
      const module = enabledModules[i];
      
      onModuleStart?.(module);
      
      const result = await processModuleSafe(
        jobId,
        module,
        (progress) => onModuleProgress?.(module, progress)
      );
      
      results.push(result);
      onModuleComplete?.(module, result);

      // Delay between modules (except after last)
      if (i < enabledModules.length - 1) {
        await delayBetweenOperations(3000);
      }
    }
  } else {
    // Parallel processing for short videos
    const promises = enabledModules.map(async (module) => {
      onModuleStart?.(module);
      
      const result = await processModuleSafe(
        jobId,
        module,
        (progress) => onModuleProgress?.(module, progress)
      );
      
      onModuleComplete?.(module, result);
      return result;
    });

    results.push(...await Promise.all(promises));
  }

  // Summary
  const totalDuration = Date.now() - startTime;
  const successful = results.filter(r => r.status === 'completed').length;
  const failed = results.filter(r => r.status === 'failed').length;

  console.log(`\n${'='.repeat(60)}`);
  console.log(`[Processor] Job ${jobId} complete`);
  console.log(`[Processor] Duration: ${formatDuration(totalDuration / 1000)}`);
  console.log(`[Processor] Results: ${successful} completed, ${failed} failed`);
  console.log(`${'='.repeat(60)}\n`);

  return {
    jobId,
    success: failed === 0,
    results,
    totalDurationMs: totalDuration,
    processingMode: mode,
  };
}

// ============================================
// Module Processing
// ============================================

async function processModuleSafe(
  jobId: string,
  module: string,
  onProgress?: (progress: number) => void
): Promise<ModuleResult> {
  const startTime = Date.now();

  console.log(`[${module}] Starting...`);
  onProgress?.(0);

  try {
    const data = await withRetry(
      () => processModule(jobId, module, onProgress),
      {
        maxRetries: 3,
        baseDelayMs: 5000,
        onRetry: (attempt, delay) => {
          console.log(`[${module}] Retry ${attempt + 1} after ${delay}ms`);
        },
      }
    );

    const duration = Date.now() - startTime;
    console.log(`[${module}] ✓ Completed in ${formatDuration(duration / 1000)}`);
    onProgress?.(100);

    return {
      module,
      status: 'completed',
      data,
      durationMs: duration,
    };

  } catch (error: any) {
    const duration = Date.now() - startTime;
    console.error(`[${module}] ✗ Failed: ${error.message}`);

    return {
      module,
      status: 'failed',
      error: error.message,
      durationMs: duration,
    };
  }
}

async function processModule(
  jobId: string,
  module: string,
  onProgress?: (progress: number) => void
): Promise<any> {
  const model = getModelForTask(module);
  const config = getTaskConfig(module);

  console.log(`[${module}] Using model: ${model}`);

  switch (module) {
    case 'synopsis':
      return processSynopsis(jobId, model);

    case 'shotList':
      return processShotList(jobId, model, onProgress);

    case 'transcription':
      return processTranscription(jobId, model);

    case 'graphics':
      return processGraphics(jobId, model);

    case 'fauna':
      return processFauna(jobId, model);

    case 'cast':
      return processCast(jobId, model);

    default:
      throw new Error(`Unknown module: ${module}`);
  }
}

// ============================================
// Individual Module Implementations
// ============================================

async function processSynopsis(jobId: string, model: string): Promise<string> {
  const prompt = `You are a professional video analyst for a documentary production company.

Analyze this video and provide a comprehensive synopsis suitable for broadcast documentation.

Structure your response as follows:

OVERVIEW
[2-3 sentence summary of the entire video]

NARRATIVE ARC
[Describe the story structure, key plot points, and progression]

KEY SCENES
[List 5-10 most significant scenes with approximate timestamps]

SUBJECTS & CHARACTERS
[Identify main subjects, characters, or interviewees]

VISUAL STYLE
[Describe cinematography, color palette, editing style]

TONE & MOOD
[Overall emotional tone and atmosphere]

TARGET AUDIENCE
[Suggested audience demographics and interests]

BROADCAST NOTES
[Any considerations for broadcast scheduling or content warnings]

Be specific, professional, and concise.`;

  return cacheManager.generateWithCache(jobId, prompt, model);
}

async function processShotList(
  jobId: string,
  model: string,
  onProgress?: (progress: number) => void
): Promise<any[]> {
  // First, detect all shots
  const detectPrompt = `Analyze this video and identify every distinct shot/cut.

For each shot, provide:
- Shot number (sequential)
- Start timecode (HH:MM:SS:FF format, 25fps)
- End timecode
- Duration in seconds
- Shot type (wide, medium, close-up, extreme close-up, etc.)
- Camera movement (static, pan, tilt, dolly, handheld, etc.)

Return as JSON array:
[
  {
    "id": 1,
    "startTimecode": "00:00:00:00",
    "endTimecode": "00:00:05:12",
    "durationSeconds": 5.5,
    "shotType": "wide",
    "cameraMovement": "static"
  }
]

Detect ALL shots in the video. Return ONLY valid JSON array.`;

  console.log(`[shotList] Detecting shots...`);
  const detectResponse = await cacheManager.generateWithCache(jobId, detectPrompt, model);
  const shots = safeJsonParse(detectResponse);

  if (!Array.isArray(shots) || shots.length === 0) {
    console.warn(`[shotList] No shots detected or invalid response`);
    return [];
  }

  console.log(`[shotList] Detected ${shots.length} shots`);

  // For many shots, enrich in batches
  if (shots.length > 20) {
    console.log(`[shotList] Enriching ${shots.length} shots in batches...`);
    return enrichShotsInBatches(jobId, shots, model, onProgress);
  }

  return shots;
}

async function processTranscription(jobId: string, model: string): Promise<any[]> {
  const prompt = `Transcribe ALL spoken content in this video with precise timestamps.

Requirements:
- Include every word spoken
- Use speaker diarization (SPEAKER_01, SPEAKER_02, etc.)
- Use timecodes in HH:MM:SS format
- Preserve natural speech patterns (um, uh, pauses noted as [pause])
- Note any non-speech audio events in brackets [laughter], [applause], etc.

Return as JSON array:
[
  {
    "startTime": "00:00:05",
    "endTime": "00:00:12",
    "speaker": "SPEAKER_01",
    "transcript": "Welcome to the show. Today we'll be discussing..."
  }
]

Transcribe the COMPLETE video. Return ONLY valid JSON array.`;

  const response = await cacheManager.generateWithCache(jobId, prompt, model);
  return safeJsonParse(response);
}

async function processGraphics(jobId: string, model: string): Promise<any[]> {
  const prompt = `Identify ALL on-screen graphics, text, and visual overlays in this video.

For each graphic element, provide:
- Timecode when it appears
- Duration on screen
- Type (lower third, full screen, logo, subtitle, chart, map, etc.)
- Content (exact text if readable, description if not)
- Position on screen (lower third, center, upper right, etc.)

Return as JSON array:
[
  {
    "timecode": "00:01:30",
    "duration": 5,
    "type": "lower_third",
    "content": "Dr. Jane Smith - Marine Biologist",
    "position": "lower_third_left"
  }
]

Include ALL graphics throughout the entire video. Return ONLY valid JSON array.`;

  const response = await cacheManager.generateWithCache(jobId, prompt, model);
  return safeJsonParse(response);
}

async function processFauna(jobId: string, model: string): Promise<any[]> {
  const prompt = `Identify ALL wildlife and fauna visible in this video.

For each species identified:
- Common name
- Scientific name (if identifiable)
- Timecode of first appearance
- Approximate total screen time
- Behavior observed
- Confidence level (high, medium, low)

Return as JSON array:
[
  {
    "commonName": "African Elephant",
    "scientificName": "Loxodonta africana",
    "firstAppearance": "00:02:15",
    "screenTimeSeconds": 45,
    "behavior": "Drinking at waterhole with calf",
    "confidence": "high"
  }
]

Identify ALL animals, birds, fish, insects, etc. Return ONLY valid JSON array.`;

  const response = await cacheManager.generateWithCache(jobId, prompt, model);
  return safeJsonParse(response);
}

async function processCast(jobId: string, model: string): Promise<any[]> {
  const prompt = `Identify all people appearing in this video.

For each person:
- Name (if identified via graphics, speech, or recognition)
- Role (host, interviewee, expert, narrator, etc.)
- First appearance timecode
- Approximate screen time
- Notable characteristics

Return as JSON array:
[
  {
    "name": "Unknown Speaker 1",
    "role": "interviewee",
    "firstAppearance": "00:00:30",
    "screenTimeSeconds": 120,
    "description": "Male, approximately 40s, wearing blue shirt"
  }
]

List ALL people who appear on screen. Return ONLY valid JSON array.`;

  const response = await cacheManager.generateWithCache(jobId, prompt, model);
  return safeJsonParse(response);
}

// ============================================
// Utilities
// ============================================

function safeJsonParse(text: string): any {
  // Remove markdown code blocks
  let cleaned = text
    .replace(/```json\s*/gi, '')
    .replace(/```\s*/gi, '')
    .trim();

  // Try direct parse
  try {
    return JSON.parse(cleaned);
  } catch (e) {
    // Try to extract JSON array
    const arrayMatch = cleaned.match(/\[[\s\S]*\]/);
    if (arrayMatch) {
      try {
        return JSON.parse(arrayMatch[0]);
      } catch {
        // Continue to aggressive repair
      }
    }

    // Aggressive repair: fix common issues
    cleaned = cleaned
      .replace(/,\s*}/g, '}')     // Remove trailing commas in objects
      .replace(/,\s*\]/g, ']')    // Remove trailing commas in arrays
      .replace(/'/g, '"')         // Single to double quotes
      .replace(/(\w+):/g, '"$1":'); // Unquoted keys

    try {
      return JSON.parse(cleaned);
    } catch {
      console.warn('[Parser] All parse attempts failed');
      return [];
    }
  }
}

function formatDuration(seconds: number): string {
  if (seconds < 60) {
    return `${Math.round(seconds)}s`;
  }
  const mins = Math.floor(seconds / 60);
  const secs = Math.round(seconds % 60);
  if (mins < 60) {
    return `${mins}m ${secs}s`;
  }
  const hours = Math.floor(mins / 60);
  const remainMins = mins % 60;
  return `${hours}h ${remainMins}m`;
}

export { formatDuration, safeJsonParse };
