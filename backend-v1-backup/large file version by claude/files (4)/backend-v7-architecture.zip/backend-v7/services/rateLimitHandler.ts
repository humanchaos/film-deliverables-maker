/**
 * Rate Limit Handler with Exponential Backoff
 * 
 * Handles Gemini API 429 errors with intelligent retry logic
 * that respects the API's retry-after hints.
 */

export interface RetryConfig {
  maxRetries: number;
  baseDelayMs: number;
  maxDelayMs: number;
  onRetry?: (attempt: number, delay: number, error: any) => void;
}

const DEFAULT_CONFIG: RetryConfig = {
  maxRetries: 5,
  baseDelayMs: 1000,
  maxDelayMs: 120_000, // 2 minutes max
};

/**
 * Wrap an async operation with retry logic for rate limits
 */
export async function withRetry<T>(
  operation: () => Promise<T>,
  config: Partial<RetryConfig> = {}
): Promise<T> {
  const { maxRetries, baseDelayMs, maxDelayMs, onRetry } = {
    ...DEFAULT_CONFIG,
    ...config,
  };

  let lastError: Error | null = null;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await operation();
    } catch (error: any) {
      lastError = error;

      // Check if this is a retryable error
      if (!isRetryableError(error)) {
        throw error;
      }

      // Don't retry if we've exhausted attempts
      if (attempt >= maxRetries) {
        console.error(`[RateLimit] Max retries (${maxRetries}) exceeded`);
        throw error;
      }

      // Calculate delay
      const retryAfter = extractRetryAfter(error);
      const backoffDelay = calculateBackoff(attempt, baseDelayMs, maxDelayMs);
      const delay = retryAfter || backoffDelay;

      console.warn(`[RateLimit] Rate limited (attempt ${attempt + 1}/${maxRetries + 1})`);
      console.warn(`[RateLimit] Waiting ${delay}ms before retry...`);

      // Notify callback if provided
      onRetry?.(attempt, delay, error);

      // Wait before retry
      await sleep(delay);
    }
  }

  throw lastError || new Error('Unexpected retry loop exit');
}

/**
 * Check if an error is retryable (rate limit or transient)
 */
function isRetryableError(error: any): boolean {
  // HTTP 429 Too Many Requests
  if (error?.status === 429) return true;
  if (error?.code === 429) return true;

  // Check error message
  const message = String(error?.message || '').toLowerCase();
  if (message.includes('429')) return true;
  if (message.includes('rate limit')) return true;
  if (message.includes('quota exceeded')) return true;
  if (message.includes('resource exhausted')) return true;

  // HTTP 503 Service Unavailable (transient)
  if (error?.status === 503) return true;

  // HTTP 500 Internal Server Error (sometimes transient)
  if (error?.status === 500) return true;

  return false;
}

/**
 * Extract retry-after delay from error response
 */
function extractRetryAfter(error: any): number | null {
  // Check for Retry-After header (in seconds)
  const retryHeader = error?.headers?.['retry-after'] || 
                      error?.response?.headers?.['retry-after'];
  if (retryHeader) {
    const seconds = parseInt(retryHeader, 10);
    if (!isNaN(seconds)) {
      return seconds * 1000;
    }
  }

  // Check for retryDelay in Gemini error response
  // Format: "retryDelay": "42s" or quotaValue/retryDelay in message
  const message = String(error?.message || '');
  
  // Match patterns like: retryDelay: "42s" or retryDelay":"42s"
  const retryMatch = message.match(/retryDelay['":\s]+(\d+)s/i);
  if (retryMatch) {
    return parseInt(retryMatch[1], 10) * 1000;
  }

  // Match "retry after X seconds" pattern
  const retryAfterMatch = message.match(/retry after (\d+) seconds/i);
  if (retryAfterMatch) {
    return parseInt(retryAfterMatch[1], 10) * 1000;
  }

  return null;
}

/**
 * Calculate exponential backoff with jitter
 */
function calculateBackoff(
  attempt: number,
  baseMs: number,
  maxMs: number
): number {
  // Exponential: base * 2^attempt
  const exponential = baseMs * Math.pow(2, attempt);
  
  // Add random jitter (0-25% of exponential)
  const jitter = exponential * Math.random() * 0.25;
  
  // Cap at maximum
  return Math.min(exponential + jitter, maxMs);
}

/**
 * Sleep for specified milliseconds
 */
function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Rate limiter class for managing request pacing
 */
export class RateLimiter {
  private queue: Array<() => void> = [];
  private processing = false;
  private lastRequestTime = 0;

  constructor(
    private requestsPerMinute: number,
    private tokensPerMinute: number
  ) {}

  /**
   * Wait for rate limit slot to be available
   */
  async acquire(): Promise<void> {
    const minInterval = 60_000 / this.requestsPerMinute;
    const now = Date.now();
    const elapsed = now - this.lastRequestTime;

    if (elapsed < minInterval) {
      await sleep(minInterval - elapsed);
    }

    this.lastRequestTime = Date.now();
  }

  /**
   * Execute an operation with rate limiting
   */
  async execute<T>(operation: () => Promise<T>): Promise<T> {
    await this.acquire();
    return operation();
  }
}

/**
 * Create a rate-limited version of an async function
 */
export function rateLimited<T extends (...args: any[]) => Promise<any>>(
  fn: T,
  limiter: RateLimiter
): T {
  return (async (...args: Parameters<T>) => {
    return limiter.execute(() => fn(...args));
  }) as T;
}

/**
 * Utility: Delay between sequential operations
 */
export async function delayBetweenOperations(ms: number = 2000): Promise<void> {
  console.log(`[RateLimit] Waiting ${ms}ms between operations...`);
  await sleep(ms);
}
