/**
 * Model Configuration and Task Routing
 * 
 * Routes different analysis tasks to appropriate Gemini models
 * based on their requirements (context needs, speed, accuracy)
 */

export interface ModelSpec {
  id: string;
  name: string;
  contextWindow: number;
  outputLimit: number;
  strengths: string[];
  rateLimit: {
    rpm: number;  // Requests per minute (Tier 1)
    tpm: number;  // Tokens per minute (Tier 1)
  };
}

export const MODELS: Record<string, ModelSpec> = {
  // Best for long video understanding - 2M context, best recall
  'gemini-1.5-pro-002': {
    id: 'gemini-1.5-pro-002',
    name: 'Gemini 1.5 Pro',
    contextWindow: 2_000_000,
    outputLimit: 8_192,
    strengths: ['long-context', 'video-understanding', 'retrieval-accuracy'],
    rateLimit: { rpm: 100, tpm: 1_000_000 },
  },

  // Best balance of speed and quality
  'gemini-2.5-flash': {
    id: 'gemini-2.5-flash',
    name: 'Gemini 2.5 Flash',
    contextWindow: 1_000_000,
    outputLimit: 8_192,
    strengths: ['speed', 'multimodal', 'cost-effective'],
    rateLimit: { rpm: 450, tpm: 1_000_000 },
  },

  // Highest rate limits, good for batched operations
  'gemini-2.0-flash': {
    id: 'gemini-2.0-flash',
    name: 'Gemini 2.0 Flash',
    contextWindow: 1_000_000,
    outputLimit: 8_192,
    strengths: ['speed', 'high-throughput', 'tool-use'],
    rateLimit: { rpm: 300, tpm: 250_000 },
  },

  // Thinking model for complex reasoning
  'gemini-2.5-pro': {
    id: 'gemini-2.5-pro',
    name: 'Gemini 2.5 Pro',
    contextWindow: 1_000_000,
    outputLimit: 8_192,
    strengths: ['reasoning', 'complex-analysis', 'accuracy'],
    rateLimit: { rpm: 150, tpm: 1_000_000 },
  },
};

/**
 * Task categories and their model requirements
 */
export type TaskCategory = 'heavy' | 'balanced' | 'fast';

export interface TaskConfig {
  category: TaskCategory;
  model: string;
  description: string;
  estimatedTokens: number;  // Rough estimate for output
  requiresFullContext: boolean;
}

export const TASK_CONFIGS: Record<string, TaskConfig> = {
  // Heavy tasks - need full video understanding
  synopsis: {
    category: 'heavy',
    model: 'gemini-1.5-pro-002',
    description: 'Full video synopsis generation',
    estimatedTokens: 2000,
    requiresFullContext: true,
  },
  
  transcription: {
    category: 'heavy',
    model: 'gemini-1.5-pro-002',
    description: 'Full audio transcription with timestamps',
    estimatedTokens: 10000,
    requiresFullContext: true,
  },

  // Balanced tasks - good speed/quality tradeoff
  shotList: {
    category: 'balanced',
    model: 'gemini-2.5-flash',
    description: 'Shot detection and timecode extraction',
    estimatedTokens: 5000,
    requiresFullContext: true,
  },

  shotEnrich: {
    category: 'balanced',
    model: 'gemini-2.5-flash',
    description: 'Shot description enrichment (batched)',
    estimatedTokens: 1000,  // Per batch
    requiresFullContext: true,
  },

  graphics: {
    category: 'balanced',
    model: 'gemini-2.5-flash',
    description: 'On-screen graphics and text detection',
    estimatedTokens: 3000,
    requiresFullContext: true,
  },

  fauna: {
    category: 'balanced',
    model: 'gemini-2.5-flash',
    description: 'Wildlife species identification',
    estimatedTokens: 3000,
    requiresFullContext: true,
  },

  // Fast tasks - simple extraction
  cast: {
    category: 'fast',
    model: 'gemini-2.0-flash',
    description: 'Talent/cast identification',
    estimatedTokens: 1000,
    requiresFullContext: false,
  },

  metadata: {
    category: 'fast',
    model: 'gemini-2.0-flash',
    description: 'Basic video metadata extraction',
    estimatedTokens: 500,
    requiresFullContext: false,
  },
};

/**
 * Get the recommended model for a task
 */
export function getModelForTask(task: string): string {
  const config = TASK_CONFIGS[task];
  if (!config) {
    console.warn(`[ModelRouter] Unknown task "${task}", using default model`);
    return 'gemini-2.5-flash';
  }
  return config.model;
}

/**
 * Get full configuration for a task
 */
export function getTaskConfig(task: string): TaskConfig | null {
  return TASK_CONFIGS[task] || null;
}

/**
 * Get model specification
 */
export function getModelSpec(modelId: string): ModelSpec | null {
  return MODELS[modelId] || null;
}

/**
 * Calculate estimated processing time based on video duration and tasks
 */
export function estimateProcessingTime(
  videoDurationSeconds: number,
  tasks: string[]
): { totalSeconds: number; breakdown: Record<string, number> } {
  const breakdown: Record<string, number> = {};
  let total = 0;

  // Base time: video analysis (roughly 1:10 ratio for long videos)
  const baseTime = Math.max(60, videoDurationSeconds / 10);

  for (const task of tasks) {
    const config = TASK_CONFIGS[task];
    if (!config) continue;

    let taskTime: number;
    switch (config.category) {
      case 'heavy':
        taskTime = baseTime * 1.5;
        break;
      case 'balanced':
        taskTime = baseTime;
        break;
      case 'fast':
        taskTime = baseTime * 0.5;
        break;
      default:
        taskTime = baseTime;
    }

    // Add buffer for sequential processing
    if (videoDurationSeconds > 600) {
      taskTime += 10; // 10s buffer between modules
    }

    breakdown[task] = Math.round(taskTime);
    total += taskTime;
  }

  return {
    totalSeconds: Math.round(total),
    breakdown,
  };
}

/**
 * Determine if video should use sequential processing
 */
export function shouldUseSequentialProcessing(
  videoDurationSeconds: number,
  taskCount: number
): boolean {
  // Sequential for videos > 10 minutes
  if (videoDurationSeconds > 600) return true;
  
  // Sequential if many tasks on medium-length videos
  if (videoDurationSeconds > 300 && taskCount > 3) return true;
  
  return false;
}

/**
 * Get optimal batch size for shot enrichment based on video length
 */
export function getOptimalBatchSize(
  shotCount: number,
  videoDurationSeconds: number
): number {
  // Shorter videos can handle larger batches
  if (videoDurationSeconds < 300) return 100;
  if (videoDurationSeconds < 600) return 75;
  if (videoDurationSeconds < 1800) return 50;
  return 30; // Very long videos need smaller batches
}
