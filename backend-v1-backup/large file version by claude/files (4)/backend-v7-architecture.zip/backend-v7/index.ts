/**
 * Video Analysis Backend V7
 * 
 * Main entry point and integration example
 */

// ============================================
// Exports
// ============================================

export { cacheManager, ContextCacheManager } from './services/contextCacheManager';
export { processVideo, ProcessingOptions, ProcessingResult, ModuleResult } from './services/sequentialProcessor';
export { enrichShotsInBatches, Shot, EnrichedShot } from './services/shotEnrichment';
export { withRetry, RateLimiter, delayBetweenOperations } from './services/rateLimitHandler';
export {
  MODELS,
  TASK_CONFIGS,
  getModelForTask,
  getTaskConfig,
  shouldUseSequentialProcessing,
  estimateProcessingTime,
} from './config/modelConfig';

// ============================================
// Integration Example
// ============================================

/*
USAGE EXAMPLE:
==============

import { processVideo, cacheManager } from './backend-v7';

// In your analysis coordinator:

async function runAnalysis(request: AnalysisRequest) {
  const { jobId, fileUri, videoDuration, config } = request;

  // Build enabled modules list
  const enabledModules: string[] = [];
  if (config.synopsis) enabledModules.push('synopsis');
  if (config.shotList) enabledModules.push('shotList');
  if (config.transcription) enabledModules.push('transcription');
  if (config.graphics) enabledModules.push('graphics');
  if (config.fauna) enabledModules.push('fauna');
  if (config.cast) enabledModules.push('cast');

  // Process video
  const result = await processVideo({
    jobId,
    fileUri,
    videoDuration,
    enabledModules,
    onModuleStart: (module) => {
      console.log(`Starting ${module}...`);
      updateJobStatus(jobId, module, 'processing', 0);
    },
    onModuleProgress: (module, progress) => {
      updateJobStatus(jobId, module, 'processing', progress);
    },
    onModuleComplete: (module, result) => {
      updateJobStatus(jobId, module, result.status, 100);
    },
  });

  // Store results
  await storeResults(jobId, result);

  return result;
}


CLOUD RUN DEPLOYMENT:
=====================

1. Copy these files to your backend/src directory:
   - services/contextCacheManager.ts
   - services/sequentialProcessor.ts
   - services/shotEnrichment.ts
   - services/rateLimitHandler.ts
   - config/modelConfig.ts

2. Update your existing analysisCoordinator.ts to use processVideo()

3. Update package.json if needed:
   npm install @google/generative-ai@latest

4. Deploy:
   gcloud run deploy gemini-super-app-backend \
     --source . \
     --region europe-west3 \
     --set-env-vars="GEMINI_API_KEY=your-key"


COST SAVINGS CALCULATION:
=========================

Without caching (current):
- 52-min video = ~820,000 tokens
- 5 modules = 5 × 820K = 4.1M input tokens
- Cost: 4.1M × $1.25/M = $5.13 per video

With caching (V7):
- Cache: 820K tokens (one-time)
- Prompts: 5 × 5K = 25K tokens
- Total: 845K tokens
- Cache storage: ~$0.10/hour
- Cost: 845K × $1.25/M + $0.10 = $1.16 per video

SAVINGS: 77% reduction in token costs
*/


// ============================================
// Quick Start Function
// ============================================

import { processVideo } from './services/sequentialProcessor';

/**
 * Simplified function for quick integration
 */
export async function analyzeVideo(
  jobId: string,
  fileUri: string,
  videoDurationSeconds: number,
  modules: {
    synopsis?: boolean;
    shotList?: boolean;
    transcription?: boolean;
    graphics?: boolean;
    fauna?: boolean;
    cast?: boolean;
  }
) {
  const enabledModules: string[] = [];
  
  if (modules.synopsis) enabledModules.push('synopsis');
  if (modules.shotList) enabledModules.push('shotList');
  if (modules.transcription) enabledModules.push('transcription');
  if (modules.graphics) enabledModules.push('graphics');
  if (modules.fauna) enabledModules.push('fauna');
  if (modules.cast) enabledModules.push('cast');

  if (enabledModules.length === 0) {
    throw new Error('At least one module must be enabled');
  }

  return processVideo({
    jobId,
    fileUri,
    videoDuration: videoDurationSeconds,
    enabledModules,
  });
}
