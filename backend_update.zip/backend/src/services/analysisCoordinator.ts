import { Storage } from '@google-cloud/storage';
import { GoogleAIFileManager, FileState } from "@google/generative-ai/server";
import { GoogleGenerativeAI } from "@google/generative-ai";
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import * as https from 'https';
import { db } from '../config/firebase';
import { config } from '../config/env';
import { JobDocument, FullAnalysisResult } from '../types';
import * as geminiService from './geminiService';
import * as videoIntelligenceService from './videoIntelligenceService';
import { logger } from '../utils/logger';
import { pipeline } from 'stream/promises';

const storage = new Storage();
if (!config.geminiApiKey) {
    logger.warn("GEMINI_API_KEY is missing. Gemini File Manager will fail.");
}
const fileManager = new GoogleAIFileManager(config.geminiApiKey || '');

/**
 * Main Orchestrator for Video Analysis.
 */
export async function performAnalysis(jobId: string, job: JobDocument): Promise<Partial<FullAnalysisResult>> {
    logger.info(`Starting Analysis Coordinator for Job ${jobId}`);

    const { gcsUri, analysisConfig } = job.input;
    // Removed tempFilePath logic (No Disk Usage)
    let geminiFileUri: string | null = null;
    let geminiFileName: string | null = null;
    const results: Partial<FullAnalysisResult> = {};

    try {
        // 1. PREPARATION: Stream to Gemini (if needed)
        const needsGemini = analysisConfig.synopsis || analysisConfig.fauna ||
            analysisConfig.graphics || analysisConfig.transcription || analysisConfig.cast;

        if (needsGemini) {
            await updateProgress(jobId, 'preparing', 5, 'Streaming video from GCS to Gemini...');

            // STREAMING UPLOAD (No Disk Buffer)
            const uploadResult = await streamGcsToGemini(gcsUri, 'video/mp4', config.geminiApiKey || '');

            geminiFileUri = uploadResult.uri;
            geminiFileName = uploadResult.name; // "files/..." name

            await updateProgress(jobId, 'preparing', 15, 'Waiting for Gemini processing...');
            await waitForGeminiFileActive(geminiFileName);
        }

        // 2. PARALLEL EXECUTION
        const promises: Promise<any>[] = [];

        // --- A. Video Intelligence ---
        if (analysisConfig.videoIntelligence) {
            promises.push((async () => {
                try {
                    await updateModuleStatus(jobId, 'shotList', 'processing', 0);
                    // Use AnnotateVideo directly (already supports GCS URI natively)
                    await videoIntelligenceService.annotateVideo(gcsUri, ['SHOT_CHANGE_DETECTION', 'LABEL_DETECTION'] as any);
                    await updateModuleStatus(jobId, 'shotList', 'completed', 100);
                } catch (e: any) {
                    logger.error("Video Intelligence Failed", e);
                    await updateModuleStatus(jobId, 'shotList', 'failed', 0, e.message);
                }
            })());
        }

        // --- B. Gemini Modules ---
        if (geminiFileUri) {
            // 1. Synopsis
            if (analysisConfig.synopsis) {
                promises.push(runModule(jobId, 'synopsis', async () => {
                    const analysis = await geminiService.analyzeVideoContent(geminiFileUri!, 'video/mp4');
                    return geminiService.generateSynopsisFromAnalysis(
                        analysis, 'AI Writer', 'AI Director', 'English', '', job.input.analysisConfig as any // reusing config
                    );
                }, results));
            }

            // 2. Fauna
            if (analysisConfig.fauna) {
                promises.push(runModule(jobId, 'fauna', async () => {
                    return geminiService.analyzeVideoForSpecies(geminiFileUri!, 'video/mp4', 'English', 'German', job.input.duration || 0);
                }, results));
            }

            // 3. Graphics
            if (analysisConfig.graphics) {
                promises.push(runModule(jobId, 'graphics', async () => {
                    return geminiService.analyzeGraphicsAndLowerThirds(geminiFileUri!, 'video/mp4', job.input.duration || 0, 'Unknown Title');
                }, results));
            }

            // 4. Transcription
            if (analysisConfig.transcription) {
                promises.push(runModule(jobId, 'transcription', async () => {
                    return geminiService.transcribeMedia(geminiFileUri!, 'video/mp4');
                }, results));
            }
        }

        await Promise.all(promises);
        return results;

    } catch (error) {
        logger.error("Analysis Coordinator Critical Error", error);
        throw error;
    } finally {
        if (geminiFileName) {
            try {
                await fileManager.deleteFile(geminiFileName);
                logger.info(`Deleted Gemini file: ${geminiFileName}`);
            } catch (e) {
                logger.warn(`Failed to delete Gemini file: ${geminiFileName}`, e);
            }
        }
    }
}

// Helper to standardise module execution & error handling
async function runModule(jobId: string, moduleName: string, action: () => Promise<any>, resultsObj: any) {
    try {
        await updateModuleStatus(jobId, moduleName, 'processing', 0);
        const res = await action();
        resultsObj[moduleName] = res;
        await updateModuleStatus(jobId, moduleName, 'completed', 100);
    } catch (e: any) {
        logger.error(`Module ${moduleName} Failed`, e);
        await updateModuleStatus(jobId, moduleName, 'failed', 0, e.message);
    }
}

// ---------------------------------------------------------------------------
// STREAMING UPLOAD IMPLEMENTATION
// ---------------------------------------------------------------------------

async function streamGcsToGemini(gcsUri: string, mimeType: string, apiKey: string): Promise<{ name: string, uri: string }> {
    const matches = gcsUri.match(/gs:\/\/([^\/]+)\/(.+)/);
    if (!matches) throw new Error(`Invalid GCS URI: ${gcsUri}`);
    const bucketName = matches[1];
    const fileName = matches[2];

    const bucket = storage.bucket(bucketName);
    const gcsFile = bucket.file(fileName);
    const [metadata] = await gcsFile.getMetadata();
    const fileSize = parseInt(metadata.size as string, 10);

    logger.info(`Starting stream upload for ${fileName} (${fileSize} bytes)`);

    // 1. Start Resumable Upload Session (Gemini API)
    const initRes = await fetch(`https://generativelanguage.googleapis.com/upload/v1beta/files?key=${apiKey}`, {
        method: 'POST',
        headers: {
            'X-Goog-Upload-Protocol': 'resumable',
            'X-Goog-Upload-Command': 'start',
            'X-Goog-Upload-Header-Content-Length': fileSize.toString(),
            'X-Goog-Upload-Header-Content-Type': mimeType,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ file: { display_name: fileName } })
    });

    if (!initRes.ok) throw new Error(`Failed to init upload: ${initRes.statusText}`);
    const uploadUrl = initRes.headers.get('x-goog-upload-url');
    if (!uploadUrl) throw new Error("No upload URL returned");

    // 2. Pipe Stream
    // We use Node's native https to pipe the stream because fetch with duplex streams can be tricky in some environments

    return new Promise((resolve, reject) => {
        const readStream = gcsFile.createReadStream();

        const req = https.request(uploadUrl, {
            method: 'POST', // or PUT depending on command? Actually for resumable 'upload, finalize' usually PUT or POST. standard is PUT for bytes.
            // But wait, the uploadUrl is unique.
            // X-Goog-Upload-Command: upload, finalize
            headers: {
                'Content-Length': fileSize,
                'X-Goog-Upload-Offset': '0',
                'X-Goog-Upload-Command': 'upload, finalize'
            }
        }, (res) => {
            let data = '';
            res.on('data', (chunk) => data += chunk);
            res.on('end', () => {
                if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) {
                    try {
                        const json = JSON.parse(data);
                        logger.info(`Stream upload complete: ${json.file.uri}`);
                        resolve(json.file);
                    } catch (e) {
                        reject(e);
                    }
                } else {
                    reject(new Error(`Upload failed with status ${res.statusCode}: ${data}`));
                }
            });
        });

        req.on('error', (e) => reject(e));

        // Pipe GCS stream to Request
        readStream.pipe(req);
    });
}

async function waitForGeminiFileActive(name: string) {
    logger.info(`Waiting for Gemini file ${name} to be ACTIVE...`);
    const startTime = Date.now();
    const TIMEOUT_MS = 30 * 60 * 1000;
    let file = await fileManager.getFile(name);
    while (file.state === FileState.PROCESSING) {
        if (Date.now() - startTime > TIMEOUT_MS) throw new Error(`Timeout ${name}`);
        await new Promise(r => setTimeout(r, 2000));
        file = await fileManager.getFile(name);
    }
    if (file.state === FileState.FAILED) throw new Error("Gemini Processing Failed");
    logger.info("Gemini File ACTIVE");
}

async function updateProgress(jobId: string, stage: string, percentage: number, message: string) {
    await db.collection('jobs').doc(jobId).update({
        'progress.overall': percentage,
        'progress.currentStage': message,
        updatedAt: new Date()
    });
}

async function updateModuleStatus(jobId: string, module: string, status: string, progress: number, error?: string) {
    const update: any = { [`progress.modules.${module}.status`]: status, [`progress.modules.${module}.progress`]: progress };
    if (error) update[`progress.modules.${module}.error`] = error;
    await db.collection('jobs').doc(jobId).update(update);
}

export const canRunServerSide = (job: JobDocument) => {
    // If we have a GCS URI and a valid Job ID, we are authorized by the system
    // The Worker Service Account handles the Google API auth, not the user.
    return !!job.input.gcsUri;
};
