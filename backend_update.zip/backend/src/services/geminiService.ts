import { GoogleGenerativeAI, SchemaType as Type } from "@google/generative-ai";
import { config } from '../config/env';
import {
    AnalysisResult,
    Synopsis,
    SynopsisConfig,
    GraphicsAnalysisResult,
    TranscriptionResult,
    SpeciesSighting
} from '../types';

// Initialize the Official SDK
const genAI = new GoogleGenerativeAI(config.geminiApiKey || '');

// ═══════════════════════════════════════════════════════════════════════════════
// UTILITY FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════════

function repairJson(jsonString: string): string {
    let fixed = jsonString.trim();
    // 1. Remove Markdown code blocks
    fixed = fixed.replace(/^```(json)?|```$/g, '');
    // 2. Extract JSON object/array if embedded in text
    const jsonMatch = fixed.match(/(\{[\s\S]*\}|\[[\s\S]*\])/);
    if (jsonMatch) {
        fixed = jsonMatch[0];
    }
    // 3. Fix trailing commas (common AI error)
    fixed = fixed.replace(/,(\s*[}\]])/g, '$1');
    return fixed;
}

function safeJsonParse<T>(jsonString: string): T {
    try {
        const cleanString = repairJson(jsonString);
        if (!cleanString) throw new Error("Empty JSON response");
        return JSON.parse(cleanString);
    } catch (e) {
        console.warn("Initial JSON parse failed, attempting aggressive repair...", e);
        try {
            let aggressiveFix = jsonString.replace(/,(\s*)/g, ',$1');
            aggressiveFix = aggressiveFix.replace(/([}\]])[\s\S]*$/, '$1');
            return JSON.parse(repairJson(aggressiveFix));
        } catch (e2) {
            console.error("Failed to parse JSON response:", jsonString, e2);
            throw new Error("INVALID_API_RESPONSE");
        }
    }
}

function formatDuration(seconds: number): string {
    if (isNaN(seconds) || seconds < 0) return "00:00:00";
    const totalSeconds = Math.floor(seconds);
    const h = Math.floor(totalSeconds / 3600), m = Math.floor((totalSeconds % 3600) / 60), s = totalSeconds % 60;
    return [h, m, s].map(v => String(v).padStart(2, '0')).join(':');
}

// ═══════════════════════════════════════════════════════════════════════════════
// SYNOPSIS GENERATION
// ═══════════════════════════════════════════════════════════════════════════════

export const analyzeVideoContent = async (
    fileUri: string,
    mimeType: string
): Promise<AnalysisResult> => {

    try {
        const prompt = `
      You are an expert video analysis AI. Analyze the provided video file.
      Your task is to synthesize all information into a final, cohesive analysis in JSON format.
      - Transcribe spoken words if present.
      - Summarize the entire video in one sentence.
      - Create a single, chronological list of the most important key events.
      - Infer any potential dialogue or important sounds based on visual cues if audio is unclear.
      
      **CRITICAL:** Base all descriptions strictly on the video content. Do not invent details not present in the video.
    `;

        const modelConfig: any = {
            model: 'gemini-1.5-pro', // Use 1.5 Pro for backend analysis (better context)
            generationConfig: {
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        summary: { type: Type.STRING, description: "A brief, one-sentence summary of the video's content." },
                        events: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    timestamp: { type: Type.STRING, description: "Approximate time or sequence of the event (e.g., '00:05', 'Beginning', 'Middle')." },
                                    description: { type: Type.STRING, description: "A detailed description of what is happening in the event." },
                                },
                                required: ['timestamp', 'description'],
                            },
                        },
                        inferred_dialogue: { type: Type.STRING, description: "An inferred transcription of what might be said, based on visual cues." },
                        transcription: { type: Type.STRING, description: "A transcription of the spoken content from the audio track. If no audio was provided, state that." },
                    },
                    required: ['summary', 'events', 'inferred_dialogue', 'transcription'],
                },
            }
        };

        const model = genAI.getGenerativeModel(modelConfig);

        const result = await model.generateContent([
            { fileData: { fileUri: fileUri, mimeType: mimeType } },
            { text: prompt }
        ]);

        const rawText = result.response.text() || '';
        return safeJsonParse<AnalysisResult>(rawText);

    } catch (error: any) {
        console.error("Error analyzing video with Gemini:", error);
        throw new Error(error.message || "ANALYSIS_FAIL");
    }
};

export const generateSynopsisFromAnalysis = async (
    analysis: AnalysisResult,
    writer: string,
    director: string,
    language: string,
    keywords: string,
    synopsisConfig: SynopsisConfig
): Promise<Synopsis> => {

    try {
        const prompt = `
          You are a master screenwriter and film marketing expert. Your task is to transform raw video analysis data into a compelling, professional film synopsis and marketing profile. Your writing should be evocative and ready for a pitch deck.

          **Your Constraints:**
          - **Language:** Generate all content in: ${language}.
          - **Title:** Maximum ${synopsisConfig.titleMaxChars} characters.
          - **One Line (Logline):** Approximately ${synopsisConfig.loglineMaxWords} words.
          - **Paragraph (Summary):** Approximately ${synopsisConfig.summaryMaxWords} words.
          - **Key Themes:** Approximately ${synopsisConfig.keyThemesMaxWords} words.
          - **Target Audience:** Approximately ${synopsisConfig.targetAudienceMaxWords} words.
          
          **Video Analysis Data:**
          - Transcription: "${analysis.transcription}"
          - Summary: "${analysis.summary}"
          - Key Events: ${JSON.stringify(analysis.events.map(e => e.description))}
          - Inferred Dialogue: "${analysis.inferred_dialogue}"

          Your output must be a single JSON object with keys: "title", "oneLine", "paragraph", "fullSynopsis", "keyThemes", "targetAudience".
      `;

        const model = genAI.getGenerativeModel({
            model: 'gemini-1.5-pro',
            generationConfig: {
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        title: { type: Type.STRING },
                        oneLine: { type: Type.STRING },
                        paragraph: { type: Type.STRING },
                        fullSynopsis: { type: Type.STRING },
                        keyThemes: { type: Type.STRING },
                        targetAudience: { type: Type.STRING }
                    },
                    required: ['title', 'oneLine', 'paragraph', 'fullSynopsis', 'keyThemes', 'targetAudience']
                }
            }
        });

        const result = await model.generateContent(prompt);
        const aiGeneratedContent = safeJsonParse<any>(result.response.text() || '');

        return {
            ...aiGeneratedContent,
            writtenBy: writer,
            directedBy: director,
        };

    } catch (error: any) {
        console.error("Error generating synopsis with Gemini:", error);
        throw new Error("SYNOPSIS_FAIL");
    }
};

// ═══════════════════════════════════════════════════════════════════════════════
// GRAPHICS
// ═══════════════════════════════════════════════════════════════════════════════

export async function analyzeGraphicsAndLowerThirds(
    fileUri: string, mimeType: string, duration: number, filmTitle: string
): Promise<GraphicsAnalysisResult> {

    const prompt = `You are a post-production assistant with excellent OCR skills. Analyze the provided video file. Your task is to identify and transcribe all on-screen graphics (e.g., title cards, location indicators) and lower thirds. Output strictly JSON.`;

    try {
        const model = genAI.getGenerativeModel({
            model: 'gemini-1.5-flash', // Flash is better for OCR/Vision tasks usually
            generationConfig: {
                responseMimeType: 'application/json',
                temperature: 0.2,
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        programTitle: { type: Type.STRING },
                        runtime: { type: Type.STRING },
                        graphics: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT, properties: {
                                    description: { type: Type.STRING },
                                    timecodeIn: { type: Type.STRING },
                                    timecodeOut: { type: Type.STRING },
                                    cleanTimecodeIn: { type: Type.STRING },
                                    cleanTimecodeOut: { type: Type.STRING },
                                },
                                required: ["description", "timecodeIn", "timecodeOut"],
                            },
                        },
                        lowerThirds: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT, properties: {
                                    text: { type: Type.STRING },
                                    timecodeIn: { type: Type.STRING },
                                    timecodeOut: { type: Type.STRING }
                                },
                                required: ["text", "timecodeIn", "timecodeOut"],
                            },
                        },
                    },
                    required: ["programTitle", "runtime", "graphics", "lowerThirds"],
                },
            }
        });

        const result = await model.generateContent([
            { fileData: { fileUri: fileUri, mimeType: mimeType } },
            { text: prompt }
        ]);

        const parsedResult = safeJsonParse<GraphicsAnalysisResult>(result.response.text() || '');
        parsedResult.programTitle = filmTitle;
        parsedResult.runtime = formatDuration(duration);
        return parsedResult;
    } catch (e) {
        console.error("Error analyzing graphics:", e);
        throw new Error("Graphics analysis failed.");
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// FAUNA FINDER
// ═══════════════════════════════════════════════════════════════════════════════

export async function analyzeVideoForSpecies(
    fileUri: string,
    mimeType: string,
    primaryLanguage: string,
    secondaryLanguage: string,
    videoDuration: number = 0
): Promise<Omit<SpeciesSighting, 'id' | 'thumbnail'>[]> {

    const prompt = `Analyze this video. Your task is to identify **every single animal sighting**. 
    Provide: 
    - 'commonName': The common name in ${primaryLanguage}.
    - 'latinName': The scientific name.
    - 'germanName': The common name in ${secondaryLanguage}.
    - 'timecode': The EXACT timecode.
    - 'category': (e.g., "Mammal", "Bird").
    - 'confidence': 0.0 to 1.0.
    - 'behavior': Brief description.
    - 'iucnStatus': IUCN status if known.
    - 'encounterGroup': Group ID if same individual seen multiple times.
    
    The final output must be a valid JSON object with a single key "sightings".`;

    try {
        const model = genAI.getGenerativeModel({
            model: 'gemini-1.5-flash',
            generationConfig: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        sightings: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    commonName: { type: Type.STRING },
                                    latinName: { type: Type.STRING },
                                    germanName: { type: Type.STRING },
                                    timecode: { type: Type.STRING },
                                    category: { type: Type.STRING },
                                    confidence: { type: Type.NUMBER },
                                    behavior: { type: Type.STRING },
                                    iucnStatus: { type: Type.STRING },
                                    encounterGroup: { type: Type.STRING },
                                },
                                required: ["commonName", "latinName", "timecode", "category", "confidence"],
                            },
                        },
                    },
                    required: ["sightings"],
                },
            },
        });

        const result = await model.generateContent([
            { fileData: { fileUri: fileUri, mimeType: mimeType } },
            { text: prompt }
        ]);

        const parsed = safeJsonParse<any>(result.response.text() || '');
        return parsed.sightings || [];

    } catch (e) {
        console.error(`Error analyzing fauna:`, e);
        throw new Error("Fauna analysis failed.");
    }
}

export async function transcribeMedia(
    fileUri: string, mimeType: string
): Promise<Omit<TranscriptionResult, 'speakerMap'>> {

    const prompt = `You are an expert audio transcription AI. Transcribe the provided media, identifying different speakers as SPEAKER_00, SPEAKER_01, etc. Provide the output as a time-coded transcript in a JSON object adhering to the schema.`;

    try {
        const model = genAI.getGenerativeModel({
            model: 'gemini-1.5-flash',
            generationConfig: {
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        segments: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    startTime: { type: Type.STRING },
                                    endTime: { type: Type.STRING },
                                    speaker: { type: Type.STRING },
                                    text: { type: Type.STRING },
                                },
                                required: ["startTime", "endTime", "speaker", "text"],
                            },
                        },
                    },
                    required: ["segments"],
                },
            }
        });

        const result = await model.generateContent([
            { fileData: { fileUri: fileUri, mimeType: mimeType } },
            { text: prompt }
        ]);

        const parsed = safeJsonParse<any>(result.response.text() || '');
        return parsed;

    } catch (error: any) {
        console.error("Transcription error", error);
        throw new Error("Transcription Failed");
    }
}
