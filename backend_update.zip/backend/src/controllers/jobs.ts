import { Request, Response } from 'express';
import { db } from '../config/firebase';
import { config } from '../config/env';
import { logger } from '../utils/logger';
import { CloudTasksClient } from '@google-cloud/tasks';
import { JobDocument, ModuleStatus } from '../types';
import { Timestamp } from 'firebase-admin/firestore';

const tasksClient = new CloudTasksClient();

// Define enhanced type for Cloud Tasks request
interface HttpRequestWithAuth {
    httpMethod: 'POST';
    url: string;
    body: string;
    headers: Record<string, string>;
    oidcToken?: { serviceAccountEmail: string };
}

export const createJob = async (req: Request, res: Response) => {
    try {
        const { gcsUri, mimeType, duration, analysisConfig, userId } = req.body;

        if (!gcsUri) {
            return res.status(400).json({ error: 'gcsUri is required' });
        }

        // 1. Create Job Document
        const initialModuleStatus: ModuleStatus = { status: 'pending', progress: 0 };

        // Convert duration to number if not already
        const durationNum = typeof duration === 'string' ? parseFloat(duration) : (duration || 0);

        const jobData: Omit<JobDocument, 'id'> = {
            userId: userId || 'anonymous',
            createdAt: Timestamp.now(),
            updatedAt: Timestamp.now(),
            status: 'queued',
            input: {
                gcsUri,
                mimeType: mimeType || 'video/mp4',
                duration: durationNum,
                analysisConfig: analysisConfig || {}
            },
            progress: {
                overall: 0,
                currentStage: 'Initialized',
                modules: {
                    fauna: { ...initialModuleStatus },
                    transcription: { ...initialModuleStatus },
                    shotList: { ...initialModuleStatus },
                    synopsis: { ...initialModuleStatus },
                    graphics: { ...initialModuleStatus },
                    cast: { ...initialModuleStatus }
                }
            },
            results: {}
        };

        const docRef = await db.collection('jobs').add(jobData);
        const jobId = docRef.id;

        logger.info('Job created', { jobId });

        // 2. Dispatch Cloud Task
        if (config.projectId && config.queueName && config.location && config.workerUrl) {
            const parent = tasksClient.queuePath(config.projectId, config.location, config.queueName);

            const taskRequest: HttpRequestWithAuth = {
                httpMethod: 'POST',
                url: config.workerUrl.endsWith('/workers/process')
                    ? config.workerUrl
                    : `${config.workerUrl}/workers/process`,
                body: Buffer.from(JSON.stringify({ jobId })).toString('base64'),
                headers: {
                    'Content-Type': 'application/json',
                },
            };

            if (config.serviceAccountEmail) {
                taskRequest.oidcToken = {
                    serviceAccountEmail: config.serviceAccountEmail
                };
            }

            const task = { httpRequest: taskRequest as any }; // Cast to satisfy library type if needed

            const [response] = await tasksClient.createTask({ parent, task });
            logger.info('Cloud Task dispatched', { taskId: response.name });
        } else {
            logger.warn('Cloud Tasks not configured, skipping dispatch (Local Mode?)');
        }

        res.status(201).json({ id: jobId, status: 'queued' });

    } catch (error) {
        logger.error('Error creating job', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};

export const getJob = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const jobRef = db.collection('jobs').doc(id);
        const doc = await jobRef.get();

        if (!doc.exists) {
            logger.warn(`Job document not found for ID: "${id}"`);
            return res.status(404).json({ error: 'Job not found' });
        }

        const data = doc.data() as Omit<JobDocument, 'id'> & { hasSubcollections?: boolean; results?: Record<string, any> }; // Allow extra fields

        // S5: Result Hydration (GCS Pointers)
        // Check for "isOffloaded" or "gcsUri" in results and fetch content.
        if (data.results) {
            const hydrationPromises: Promise<void>[] = [];

            Object.keys(data.results).forEach(key => {
                const moduleData = data.results![key];
                // Check if this is a pointer
                if (moduleData && moduleData.isOffloaded && moduleData.url) {
                    hydrationPromises.push((async () => {
                        try {
                            // Fetch the JSON content from the signed URL
                            // We use fetch here for simplicity. 
                            // In a high-throughput backend, we might use Storage bucket.file().download() but that requires parsing URI.
                            // The signed URL is already optimized for reading.
                            const response = await fetch(moduleData.url);
                            if (!response.ok) throw new Error(`Failed to fetch ${key}: ${response.statusText}`);
                            const json = await response.json();

                            // Inline the data, replacing the pointer 
                            // (Or merge it if you want to keep metadata, but frontend likely expects the raw analysis shape)
                            data.results![key] = json;
                        } catch (e) {
                            logger.error(`Failed to hydrate result for ${key}`, e);
                            data.results![key] = { error: 'Failed to load result' };
                        }
                    })());
                }
            });

            if (hydrationPromises.length > 0) {
                await Promise.all(hydrationPromises);
            }
        }

        // Legacy Subcollection Support (Optional, keep if needed for old jobs)
        if (data.hasSubcollections) {
            const resultsRef = jobRef.collection('results');
            const modules = ['transcription', 'shotList', 'fauna', 'synopsis'];
            const subDocs = await Promise.all(modules.map(m => resultsRef.doc(m).get()));

            if (!data.results) data.results = {};
            subDocs.forEach((subDoc, index) => {
                if (subDoc.exists) {
                    const content = subDoc.data();
                    if (content && content.data) {
                        data.results![modules[index]] = content.data;
                    }
                }
            });
        }

        res.json({ ...data, id: doc.id } as JobDocument);

    } catch (error) {
        logger.error('Error fetching job', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};

export const debugLatestJobs = async (req: Request, res: Response) => {
    try {
        const snapshot = await db.collection('jobs')
            .orderBy('createdAt', 'desc')
            .limit(5)
            .get();

        const jobs = snapshot.docs.map(doc => ({
            id: doc.id,
            status: doc.data().status,
            createdAt: doc.data().createdAt
        }));

        res.json({
            count: snapshot.size,
            projectId: process.env.GOOGLE_CLOUD_PROJECT || 'unknown',
            jobs
        });
    } catch (error) {
        logger.error('Debug list failed', error);
        res.status(500).json({ error: error instanceof Error ? error.message : 'Error' });
    }
};
