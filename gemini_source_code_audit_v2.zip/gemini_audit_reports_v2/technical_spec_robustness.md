# Technical Specification: Robustness Protocol (v2.1)
**Component:** `AnalysisCoordinator` (Frontend)
**Date:** December 22, 2025

## 1. Overview
This document specifies the "Laws of Physics" robustness hardening applied to the Long Running Job mechanism. The system is designed to tolerate unstable network environments, client-side resource constraints (sleeping laptops), and extended processing times without "hanging" or degrading the user experience.

## 2. Polling Logic (Finite State Machine)

The polling mechanism in `performAnalysis` has been refactored from a simple `while` loop to a robust state machine with the following guards:

### 2.1. Offline Isolation (The "Laptop Sleep" Guard)
**Problem:** Previous versions interpreted OS-level sleep (which severs network connections) as a `fetch_error`, incrementing failure counts and eventually timing out the job.
**Solution:**
```typescript
// Guard: Check Physical Link Layer
if (typeof navigator !== 'undefined' && !navigator.onLine) {
    console.log("[Coordinator] Offline detected. Pausing...");
    await sleep(5000);
    continue; // Loop Checkpoint - Do not increment error count
}
```
**Behavior:** The system enters a "Hibernation State" when offline. It consumes minimal resources and does not penalize the job's "Health Score". Analysis resumes instantly upon network restoration.

### 2.2. Deterministic Timeouts (The "Anti-Hang" Guard)
**Problem:** Infinite loops caused by uncaught backend stalls or zombie states.
**Solution:**
- **Global Wall-Clock Limit:** `JOB_TIMEOUT = 90 minutes`.
  - Hard limit based on Cloud Run Gen 2 max execution time.
- **Consecutive Error Limit:** `MAX_CONSECUTIVE_ERRORS = 20`.
  - Allows for transient glitches (WiFi handover) but fails fast on persistent outages (~3-5 minutes).

### 2.3. Adaptive Backoff (The "Thundering Herd" Guard)
**Strategy:**
- **Base Interval:** 2 seconds.
- **Growth Factor:** `1.5` (Exponential).
- **Cap:** 10 seconds.
- **Jitter:** RANDOM(0, 1000)ms (Prevents synchronized polling from multiple tabs).
- **Visibility Mod:** If `document.hidden` (User switched tabs), interval sets to hard 30s to respect browser throttling and save battery.

## 3. Error Classification

| Error Signature | Classification | Action |
|-----------------|----------------|--------|
| `navigator.onLine === false` | **Physical Layer** | PAUSE (Indefinite) |
| `fetch` throws (Network) | **Transport Layer** | RETRY (up to 20x) |
| `401 Unauthorized` | **Auth Layer** | FAIL FAST (Fallback to Local) |
| `403 Forbidden` | **Auth Layer** | FAIL FAST (Fallback to Local) |
| `404 Not Found` | **Logic Layer** | ABORT (Job Lost/Expired) |
| `5xx Server Error` | **Service Layer** | RETRY (Standard Backoff) |

## 4. Implementation Source
**File:** `services/analysisCoordinator.ts`
**Key Function:** `performAnalysis` -> `while(true)` loop.

This specification ensures that the frontend behaves as a resilient "Thin Client" to the "Thick Backend" on Cloud Run.
