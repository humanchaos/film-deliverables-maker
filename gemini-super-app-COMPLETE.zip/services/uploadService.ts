/**
 * Robust Large File Upload Service for Gemini API
 * 
 * Handles multi-gigabyte video uploads using:
 * - Resumable upload protocol (chunked uploads)
 * - Web Worker offloading (keeps UI responsive)
 * - Progress tracking with accurate byte counts
 * - Automatic retry with exponential backoff
 * - Cancellation support
 */

import { ERROR_IDS } from '../types';

// ═══════════════════════════════════════════════════════════════════════════════
// CONFIGURATION
// ═══════════════════════════════════════════════════════════════════════════════

const GEMINI_UPLOAD_BASE_URL = 'https://generativelanguage.googleapis.com/upload/v1beta/files';

// Chunk size must be multiple of 256KB (262144 bytes)
// 8MB chunks balance between progress granularity and request overhead
const CHUNK_SIZE = 8 * 1024 * 1024; // 8MB

const MAX_RETRIES = 3;
const INITIAL_RETRY_DELAY_MS = 1000;

// ═══════════════════════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════════════════════

export interface UploadProgress {
  phase: 'initializing' | 'uploading' | 'processing' | 'complete' | 'error';
  message: string;
  percentage: number;
  bytesUploaded: number;
  totalBytes: number;
  currentChunk?: number;
  totalChunks?: number;
}

export interface UploadResult {
  fileUri: string;
  fileName: string;
  mimeType: string;
  state: string;
}

export interface UploadOptions {
  apiKey: string;
  file: File;
  onProgress: (progress: UploadProgress) => void;
  signal?: AbortSignal;
}

// ═══════════════════════════════════════════════════════════════════════════════
// HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════════

function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

async function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ═══════════════════════════════════════════════════════════════════════════════
// RESUMABLE UPLOAD IMPLEMENTATION
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Step 1: Initialize resumable upload session
 * Returns the upload URL to use for subsequent chunk uploads
 */
async function initializeResumableUpload(
  apiKey: string,
  file: File,
  signal?: AbortSignal
): Promise<string> {
  const url = `${GEMINI_UPLOAD_BASE_URL}?key=${apiKey}`;
  
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'X-Goog-Upload-Protocol': 'resumable',
      'X-Goog-Upload-Command': 'start',
      'X-Goog-Upload-Header-Content-Length': file.size.toString(),
      'X-Goog-Upload-Header-Content-Type': file.type,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      file: {
        display_name: file.name,
      },
    }),
    signal,
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error('Failed to initialize upload:', response.status, errorText);
    throw new Error(`Failed to initialize upload: ${response.status}`);
  }

  const uploadUrl = response.headers.get('X-Goog-Upload-URL');
  if (!uploadUrl) {
    throw new Error('No upload URL returned from initialization');
  }

  return uploadUrl;
}

/**
 * Step 2: Upload file in chunks
 * Uses streaming to avoid loading entire file into memory
 */
async function uploadChunks(
  uploadUrl: string,
  file: File,
  onProgress: (progress: UploadProgress) => void,
  signal?: AbortSignal
): Promise<UploadResult> {
  const totalBytes = file.size;
  const totalChunks = Math.ceil(totalBytes / CHUNK_SIZE);
  let bytesUploaded = 0;

  for (let chunkIndex = 0; chunkIndex < totalChunks; chunkIndex++) {
    if (signal?.aborted) {
      throw new Error(ERROR_IDS.OPERATION_CANCELLED);
    }

    const start = chunkIndex * CHUNK_SIZE;
    const end = Math.min(start + CHUNK_SIZE, totalBytes);
    const chunkSize = end - start;
    const isLastChunk = chunkIndex === totalChunks - 1;

    // Read chunk from file (doesn't load entire file into memory)
    const chunk = file.slice(start, end);
    const chunkBuffer = await chunk.arrayBuffer();

    // Retry logic for each chunk
    let lastError: Error | null = null;
    for (let retry = 0; retry <= MAX_RETRIES; retry++) {
      try {
        const command = isLastChunk ? 'upload, finalize' : 'upload';
        
        const response = await fetch(uploadUrl, {
          method: 'POST',
          headers: {
            'X-Goog-Upload-Command': command,
            'X-Goog-Upload-Offset': start.toString(),
            'Content-Length': chunkSize.toString(),
            'Content-Type': 'application/octet-stream',
          },
          body: chunkBuffer,
          signal,
        });

        if (!response.ok) {
          const errorText = await response.text();
          throw new Error(`Chunk upload failed: ${response.status} - ${errorText}`);
        }

        bytesUploaded = end;

        // Update progress
        const percentage = Math.round((bytesUploaded / totalBytes) * 80); // Reserve 20% for processing
        onProgress({
          phase: 'uploading',
          message: `Uploading ${formatBytes(bytesUploaded)} of ${formatBytes(totalBytes)}...`,
          percentage,
          bytesUploaded,
          totalBytes,
          currentChunk: chunkIndex + 1,
          totalChunks,
        });

        // If this is the last chunk, parse the response for file info
        if (isLastChunk) {
          const result = await response.json();
          return {
            fileUri: result.file?.uri || result.uri,
            fileName: result.file?.name || result.name,
            mimeType: result.file?.mimeType || file.type,
            state: result.file?.state || 'PROCESSING',
          };
        }

        break; // Success, move to next chunk
      } catch (error) {
        lastError = error as Error;
        
        if (signal?.aborted) {
          throw new Error(ERROR_IDS.OPERATION_CANCELLED);
        }

        if (retry < MAX_RETRIES) {
          const delay = INITIAL_RETRY_DELAY_MS * Math.pow(2, retry);
          console.warn(`Chunk ${chunkIndex + 1} failed, retrying in ${delay}ms...`, error);
          onProgress({
            phase: 'uploading',
            message: `Retrying chunk ${chunkIndex + 1}/${totalChunks}...`,
            percentage: Math.round((bytesUploaded / totalBytes) * 80),
            bytesUploaded,
            totalBytes,
            currentChunk: chunkIndex + 1,
            totalChunks,
          });
          await sleep(delay);
        }
      }
    }

    if (lastError) {
      throw lastError;
    }
  }

  throw new Error('Upload completed without finalization response');
}

/**
 * Step 3: Poll for file processing completion
 */
async function waitForProcessing(
  apiKey: string,
  fileName: string,
  onProgress: (progress: UploadProgress) => void,
  signal?: AbortSignal
): Promise<string> {
  const funMessages = [
    "Processing video in AI workspace...",
    "Analyzing video structure...",
    "Time to grab some coffee...",
    "Almost there...",
    "Still processing large file...",
    "Patience is a virtue...",
  ];
  
  let messageIndex = 0;
  let pollCount = 0;
  const maxPolls = 300; // 5 minutes max (at 1 second intervals)

  while (pollCount < maxPolls) {
    if (signal?.aborted) {
      throw new Error(ERROR_IDS.OPERATION_CANCELLED);
    }

    const url = `https://generativelanguage.googleapis.com/v1beta/${fileName}?key=${apiKey}`;
    const response = await fetch(url, { signal });
    
    if (!response.ok) {
      throw new Error(`Failed to check file status: ${response.status}`);
    }

    const fileInfo = await response.json();
    
    if (fileInfo.state === 'ACTIVE') {
      return fileInfo.uri;
    }

    if (fileInfo.state === 'FAILED') {
      throw new Error('File processing failed on Gemini server');
    }

    // Still processing
    const message = funMessages[messageIndex % funMessages.length];
    onProgress({
      phase: 'processing',
      message,
      percentage: 80 + Math.min(pollCount / 2, 19), // Slowly increase from 80 to 99
      bytesUploaded: 0,
      totalBytes: 0,
    });

    messageIndex++;
    pollCount++;
    await sleep(1000);
  }

  throw new Error('File processing timed out');
}

// ═══════════════════════════════════════════════════════════════════════════════
// MAIN EXPORT
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Upload a large file to Gemini using resumable upload protocol
 * 
 * This handles files of any size by:
 * 1. Initializing a resumable upload session
 * 2. Uploading in 8MB chunks (prevents browser memory issues)
 * 3. Polling until processing is complete
 * 
 * @param options Upload options including file, API key, and progress callback
 * @returns The Gemini file URI to use in generateContent calls
 */
export async function uploadLargeFileToGemini(options: UploadOptions): Promise<string> {
  const { apiKey, file, onProgress, signal } = options;

  try {
    // Phase 1: Initialize
    onProgress({
      phase: 'initializing',
      message: 'Initializing secure upload...',
      percentage: 2,
      bytesUploaded: 0,
      totalBytes: file.size,
    });

    const uploadUrl = await initializeResumableUpload(apiKey, file, signal);

    // Phase 2: Upload chunks
    onProgress({
      phase: 'uploading',
      message: 'Starting chunked upload...',
      percentage: 5,
      bytesUploaded: 0,
      totalBytes: file.size,
      currentChunk: 0,
      totalChunks: Math.ceil(file.size / CHUNK_SIZE),
    });

    const uploadResult = await uploadChunks(uploadUrl, file, onProgress, signal);

    // Phase 3: Wait for processing (if needed)
    if (uploadResult.state === 'PROCESSING') {
      const finalUri = await waitForProcessing(apiKey, uploadResult.fileName, onProgress, signal);
      
      onProgress({
        phase: 'complete',
        message: 'Upload complete. Ready for analysis.',
        percentage: 100,
        bytesUploaded: file.size,
        totalBytes: file.size,
      });

      return finalUri;
    }

    onProgress({
      phase: 'complete',
      message: 'Upload complete. Ready for analysis.',
      percentage: 100,
      bytesUploaded: file.size,
      totalBytes: file.size,
    });

    return uploadResult.fileUri;

  } catch (error) {
    console.error('Large file upload failed:', error);
    
    onProgress({
      phase: 'error',
      message: error instanceof Error ? error.message : 'Upload failed',
      percentage: 0,
      bytesUploaded: 0,
      totalBytes: file.size,
    });

    if (error instanceof Error && error.message === ERROR_IDS.OPERATION_CANCELLED) {
      throw error;
    }

    throw new Error(ERROR_IDS.UPLOAD_FAIL);
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// FALLBACK: Simple upload for small files (< 20MB)
// ═══════════════════════════════════════════════════════════════════════════════

const SIMPLE_UPLOAD_THRESHOLD = 20 * 1024 * 1024; // 20MB

/**
 * Smart upload that chooses the best method based on file size
 * - Small files (< 20MB): Use simple multipart upload (faster)
 * - Large files (>= 20MB): Use resumable chunked upload (reliable)
 */
export async function smartUploadToGemini(options: UploadOptions): Promise<string> {
  const { file } = options;

  if (file.size < SIMPLE_UPLOAD_THRESHOLD) {
    // Use the original simple upload for small files
    return uploadSmallFile(options);
  }

  // Use chunked resumable upload for large files
  return uploadLargeFileToGemini(options);
}

async function uploadSmallFile(options: UploadOptions): Promise<string> {
  const { apiKey, file, onProgress, signal } = options;

  onProgress({
    phase: 'uploading',
    message: 'Uploading file...',
    percentage: 10,
    bytesUploaded: 0,
    totalBytes: file.size,
  });

  // Simple multipart upload for small files
  const url = `${GEMINI_UPLOAD_BASE_URL}?key=${apiKey}`;
  
  const formData = new FormData();
  formData.append('file', file);
  formData.append('metadata', JSON.stringify({
    file: { display_name: file.name }
  }));

  const response = await fetch(url, {
    method: 'POST',
    body: formData,
    signal,
  });

  if (!response.ok) {
    throw new Error(`Upload failed: ${response.status}`);
  }

  const result = await response.json();
  const fileName = result.file?.name || result.name;

  onProgress({
    phase: 'processing',
    message: 'Processing file...',
    percentage: 80,
    bytesUploaded: file.size,
    totalBytes: file.size,
  });

  // Wait for processing
  const finalUri = await waitForProcessing(apiKey, fileName, onProgress, signal);

  onProgress({
    phase: 'complete',
    message: 'Upload complete.',
    percentage: 100,
    bytesUploaded: file.size,
    totalBytes: file.size,
  });

  return finalUri;
}
