
import { GoogleGenAI, Type } from "@google/genai";
import type { 
  AnalysisResult, 
  Synopsis, 
  SynopsisConfig, 
  Bio, 
  GraphicsAnalysisResult,
  SpeciesSighting,
  TranscriptionResult,
  Shot
} from '../types';
import { ERROR_IDS } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// ═══════════════════════════════════════════════════════════════════════════════
// UTILITY FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════════

function safeJsonParse<T>(jsonString: string): T {
  try {
    const cleanString = jsonString.trim().replace(/^```(json)?|```$/g, '');
    if (!cleanString) {
      throw new Error(ERROR_IDS.INVALID_API_RESPONSE);
    }
    return JSON.parse(cleanString);
  } catch (e) {
    console.error("Failed to parse JSON response:", jsonString, e);
    throw new Error(ERROR_IDS.INVALID_API_RESPONSE);
  }
}

function formatDuration(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) return "00:00:00";
  const totalSeconds = Math.floor(seconds);
  const h = Math.floor(totalSeconds / 3600), m = Math.floor((totalSeconds % 3600) / 60), s = totalSeconds % 60;
  return [h, m, s].map(v => String(v).padStart(2, '0')).join(':');
}

// ═══════════════════════════════════════════════════════════════════════════════
// FILE UPLOAD MANAGEMENT
// ═══════════════════════════════════════════════════════════════════════════════

import { smartUploadToGemini, type UploadProgress } from './uploadService';

// Threshold for using chunked upload (files >= 50MB use chunked)
const CHUNKED_UPLOAD_THRESHOLD = 50 * 1024 * 1024;

/**
 * Upload a file to Gemini for analysis
 * 
 * Automatically chooses the best upload method:
 * - Small files (< 50MB): SDK's built-in upload (simpler, faster)
 * - Large files (>= 50MB): Chunked resumable upload (handles multi-GB files)
 */
export const uploadFileToGemini = async (
  file: File,
  progressCallback: (message: string, percentage: number) => void,
  signal?: AbortSignal
): Promise<string> => {
  
  // For large files, use the robust chunked upload
  if (file.size >= CHUNKED_UPLOAD_THRESHOLD) {
    console.log(`Large file detected (${(file.size / (1024 * 1024)).toFixed(1)}MB), using chunked upload...`);
    
    return smartUploadToGemini({
      apiKey: process.env.API_KEY || '',
      file,
      onProgress: (progress: UploadProgress) => {
        progressCallback(progress.message, progress.percentage);
      },
      signal,
    });
  }

  // For smaller files, use the SDK's simpler upload
  try {
    if (signal?.aborted) throw new Error(ERROR_IDS.OPERATION_CANCELLED);
    
    progressCallback('Initiating secure upload...', 5);
    
    const uploadResult = await ai.files.upload({
      file: file,
      config: { 
        displayName: file.name,
        mimeType: file.type 
      }
    });

    progressCallback('Processing file in AI Workspace...', 50);

    let fileState = uploadResult.state;
    let fileUri = uploadResult.uri;
    const fileName = uploadResult.name; // This is the ID, e.g. files/123

    const funMessages = [
        "Time to go grab some coffee...",
        "Now is the time for your long awaited bathroom break...",
        "Go chat with someone and hone your social skills...",
        "Call someone and say something nice...",
        "Clean up the mess on your desk...",
        "Maybe drink some water...",
        "Processing file in AI Workspace..."
    ];
    let messageIndex = 0;

    // Poll until active
    while (fileState === 'PROCESSING') {
      if (signal?.aborted) throw new Error(ERROR_IDS.OPERATION_CANCELLED);
      
      progressCallback(funMessages[messageIndex % funMessages.length], 50);
      messageIndex++;
      await new Promise(resolve => setTimeout(resolve, 4000));
      const currentFile = await ai.files.get({ name: fileName });
      fileState = currentFile.state;
      if (fileState === 'FAILED') {
        throw new Error('File processing failed on Gemini server.');
      }
    }

    progressCallback('Upload complete. Ready for analysis.', 100);
    return fileUri;
  } catch (error) {
    // Log the full error details for debugging large file failures
    console.error("Gemini File API Upload Failed:", error);
    if (error instanceof Error) {
        console.error("Error details:", error.message, error.stack);
    }
    throw new Error(ERROR_IDS.UPLOAD_FAIL);
  }
};

// ═══════════════════════════════════════════════════════════════════════════════
// SYNOPSIS GENERATION
// ═══════════════════════════════════════════════════════════════════════════════

export const analyzeVideoContent = async (
  fileUri: string,
  mimeType: string,
  signal: AbortSignal,
  progressCallback: (message: string, percentage: number) => void
): Promise<AnalysisResult> => {

  try {
    if (signal.aborted) throw new Error(ERROR_IDS.OPERATION_CANCELLED);
    progressCallback('Analyzing video content...', 30);

    const prompt = `
      You are an expert video analysis AI. Analyze the provided video file.
      Your task is to synthesize all information into a final, cohesive analysis in JSON format.
      - Transcribe spoken words if present.
      - Summarize the entire video in one sentence.
      - Create a single, chronological list of the most important key events.
      - Infer any potential dialogue or important sounds based on visual cues if audio is unclear.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [{
        role: 'user',
        parts: [
          { fileData: { fileUri: fileUri, mimeType: mimeType } },
          { text: prompt }
        ]
      }],
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING, description: "A brief, one-sentence summary of the video's content." },
            events: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  timestamp: { type: Type.STRING, description: "Approximate time or sequence of the event (e.g., '00:05', 'Beginning', 'Middle')." },
                  description: { type: Type.STRING, description: "A detailed description of what is happening in the event." },
                },
                required: ['timestamp', 'description'],
              },
            },
            inferred_dialogue: { type: Type.STRING, description: "An inferred transcription of what might be said, based on visual cues." },
            transcription: { type: Type.STRING, description: "A transcription of the spoken content from the audio track. If no audio was provided, state that." },
          },
          required: ['summary', 'events', 'inferred_dialogue', 'transcription'],
        },
      },
    });

    if (signal.aborted) throw new Error(ERROR_IDS.OPERATION_CANCELLED);
    return safeJsonParse<AnalysisResult>(response.text);

  } catch (error) {
    console.error("Error analyzing video with Gemini:", error);
    if (error instanceof Error && error.message === ERROR_IDS.OPERATION_CANCELLED) throw error;
    throw new Error(ERROR_IDS.ANALYSIS_FAIL);
  }
};

export const generateSynopsisFromAnalysis = async (
  analysis: AnalysisResult,
  writer: string,
  director: string,
  language: string,
  videoTitle: string,
  keywords: string,
  signal: AbortSignal,
  synopsisConfig: SynopsisConfig
): Promise<Synopsis> => {
  if (signal.aborted) throw new Error(ERROR_IDS.OPERATION_CANCELLED);

  try {
      const prompt = `
          You are a master screenwriter and film marketing expert. Your task is to transform raw video analysis data into a compelling, professional film synopsis and marketing profile. Your writing should be evocative and ready for a pitch deck.

          **Content to Generate:**
          1.  **Title:** A creative, fitting title for the video.
          2.  **One Line (Logline):** A single, powerful sentence capturing the core story.
          3.  **Paragraph (Summary):** An engaging paragraph setting the scene and narrative.
          4.  **Full Synopsis:** A detailed, multi-paragraph synopsis with a clear beginning, middle, and end.
          5.  **Key Themes:** A concise summary of the central themes and ideas.
          6.  **Target Audience:** A description of the ideal viewer for this content.

          **Your Constraints:**
          - **Language:** Generate all content in: ${language}.
          - **Title:** Maximum ${synopsisConfig.titleMaxChars} characters.
          - **One Line (Logline):** Approximately ${synopsisConfig.loglineMaxWords} words.
          - **Paragraph (Summary):** Approximately ${synopsisConfig.summaryMaxWords} words.
          - **Key Themes:** Approximately ${synopsisConfig.keyThemesMaxWords} words.
          - **Target Audience:** Approximately ${synopsisConfig.targetAudienceMaxWords} words.
          - **Full Synopsis:** No strict length limit, but should be comprehensive and well-structured.

${keywords ? `
          **Guiding Keywords:** Use these to guide the tone and focus: ${keywords}.` : ''}

          **Video Analysis Data:**
          - Transcription: "${analysis.transcription}"
          - Summary: "${analysis.summary}"
          - Key Events: ${JSON.stringify(analysis.events.map(e => e.description))}
          - Inferred Dialogue: "${analysis.inferred_dialogue}"

          Your output must be a single JSON object with keys: "title", "oneLine", "paragraph", "fullSynopsis", "keyThemes", "targetAudience".
      `;

      if (signal.aborted) throw new Error(ERROR_IDS.OPERATION_CANCELLED);

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: [{ parts: [{ text: prompt }] }],
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              oneLine: { type: Type.STRING },
              paragraph: { type: Type.STRING },
              fullSynopsis: { type: Type.STRING },
              keyThemes: { type: Type.STRING },
              targetAudience: { type: Type.STRING }
            },
            required: ['title', 'oneLine', 'paragraph', 'fullSynopsis', 'keyThemes', 'targetAudience']
          }
        }
      });
      
      const aiGeneratedContent = safeJsonParse<any>(response.text);

      const resultJson: Synopsis = {
        ...aiGeneratedContent,
        writtenBy: writer,
        directedBy: director,
      };

      return resultJson;

  } catch (error) {
    console.error("Error generating synopsis with Gemini:", error);
    if (error instanceof Error && error.message === ERROR_IDS.OPERATION_CANCELLED) {
      throw error;
    }
    throw new Error(ERROR_IDS.SYNOPSIS_FAIL);
  }
};

// ═══════════════════════════════════════════════════════════════════════════════
// BIO GENERATION
// ═══════════════════════════════════════════════════════════════════════════════

export const extractTalentFromVideo = async (fileUri: string, mimeType: string): Promise<string[]> => {
    const prompt = `Analyze the video. Identify any people introduced with text on the screen, commonly known as a 'lower third'. Extract their full names. Return the result as a valid JSON object with a single key 'names' which is an array of strings. For example: {"names": ["Lisa Hywood", "Ellen Connelly"]}. If no names are found, return an empty array. Do not include titles or roles, only full names.`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash', // Flash is good for extraction
            contents: { 
              role: 'user',
              parts: [
                { fileData: { fileUri, mimeType } },
                { text: prompt }
              ] 
            },
            config: { temperature: 0.1, responseMimeType: 'application/json' },
        });

        const parsed = safeJsonParse<{ names: any }>(response.text);
        if (parsed.names && Array.isArray(parsed.names)) {
            return [...new Set<string>(parsed.names.filter((name: any): name is string => typeof name === 'string' && name.trim() !== ''))];
        }
        return [];
    } catch (e) {
        console.error('Error analyzing video for talent:', e);
        throw new Error('An API error occurred while analyzing the video for talent.');
    }
};

interface BioResponse {
  fullName: string;
  title: string;
  biography: string;
}

export const generateBio = async (talentName: string, context: string, language: string): Promise<BioResponse> => {
  const prompt = `You are a professional biographer. Research and write a professional biography for the person named "${talentName}". Their specific context or role is: "${context}". Use this context to find the correct person. The biography should be engaging, accurate, and suitable for promotional materials. The entire response must be written in ${language}. Your output must be a single, valid JSON object. If you find sufficient information, the JSON should have "fullName", "title", and "biography" keys. If you cannot find sufficient information, return: {"fullName": "${talentName}", "title": "Information Not Found", "biography": "Could not find sufficient information."}.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-pro',
      contents: prompt,
      config: { 
        tools: [{ googleSearch: {} }], 
        temperature: 0.7,
        responseMimeType: 'application/json'
      },
    });

    const parsed = safeJsonParse<any>(response.text);
    return parsed as BioResponse;
  } catch (e) {
    console.error(`Error generating bio for ${talentName}:`, e);
    throw new Error(`Failed to generate biography for "${talentName}".`);
  }
};

// ═══════════════════════════════════════════════════════════════════════════════
// GRAPHICS & LOWER THIRDS ANALYSIS
// ═══════════════════════════════════════════════════════════════════════════════

export async function analyzeGraphicsAndLowerThirds(
  fileUri: string, mimeType: string, duration: number, filmTitle: string
): Promise<GraphicsAnalysisResult> {
  
  const prompt = `You are a post-production assistant with excellent OCR skills. Analyze the provided video file. Your task is to identify and transcribe all on-screen graphics (e.g., title cards, location indicators) and lower thirds (text identifying a person or place, usually at the bottom of the screen). Be extremely accurate. Output must be a single, valid JSON object strictly adhering to the schema.`;
  
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: { 
      role: 'user',
      parts: [
        { fileData: { fileUri, mimeType } },
        { text: prompt }
      ] 
    },
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          programTitle: { type: Type.STRING },
          runtime: { type: Type.STRING },
          graphics: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT, properties: { 
                description: { type: Type.STRING }, 
                timecodeIn: { type: Type.STRING }, 
                timecodeOut: { type: Type.STRING },
                cleanTimecodeIn: { type: Type.STRING },
                cleanTimecodeOut: { type: Type.STRING },
              },
              required: ["description", "timecodeIn", "timecodeOut"],
            },
          },
          lowerThirds: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT, properties: { 
                text: { type: Type.STRING }, 
                timecodeIn: { type: Type.STRING }, 
                timecodeOut: { type: Type.STRING } 
              },
              required: ["text", "timecodeIn", "timecodeOut"],
            },
          },
        },
        required: ["programTitle", "runtime", "graphics", "lowerThirds"],
      },
      temperature: 0.2,
    }
  });

  const parsedResult = safeJsonParse<GraphicsAnalysisResult>(response.text);
  parsedResult.programTitle = filmTitle;
  parsedResult.runtime = formatDuration(duration);
  return parsedResult;
}

// ═══════════════════════════════════════════════════════════════════════════════
// FAUNA FINDER
// ═══════════════════════════════════════════════════════════════════════════════

export async function analyzeVideoForSpecies(
  fileUri: string, mimeType: string, primaryLanguage: string, secondaryLanguage: string
): Promise<Omit<SpeciesSighting, 'id'|'thumbnail'>[]> {
    const prompt = `Analyze this video. Your task is to identify **every single animal sighting**. Do not summarize or group them. If the same animal appears in multiple shots, create a separate entry for each sighting. 
    For each sighting, provide: 
    - 'commonName': The common name in ${primaryLanguage}.
    - 'latinName': The scientific name.
    - 'germanName': The common name in ${secondaryLanguage}.
    - 'timecode': The EXACT timecode of the frame where the animal is seen.
    - 'category': A simple category (e.g., "Mammal", "Bird", "Insect", "Fish").
    - 'confidence': A score from 0.0 to 1.0 indicating your confidence in the identification.
    The final output must be a JSON array of objects.`;
    
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: { 
          role: 'user',
          parts: [
            { fileData: { fileUri, mimeType } },
            { text: prompt }
          ] 
        },
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    commonName: { type: Type.STRING },
                    latinName: { type: Type.STRING },
                    germanName: { type: Type.STRING },
                    timecode: { type: Type.STRING },
                    category: { type: Type.STRING },
                    confidence: { type: Type.NUMBER },
                  },
                  required: ["commonName", "latinName", "timecode", "category", "confidence"],
                },
            },
        },
    });
    
    return safeJsonParse<Omit<SpeciesSighting, 'id'|'thumbnail'>[]>(response.text);
}

// ═══════════════════════════════════════════════════════════════════════════════
// TRANSCRIPTION
// ═══════════════════════════════════════════════════════════════════════════════

export async function transcribeMedia(
  fileUri: string, mimeType: string, signal: AbortSignal, progressCallback: (message: string, percentage: number) => void
): Promise<Omit<TranscriptionResult, 'speakerMap'>> {
  
  progressCallback('Transcribing audio with AI...', 50);

  const prompt = `You are an expert audio transcription AI. Transcribe the provided media, identifying different speakers as SPEAKER_00, SPEAKER_01, etc. Provide the output as a time-coded transcript in a JSON object adhering to the schema.`;
  
  if (signal.aborted) throw new Error(ERROR_IDS.OPERATION_CANCELLED);

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: [{ 
      role: 'user',
      parts: [
        { fileData: { fileUri, mimeType } },
        { text: prompt }
      ] 
    }],
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          segments: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                startTime: { type: Type.STRING, description: "Start time in HH:MM:SS.mmm format." },
                endTime: { type: Type.STRING, description: "End time in HH:MM:SS.mmm format." },
                speaker: { type: Type.STRING, description: "Speaker identifier (e.g., SPEAKER_00)." },
                transcript: { type: Type.STRING, description: "Transcribed text." },
              },
              required: ['startTime', 'endTime', 'speaker', 'transcript'],
            },
          },
        },
        required: ['segments'],
      },
    },
  });

  if (signal.aborted) throw new Error(ERROR_IDS.OPERATION_CANCELLED);
  progressCallback('Finalizing transcription...', 95);

  return safeJsonParse<Omit<TranscriptionResult, 'speakerMap'>>(response.text);
}

// ═══════════════════════════════════════════════════════════════════════════════
// SHOT LIST GENERATION
// ═══════════════════════════════════════════════════════════════════════════════

export async function generateShotList(
  fileUri: string, mimeType: string, language: string, frameRate: number, signal: AbortSignal, progressCallback: (message: string, percentage: number) => void
): Promise<Omit<Shot, 'nr' | 'thumbnail'>[]> {

  progressCallback('Analyzing video for shot detection...', 10);

  const prompt = `You are an expert film editor analyzing this video to identify distinct shots. A shot change is defined by any change in camera angle, subject framing, or location. Be very granular and sensitive to subtle changes. For each shot you identify, provide a description, action, and audio cues in ${language}. Provide timecodes in HH:MM:SS:FF format based on a ${frameRate}fps frame rate. The final output must be a valid JSON object adhering to the schema.`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-pro',
      contents: { 
        role: 'user',
        parts: [
          { fileData: { fileUri, mimeType } },
          { text: prompt }
        ] 
      },
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT, properties: {
            shots: {
              type: Type.ARRAY, items: {
                type: Type.OBJECT, properties: {
                  tcIn: { type: Type.STRING, description: "Timecode IN in HH:MM:SS:FF format." },
                  tcOut: { type: Type.STRING, description: "Timecode OUT in HH:MM:SS:FF format." },
                  duration: { type: Type.STRING, description: "Duration in HH:MM:SS:FF format." },
                  description: { type: Type.STRING, description: `Visual description in ${language}.` },
                  action: { type: Type.STRING, description: `Main action in ${language}.` },
                  audio: { type: Type.STRING, description: `Audio description in ${language}.` },
                }, required: ['tcIn', 'tcOut', 'duration', 'description', 'action', 'audio'],
              },
            },
          }, required: ['shots'],
        },
      },
    });

    if (signal.aborted) throw new Error(ERROR_IDS.OPERATION_CANCELLED);
    const result = safeJsonParse<{ shots: Omit<Shot, 'nr' | 'thumbnail'>[] }>(response.text);
    return result.shots;
}
