
import { parseTimecode } from './tableUtils';

interface Task {
  id: string;
  videoUrl: string;
  time: number;
  resolve: (dataUrl: string) => void;
  reject: (err: any) => void;
}

class ThumbnailGenerator {
  private stack: Task[] = [];
  private isProcessing = false;
  private videoElement: HTMLVideoElement | null = null;
  private canvasElement: HTMLCanvasElement | null = null;
  private currentVideoUrl: string | null = null;

  constructor() {
    if (typeof document !== 'undefined') {
      this.videoElement = document.createElement('video');
      this.videoElement.muted = true;
      this.videoElement.crossOrigin = 'anonymous';
      this.videoElement.preload = 'auto';
      this.videoElement.playsInline = true;
      
      this.canvasElement = document.createElement('canvas');
    }
  }

  public generateThumbnail(videoUrl: string, timecode: string | number): Promise<string> {
    const time = typeof timecode === 'string' ? parseTimecode(timecode) : timecode;
    const id = `${videoUrl}-${time}`;

    // Deduplicate: If request exists, remove it (we will re-add at the top of stack)
    this.stack = this.stack.filter(t => t.id !== id);

    return new Promise((resolve, reject) => {
      // LIFO: Unshift (add to front) to prioritize most recent request (scrolling down)
      this.stack.unshift({ id, videoUrl, time, resolve, reject });
      this.processQueue();
    });
  }

  private async processQueue() {
    if (this.isProcessing || this.stack.length === 0 || !this.videoElement || !this.canvasElement) return;

    this.isProcessing = true;
    const task = this.stack.shift(); // Get newest task

    if (!task) {
      this.isProcessing = false;
      return;
    }

    try {
      // 1. Load Source
      if (this.currentVideoUrl !== task.videoUrl) {
        this.videoElement.src = task.videoUrl;
        this.currentVideoUrl = task.videoUrl;
        await new Promise((resolve, reject) => {
          const onLoaded = () => { cleanup(); resolve(true); };
          const onError = () => { cleanup(); reject(new Error('Video load failed')); };
          const cleanup = () => {
             this.videoElement?.removeEventListener('loadeddata', onLoaded);
             this.videoElement?.removeEventListener('error', onError);
          };
          this.videoElement?.addEventListener('loadeddata', onLoaded);
          this.videoElement?.addEventListener('error', onError);
        });
      }

      // 2. Seek to specific time
      this.videoElement.currentTime = task.time;
      
      // 3. Wait for seek
      await new Promise((resolve, reject) => {
        const timeoutId = setTimeout(() => {
          cleanup();
          resolve(true); // Attempt capture anyway on timeout
        }, 2000);

        const onSeeked = () => {
           cleanup();
           resolve(true);
        };

        const onError = () => {
           cleanup();
           reject(new Error('Seek failed'));
        };
        
        const cleanup = () => {
           clearTimeout(timeoutId);
           this.videoElement?.removeEventListener('seeked', onSeeked);
           this.videoElement?.removeEventListener('error', onError);
        };

        this.videoElement?.addEventListener('seeked', onSeeked);
        this.videoElement?.addEventListener('error', onError);
      });

      // 4. Capture
      const ctx = this.canvasElement.getContext('2d');
      if (ctx) {
        const videoRatio = this.videoElement.videoWidth / this.videoElement.videoHeight;
        const targetWidth = 240; // Reduced size for performance
        const targetHeight = targetWidth / videoRatio;

        this.canvasElement.width = targetWidth;
        this.canvasElement.height = targetHeight;
        
        ctx.drawImage(this.videoElement, 0, 0, targetWidth, targetHeight);
        const dataUrl = this.canvasElement.toDataURL('image/jpeg', 0.6); // Lower quality for speed
        task.resolve(dataUrl);
      } else {
        task.reject(new Error('Canvas context failed'));
      }

    } catch (error) {
      console.warn('Thumbnail generation failed:', error);
      // Transparent pixel fallback
      task.resolve('data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7');
    } finally {
      this.isProcessing = false;
      // Use requestAnimationFrame for smoother UI yielding
      requestAnimationFrame(() => this.processQueue());
    }
  }
}

export const thumbnailGenerator = new ThumbnailGenerator();
