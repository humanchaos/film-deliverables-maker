/**
 * Utility functions for table formatting and data export
 * Optimized for professional production document formats
 */

/**
 * Parse timecode string to seconds
 * Supports formats: HH:MM:SS, HH:MM:SS:FF, HH:MM:SS.mmm
 */
export function parseTimecode(tc: string, frameRate: number = 25): number {
  const parts = tc.split(/[:.]/);
  
  if (parts.length === 3) {
    // Handle HH:MM:SS
    const [hours, minutes, seconds] = parts;
    return parseInt(hours) * 3600 + parseInt(minutes) * 60 + parseFloat(seconds);
  } else if (parts.length === 4) {
    if (tc.includes('.')) {
      // Handle HH:MM:SS.mmm
      const [hours, minutes, seconds, milliseconds] = parts;
      return parseInt(hours) * 3600 + parseInt(minutes) * 60 + parseInt(seconds) + parseInt(milliseconds) / 1000;
    } else {
      // Handle HH:MM:SS:FF (with frames)
      const [hours, minutes, seconds, frames] = parts;
      return parseInt(hours) * 3600 + parseInt(minutes) * 60 + parseInt(seconds) + parseInt(frames) / frameRate;
    }
  }
  
  return 0;
}

/**
 * Convert seconds to timecode string
 */
export function secondsToTimecode(seconds: number, frameRate: number = 25, includeFrames: boolean = true): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  
  const base = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  
  if (includeFrames) {
    const frames = Math.floor((seconds % 1) * frameRate);
    return `${base}:${frames.toString().padStart(2, '0')}`;
  }
  
  const milliseconds = Math.floor((seconds % 1) * 1000);
  return `${base}.${milliseconds.toString().padStart(3, '0')}`;
}

/**
 * Generate professional table format with box drawing characters
 */
export function generateTableText(
  title: string,
  headers: string[],
  rows: string[][],
  columnWidths: number[]
): string {
  const colCount = headers.length;
  
  // Top border
  let output = '┌' + columnWidths.map(w => '─'.repeat(w + 2)).join('┬') + '┐\n';
  
  // Headers
  output += '│' + headers.map((h, i) => ` ${h.padEnd(columnWidths[i])} `).join('│') + '│\n';
  
  // Header separator
  output += '├' + columnWidths.map(w => '─'.repeat(w + 2)).join('┼') + '┤\n';
  
  // Data rows
  rows.forEach(row => {
    output += '│' + row.map((cell, i) => {
      const content = cell.substring(0, columnWidths[i]);
      return ` ${content.padEnd(columnWidths[i])} `;
    }).join('│') + '│\n';
  });
  
  // Bottom border
  output += '└' + columnWidths.map(w => '─'.repeat(w + 2)).join('┴') + '┘\n';
  
  return output;
}

/**
 * Escape CSV cell content
 */
export function escapeCsvCell(content: any): string {
  const stringContent = String(content ?? '');
  // Escape quotes and wrap in quotes if contains comma, quote, or newline
  if (stringContent.includes(',') || stringContent.includes('"') || stringContent.includes('\n')) {
    return `"${stringContent.replace(/"/g, '""')}"`;
  }
  return stringContent;
}

/**
 * Generate CSV from data
 */
export function generateCSV(headers: string[], rows: any[][]): string {
  const csvHeaders = headers.map(escapeCsvCell).join(',');
  const csvRows = rows.map(row => row.map(escapeCsvCell).join(',')).join('\n');
  return `${csvHeaders}\n${csvRows}`;
}

/**
 * Download content as file
 */
export function downloadFile(content: string, filename: string, mimeType: string = 'text/plain'): void {
  const blob = new Blob([content], { type: `${mimeType};charset=utf-8;` });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  
  // Cleanup
  setTimeout(() => URL.revokeObjectURL(url), 100);
}

/**
 * Copy text to clipboard
 */
export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (err) {
    // Fallback for older browsers
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    
    try {
      document.execCommand('copy');
      document.body.removeChild(textArea);
      return true;
    } catch (e) {
      document.body.removeChild(textArea);
      return false;
    }
  }
}

/**
 * Format file size for display
 */
export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
}

/**
 * Format duration in seconds to readable string
 */
export function formatDuration(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  
  if (hours > 0) {
    return `${hours}h ${minutes}m ${secs}s`;
  } else if (minutes > 0) {
    return `${minutes}m ${secs}s`;
  }
  return `${secs}s`;
}

/**
 * Sanitize filename for cross-platform compatibility
 */
export function sanitizeFilename(filename: string): string {
  // Remove or replace invalid characters
  return filename
    .replace(/[<>:"/\\|?*]/g, '_')
    .replace(/\s+/g, '_')
    .replace(/_+/g, '_')
    .substring(0, 255); // Max filename length
}

/**
 * Debounce function for performance optimization
 */
export function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  // Fix: Use ReturnType<typeof setTimeout> for browser compatibility, as NodeJS namespace is not available.
  let timeout: ReturnType<typeof setTimeout> | null = null;
  
  return function executedFunction(...args: Parameters<T>) {
    const later = () => {
      timeout = null;
      func(...args);
    };
    
    if (timeout) clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

/**
 * Chunk array for batch processing
 */
export function chunkArray<T>(array: T[], chunkSize: number): T[][] {
  const chunks: T[][] = [];
  for (let i = 0; i < array.length; i += chunkSize) {
    chunks.push(array.slice(i, i + chunkSize));
  }
  return chunks;
}

/**
 * Compare two timecodes
 * Returns: -1 if a < b, 0 if a === b, 1 if a > b
 */
export function compareTimecodes(a: string, b: string, frameRate: number = 25): number {
  const aSeconds = parseTimecode(a, frameRate);
  const bSeconds = parseTimecode(b, frameRate);
  
  if (aSeconds < bSeconds) return -1;
  if (aSeconds > bSeconds) return 1;
  return 0;
}

/**
 * Get unique items from array by key
 */
export function uniqueBy<T>(array: T[], key: keyof T): T[] {
  const seen = new Set();
  return array.filter(item => {
    const value = item[key];
    if (seen.has(value)) return false;
    seen.add(value);
    return true;
  });
}

/**
 * Group array items by key
 */
export function groupBy<T>(array: T[], key: keyof T): Record<string, T[]> {
  return array.reduce((groups, item) => {
    const groupKey = String(item[key]);
    if (!groups[groupKey]) {
      groups[groupKey] = [];
    }
    groups[groupKey].push(item);
    return groups;
  }, {} as Record<string, T[]>);
}

/**
 * Generate professional document header
 */
export function generateDocumentHeader(
  title: string,
  programTitle: string,
  runtime?: string,
  episodeNumber?: string,
  episodeTitle?: string
): string {
  let header = `${title}\n`;
  header += `${'='.repeat(title.length)}\n\n`;
  header += `Program Title / Programmtitel: ${programTitle}\n`;
  
  if (episodeNumber) {
    header += `Episode Number / Episodennummer: ${episodeNumber}\n`;
  }
  
  if (episodeTitle) {
    header += `Episode Title / Episodentitel: ${episodeTitle}\n`;
  }
  
  if (runtime) {
    header += `Runtime / Programmlänge: ${runtime}\n`;
  }
  
  header += `\n`;
  return header;
}

/**
 * Calculate timecode duration between two timecodes
 */
export function calculateDuration(startTC: string, endTC: string, frameRate: number = 25): string {
  const startSeconds = parseTimecode(startTC, frameRate);
  const endSeconds = parseTimecode(endTC, frameRate);
  const durationSeconds = endSeconds - startSeconds;
  
  return secondsToTimecode(durationSeconds, frameRate);
}

/**
 * Validate timecode format
 */
export function isValidTimecode(tc: string): boolean {
  // Matches HH:MM:SS, HH:MM:SS:FF, or HH:MM:SS.mmm
  const regex = /^([0-9]{2}):([0-5][0-9]):([0-5][0-9])(:([0-9]{2})|\.([0-9]{3}))?$/;
  return regex.test(tc);
}

/**
 * Sort array of items by timecode
 */
export function sortByTimecode<T extends { timecode?: string; tcIn?: string }>(
  items: T[],
  frameRate: number = 25,
  descending: boolean = false
): T[] {
  return [...items].sort((a, b) => {
    const tcA = a.timecode || a.tcIn || '00:00:00';
    const tcB = b.timecode || b.tcIn || '00:00:00';
    const comparison = compareTimecodes(tcA, tcB, frameRate);
    return descending ? -comparison : comparison;
  });
}

/**
 * Memory-efficient batch processor
 */
export async function processBatch<T, R>(
  items: T[],
  batchSize: number,
  processor: (batch: T[]) => Promise<R[]>,
  onProgress?: (completed: number, total: number) => void
): Promise<R[]> {
  const results: R[] = [];
  const chunks = chunkArray(items, batchSize);
  
  for (let i = 0; i < chunks.length; i++) {
    const batchResults = await processor(chunks[i]);
    results.push(...batchResults);
    
    if (onProgress) {
      const completed = Math.min((i + 1) * batchSize, items.length);
      onProgress(completed, items.length);
    }
  }
  
  return results;
}
