
// ═══════════════════════════════════════════════════════════════════════════════
// COMMON TYPES
// ═══════════════════════════════════════════════════════════════════════════════

export type AnalysisMode = 'synopsis' | 'bio' | 'graphics' | 'fauna' | 'transcribe' | 'shotlist';

export enum AppStatus {
  UPLOAD = 'upload',
  UPLOADING = 'uploading',
  PREPARING_VIDEO = 'preparing_video',
  MODE_SELECT = 'mode_select',
  PROCESSING = 'processing',
  RESULTS = 'results',
  HISTORY = 'history', // New status for viewing saved analyses
}

// ═══════════════════════════════════════════════════════════════════════════════
// DATABASE TYPES
// ═══════════════════════════════════════════════════════════════════════════════

export interface SavedAnalysis {
  id?: number;
  type: AnalysisMode;
  fileName: string;
  date: string;
  timestamp: number;
  data: any; // The specific result type (Synopsis, ShotListResult, etc.)
}

// ═══════════════════════════════════════════════════════════════════════════════
// SYNOPSIS TYPES
// ═══════════════════════════════════════════════════════════════════════════════

export interface AnalysisResult {
  summary: string;
  events: {
    timestamp: string;
    description: string;
  }[];
  inferred_dialogue: string;
  transcription: string;
}

export interface PartialAnalysisResult {
  summary: string;
  key_events_and_observations: string[];
}

export interface Synopsis {
  title: string;
  writtenBy: string;
  directedBy: string;
  oneLine: string;
  paragraph: string;
  fullSynopsis: string;
  keyThemes: string;
  targetAudience: string;
}

export interface SynopsisConfig {
  titleMaxChars: number;
  loglineMaxWords: number;
  summaryMaxWords: number;
  keyThemesMaxWords: number;
  targetAudienceMaxWords: number;
}

export const DEFAULT_SYNOPSIS_CONFIG: SynopsisConfig = {
  titleMaxChars: 80,
  loglineMaxWords: 25,
  summaryMaxWords: 150,
  keyThemesMaxWords: 50,
  targetAudienceMaxWords: 40,
};

// ═══════════════════════════════════════════════════════════════════════════════
// BIO TYPES
// ═══════════════════════════════════════════════════════════════════════════════

export interface Bio {
  name: string;
  fullName: string;
  title: string;
  biography: string;
  isLoading?: boolean;
  error?: string;
}

// ═══════════════════════════════════════════════════════════════════════════════
// TRANSCRIPTION TYPES
// ═══════════════════════════════════════════════════════════════════════════════

export interface TranscriptionSegment {
  startTime: string;
  endTime: string;
  speaker: string;
  transcript: string;
}

export interface TranscriptionResult {
  segments: TranscriptionSegment[];
  speakerMap: Record<string, string>; // Maps "SPEAKER_00" to an editable name
}

// ═══════════════════════════════════════════════════════════════════════════════
// SHOT LIST TYPES
// ═══════════════════════════════════════════════════════════════════════════════

export interface Shot {
  nr: number;
  tcIn: string;
  tcOut: string;
  duration: string;
  description: string;
  action: string;
  audio: string;
  thumbnail?: string; // base64 data URL
}

export interface PhotoAnalysisResult {
  description: string;
  action: string;
  audio: string;
}

export interface ShotListResult {
  shots: Shot[];
  videoUrl: string; // The object URL of the video file for preview
  frameRate: number; // The frame rate used for timecode calculations
}


// ═══════════════════════════════════════════════════════════════════════════════
// CONFIGURATION CONSTANTS
// ═══════════════════════════════════════════════════════════════════════════════

export const MAX_FILE_SIZE_MB = 5120; // 5 GB
export const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;
export const SUPPORTED_VIDEO_FORMATS = [
  'video/mp4',
  'video/quicktime',
  'video/x-msvideo',
  'video/mov',
  'video/webm',
  'video/x-matroska'
];
export const MAX_VIDEO_DURATION_SECONDS = 7200; 

export const MAX_FRAMES_SHORT_VIDEO = 100; 
export const MAX_FRAMES_LONG_VIDEO = 200;

// ═══════════════════════════════════════════════════════════════════════════════
// UI MESSAGES
// ═══════════════════════════════════════════════════════════════════════════════

export const PROGRESS_MESSAGES = {
  UPLOADING: 'Uploading file to AI Workspace...',
  PREPARING_VIDEO: 'Preparing video preview...',
  EXTRACTING: 'Preparing analysis context...',
  ANALYZING: 'Analyzing video content with AI...',
  IDENTIFYING_TALENT: 'Identifying talent in video...',
  GENERATING_SYNOPSIS: 'Generating creative synopsis...',
  GENERATING_BIOS: 'Generating biographies...',
  TRANSCRIBING: 'Transcribing audio... This may take a while.',
  GENERATING_SHOTLIST: 'Generating shot list... Analyzing scenes.',
  DEFAULT: 'Processing your video... This may take a few moments.',
};

// ═══════════════════════════════════════════════════════════════════════════════
// ERROR HANDLING
// ═══════════════════════════════════════════════════════════════════════════════

export const ERROR_IDS = {
  FILE_TOO_LARGE: 'FILE_TOO_LARGE',
  FILE_TOO_LARGE_FOR_TRANSCRIPTION: 'FILE_TOO_LARGE_FOR_TRANSCRIPTION',
  UNSUPPORTED_FORMAT: 'UNSUPPORTED_FORMAT',
  NO_FRAMES: 'NO_FRAMES',
  EXTRACTION_TIMEOUT: 'EXTRACTION_TIMEOUT',
  VIDEO_LOAD_FAIL: 'VIDEO_LOAD_FAIL',
  VIDEO_TOO_LONG: 'VIDEO_TOO_LONG',
  AUDIO_EXTRACTION_FAIL: 'AUDIO_EXTRACTION_FAIL',
  ANALYSIS_FAIL: 'ANALYSIS_FAIL',
  INVALID_API_RESPONSE: 'INVALID_API_RESPONSE',
  SYNOPSIS_FAIL: 'SYNOPSIS_FAIL',
  BIO_FAIL: 'BIO_FAIL',
  NO_TALENT_FOUND: 'NO_TALENT_FOUND',
  TRANSCRIPTION_FAIL: 'TRANSCRIPTION_FAIL',
  SHOTLIST_FAIL: 'SHOTLIST_FAIL',
  SCENE_DETECTION_FAIL: 'SCENE_DETECTION_FAIL',
  OPERATION_CANCELLED: 'OPERATION_CANCELLED',
  UPLOAD_FAIL: 'UPLOAD_FAIL',
  UNKNOWN: 'UNKNOWN',
};

export const ERROR_MESSAGES: Record<string, string> = {
  [ERROR_IDS.FILE_TOO_LARGE]: `File is too large. Please select a file smaller than ${MAX_FILE_SIZE_MB / 1024}GB.`,
  [ERROR_IDS.FILE_TOO_LARGE_FOR_TRANSCRIPTION]: 'File is too large for in-browser transcription. Please use a file smaller than 200MB.',
  [ERROR_IDS.UNSUPPORTED_FORMAT]: 'Unsupported file format. Please use MP4, MOV, AVI, WebM, or MKV.',
  [ERROR_IDS.NO_FRAMES]: 'Could not extract any frames. The file might be corrupted or in an unsupported format.',
  [ERROR_IDS.EXTRACTION_TIMEOUT]: 'Frame extraction timed out. The video may be too long or complex for in-browser processing.',
  [ERROR_IDS.VIDEO_LOAD_FAIL]: 'Failed to load video file. It might be corrupt or in an unsupported format.',
  [ERROR_IDS.AUDIO_EXTRACTION_FAIL]: 'Could not extract audio from the file. The file may be silent, corrupt, or use an unsupported audio codec.',
  [ERROR_IDS.ANALYSIS_FAIL]: 'Failed to analyze video content with the AI model.',
  [ERROR_IDS.INVALID_API_RESPONSE]: 'The AI model returned an invalid or empty response. This could be due to content safety filters or a temporary issue. Please try again.',
  [ERROR_IDS.SYNOPSIS_FAIL]: 'Failed to generate a synopsis with the AI model.',
  [ERROR_IDS.BIO_FAIL]: 'Failed to generate biographies with the AI model.',
  [ERROR_IDS.NO_TALENT_FOUND]: 'Could not automatically identify any talent. You can go back and try entering names manually.',
  [ERROR_IDS.VIDEO_TOO_LONG]: `Video is too long.`,
  [ERROR_IDS.TRANSCRIPTION_FAIL]: 'Failed to transcribe the media file with the AI model.',
  [ERROR_IDS.SHOTLIST_FAIL]: 'Failed to generate a shot list with the AI model.',
  [ERROR_IDS.SCENE_DETECTION_FAIL]: 'Failed to detect scenes in the video. The file might be too short or complex.',
  [ERROR_IDS.OPERATION_CANCELLED]: 'The operation was cancelled.',
  [ERROR_IDS.UPLOAD_FAIL]: 'Failed to upload file to AI Workspace. Please check your internet connection and API Key.',
  [ERROR_IDS.UNKNOWN]: 'An unknown error occurred. Please try again.',
};

// ═══════════════════════════════════════════════════════════════════════════════
// GRAPHICS & LOWER THIRDS TYPES
// ═══════════════════════════════════════════════════════════════════════════════

export interface GraphicLogEntry {
  description: string;
  timecodeIn: string;
  timecodeOut: string;
  cleanTimecodeIn?: string;
  cleanTimecodeOut?: string;
  thumbnail?: string; // base64 data URL
}

export interface LowerThirdEntry {
  text: string;
  timecodeIn: string;
  timecodeOut: string;
  thumbnail?: string; // base64 data URL
}

export interface GraphicsAnalysisResult {
  programTitle: string;
  runtime: string;
  graphics: GraphicLogEntry[];
  lowerThirds: LowerThirdEntry[];
}

// ═══════════════════════════════════════════════════════════════════════════════
// FAUNA FINDER TYPES
// ═══════════════════════════════════════════════════════════════════════════════

export interface SpeciesSighting {
  id: string;
  commonName: string;
  latinName: string;
  germanName?: string;
  timecode: string;
  category?: string;
  confidence?: number;
  thumbnail?: string; // base64 data URL
}

export interface ExtractedFrame {
  frameData: string;
  timestamp: number;
  timecode: string;
}

export interface FaunaConfig {
  primaryLanguage: string;
  secondaryLanguage: string;
}

export const DEFAULT_FAUNA_CONFIG: FaunaConfig = {
  primaryLanguage: 'English',
  secondaryLanguage: 'German',
};
