# TMS Clip Analyzer - Complete Edition

A unified, powerful video analysis application with 6 AI-driven analysis modes for comprehensive video content processing.

## 🎯 Overview

This integrated application combines multiple video analysis tools into one seamless experience:

- **Synopsis Generation** - Create professional film synopses
- **Talent Bio Generation** - Generate biographies for on-screen talent
- **Graphics & Lower Thirds Detection** - Identify all on-screen graphics and text overlays
- **Fauna Identification** - Catalog animal species in nature content
- **Audio/Video Transcription** ✨ NEW! - Generate time-coded transcripts with speaker identification
- **Shot List Generation** ✨ NEW! - Create detailed shot-by-shot breakdowns with AI descriptions

## 📋 Complete Feature Set

### 📝 Synopsis Generation
Create professional film synopses with AI analysis

### 👥 Talent Bio Generation
Auto-detect or manually generate professional biographies

### 🎬 Graphics & Lower Thirds Detection
Identify all on-screen graphics with timecode logs

### 🦁 Fauna Identification
Catalog animal species with scientific classifications

### 🎙️ Audio/Video Transcription (NEW!)
Complete time-coded transcription with speaker identification

### 📹 Shot List Generation (NEW!)
Automatic scene detection and AI-generated shot descriptions

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Set API key in .env.local
echo "GEMINI_API_KEY=your_key_here" > .env.local

# Run development server
npm run dev
```

## 📖 How to Use

1. **Upload** your video/audio file (up to 5GB)
2. **Choose** from 6 analysis modes
3. **Configure** mode-specific options
4. **Process** and view results
5. **Export** in multiple formats

## 🎯 What's New in This Integration

This integrated version combines three separate applications into one:
- Original Clip Analyzer (4 modes)
- Audio/Video Transcriber
- Shot Lister for Video & Photo

All features are now accessible from a single, unified interface!

## 📊 Supported Formats

**Video**: MP4, MOV, WebM, AVI, MKV
**Audio**: MP3, WAV, M4A, OGG (transcription mode)

## 💡 Best For

- Documentary filmmakers
- Video editors
- Content creators
- Post-production teams
- Wildlife videographers
- Media archivists

## 🛠️ Technology

- React 19 + TypeScript
- Google Gemini AI (2.5-Flash & 2.5-Pro)
- Tailwind CSS
- Canvas & Web Audio APIs

## 📝 License

MIT
