
import React, { useState, useCallback, useEffect, useReducer, useMemo, lazy, Suspense } from 'react';
import {
  AppStatus,
  AnalysisMode,
  Synopsis,
  Bio,
  SynopsisConfig,
  DEFAULT_SYNOPSIS_CONFIG,
  MAX_FILE_SIZE_BYTES,
  SUPPORTED_VIDEO_FORMATS,
  ERROR_IDS,
  ERROR_MESSAGES,
  PROGRESS_MESSAGES,
  GraphicsAnalysisResult,
  SpeciesSighting,
  TranscriptionResult,
  ShotListResult,
  FaunaConfig,
  DEFAULT_FAUNA_CONFIG,
  SavedAnalysis,
} from './types';
import {
  analyzeVideoContent,
  generateSynopsisFromAnalysis,
  extractTalentFromVideo,
  generateBio,
  analyzeGraphicsAndLowerThirds,
  analyzeVideoForSpecies,
  transcribeMedia,
  generateShotList,
  uploadFileToGemini,
} from './services/geminiService';
import { dbService } from './services/db';

// Lazy load components for better initial load performance
const FileUploadView = lazy(() => import('./components/FileUploadView'));
const ModeSelectView = lazy(() => import('./components/ModeSelectView'));
const SynopsisInputView = lazy(() => import('./components/SynopsisInputView'));
const BioInputView = lazy(() => import('./components/BioInputView'));
const GraphicsInputView = lazy(() => import('./components/GraphicsInputView'));
const FaunaInputView = lazy(() => import('./components/FaunaInputView'));
const TranscriptionInputView = lazy(() => import('./components/TranscriptionInputView'));
const ShotListInputView = lazy(() => import('./components/ShotListInputView'));
const ProcessingView = lazy(() => import('./components/ProcessingView'));
const SynopsisResultView = lazy(() => import('./components/SynopsisResultView'));
const BioResultView = lazy(() => import('./components/BioResultView'));
const GraphicsResultView = lazy(() => import('./components/GraphicsResultView'));
const FaunaResultView = lazy(() => import('./components/FaunaResultView'));
const TranscriptionResultView = lazy(() => import('./components/TranscriptionResultView'));
const ShotListResultView = lazy(() => import('./components/ShotListResultView'));
const ErrorPopup = lazy(() => import('./components/ErrorPopup'));
const HistoryView = lazy(() => import('./components/HistoryView'));

// ═══════════════════════════════════════════════════════════════════════════════
// TYPES & INTERFACES
// ═══════════════════════════════════════════════════════════════════════════════

interface Job<T> {
  status: 'idle' | 'configuring' | 'processing' | 'results';
  progressMessage: string;
  progressPercentage: number;
  result: T | null;
  abortController: AbortController | null;
}

type AllJobs = {
  synopsis: Job<Synopsis>;
  bio: Job<Bio[]>;
  graphics: Job<GraphicsAnalysisResult>;
  fauna: Job<SpeciesSighting[]>;
  transcribe: Job<TranscriptionResult>;
  shotlist: Job<ShotListResult>;
};

interface AppState {
  appStatus: AppStatus;
  selectedMode: AnalysisMode | null;
  videoFile: File | null;
  videoPreviewUrl: string | null;
  geminiFileUri: string | null;
  popupErrorMessage: string | null;
  jobs: AllJobs;
  synopsisConfig: SynopsisConfig;
  faunaConfig: FaunaConfig;
  videoMetadata: { duration: number; width: number; height: number } | null;
  videoBufferProgress: number;
  uploadProgress: number;
  uploadMessage: string; // New state for dynamic upload messages
  uploadAbortController: AbortController | null; // For cancelling large file uploads
}

type AppAction =
  | { type: 'SET_STATUS'; payload: AppStatus }
  | { type: 'SELECT_MODE'; payload: AnalysisMode }
  | { type: 'DESELECT_MODE' }
  | { type: 'SET_VIDEO'; payload: { file: File; url: string } }
  | { type: 'SET_GEMINI_FILE_URI'; payload: string }
  | { type: 'SET_VIDEO_METADATA'; payload: { duration: number; width: number; height: number } }
  | { type: 'SET_VIDEO_BUFFER_PROGRESS'; payload: number }
  | { type: 'SET_UPLOAD_PROGRESS'; payload: { percentage: number; message?: string } }
  | { type: 'SET_UPLOAD_ABORT_CONTROLLER'; payload: AbortController | null }
  | { type: 'SET_POPUP_ERROR'; payload: string | null }
  | { type: 'UPDATE_JOB'; payload: { mode: AnalysisMode; updates: Partial<Job<any>> } }
  | { type: 'UPDATE_SYNOPSIS_CONFIG'; payload: Partial<SynopsisConfig> }
  | { type: 'UPDATE_FAUNA_CONFIG'; payload: Partial<FaunaConfig> }
  | { type: 'UPDATE_SPEAKER'; payload: { speakerId: string; newName: string } }
  | { type: 'RESET_ALL' }
  | { type: 'LOAD_SAVED_ANALYSIS'; payload: SavedAnalysis };

// ═══════════════════════════════════════════════════════════════════════════════
// REDUCER & INITIAL STATE
// ═══════════════════════════════════════════════════════════════════════════════

const initialJobState: Job<any> = {
  status: 'idle',
  progressMessage: PROGRESS_MESSAGES.DEFAULT,
  progressPercentage: 0,
  result: null,
  abortController: null,
};

const initialJobs: AllJobs = {
  synopsis: { ...initialJobState },
  bio: { ...initialJobState },
  graphics: { ...initialJobState },
  fauna: { ...initialJobState },
  transcribe: { ...initialJobState },
  shotlist: { ...initialJobState },
};

const initialState: AppState = {
  appStatus: AppStatus.UPLOAD,
  selectedMode: null,
  videoFile: null,
  videoPreviewUrl: null,
  geminiFileUri: null,
  popupErrorMessage: null,
  jobs: initialJobs,
  synopsisConfig: DEFAULT_SYNOPSIS_CONFIG,
  faunaConfig: DEFAULT_FAUNA_CONFIG,
  videoMetadata: null,
  videoBufferProgress: 0,
  uploadProgress: 0,
  uploadMessage: PROGRESS_MESSAGES.UPLOADING,
  uploadAbortController: null,
};

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_STATUS':
      return { ...state, appStatus: action.payload };
    
    case 'SELECT_MODE':
      return {
        ...state,
        selectedMode: action.payload,
        jobs: {
          ...state.jobs,
          [action.payload]: {
            ...state.jobs[action.payload],
            status: state.jobs[action.payload].status === 'idle' ? 'configuring' : state.jobs[action.payload].status,
          },
        },
      };
    
    case 'DESELECT_MODE':
      return {
        ...state,
        selectedMode: null,
        jobs: state.selectedMode
          ? {
              ...state.jobs,
              [state.selectedMode]: {
                ...state.jobs[state.selectedMode],
                status: state.jobs[state.selectedMode].status === 'configuring' ? 'idle' : state.jobs[state.selectedMode].status,
              },
            }
          : state.jobs,
      };
    
    case 'SET_VIDEO':
      return {
        ...state,
        videoFile: action.payload.file,
        videoPreviewUrl: action.payload.url,
        videoMetadata: null,
        appStatus: AppStatus.UPLOADING,
        popupErrorMessage: null,
        videoBufferProgress: 0,
        uploadProgress: 0,
        uploadMessage: PROGRESS_MESSAGES.UPLOADING,
      };

    case 'SET_GEMINI_FILE_URI':
        return { ...state, geminiFileUri: action.payload };

    case 'SET_VIDEO_METADATA':
      return { ...state, videoMetadata: action.payload };

    case 'SET_VIDEO_BUFFER_PROGRESS':
        return { ...state, videoBufferProgress: action.payload };

    case 'SET_UPLOAD_PROGRESS':
        return { 
            ...state, 
            uploadProgress: action.payload.percentage,
            uploadMessage: action.payload.message || state.uploadMessage
        };

    case 'SET_UPLOAD_ABORT_CONTROLLER':
        return { ...state, uploadAbortController: action.payload };

    case 'SET_POPUP_ERROR':
      return { ...state, popupErrorMessage: action.payload };
    
    case 'UPDATE_JOB':
      return {
        ...state,
        jobs: {
          ...state.jobs,
          [action.payload.mode]: {
            ...state.jobs[action.payload.mode],
            ...action.payload.updates,
          },
        },
      };
    
    case 'UPDATE_SYNOPSIS_CONFIG':
      return { ...state, synopsisConfig: { ...state.synopsisConfig, ...action.payload } };
    
    case 'UPDATE_FAUNA_CONFIG':
      return { ...state, faunaConfig: { ...state.faunaConfig, ...action.payload } };
    
    case 'UPDATE_SPEAKER':
      if (!state.jobs.transcribe.result) return state;
      return {
        ...state,
        jobs: {
          ...state.jobs,
          transcribe: {
            ...state.jobs.transcribe,
            result: {
              ...state.jobs.transcribe.result,
              speakerMap: {
                ...state.jobs.transcribe.result.speakerMap,
                [action.payload.speakerId]: action.payload.newName,
              },
            },
          },
        },
      };
    
    case 'RESET_ALL':
      Object.values(state.jobs).forEach(job => job.abortController?.abort());
      state.uploadAbortController?.abort(); // Cancel any in-progress upload
      if (state.videoPreviewUrl) URL.revokeObjectURL(state.videoPreviewUrl);
      return { ...initialState };

    case 'LOAD_SAVED_ANALYSIS':
        return {
            ...state,
            appStatus: AppStatus.RESULTS, 
            selectedMode: action.payload.type,
            videoFile: state.videoFile || new File([], action.payload.fileName), 
            jobs: {
                ...state.jobs,
                [action.payload.type]: {
                    ...state.jobs[action.payload.type],
                    status: 'results',
                    result: action.payload.data,
                    progressPercentage: 100
                }
            }
        };
    
    default:
      return state;
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// MAIN COMPONENT
// ═══════════════════════════════════════════════════════════════════════════════

const App: React.FC = () => {
  const [state, dispatch] = useReducer(appReducer, initialState);

  // Video Metadata Loader
  useEffect(() => {
    if (state.appStatus !== AppStatus.PREPARING_VIDEO || !state.videoPreviewUrl) {
      return;
    }
  
    let cancelled = false;
    const video = document.createElement('video');
  
    const cleanup = () => {
      video.removeEventListener('loadedmetadata', onMetadataLoaded);
      video.removeEventListener('canplaythrough', onCanPlayThrough);
      video.removeEventListener('error', onError);
      video.src = '';
      video.removeAttribute('src');
      if (video.parentElement) {
        document.body.removeChild(video);
      }
    };
  
    const onMetadataLoaded = () => {
      if (cancelled) return;
      if (!isFinite(video.duration) || video.duration === 0) {
        console.error("Invalid video duration received:", video.duration);
        dispatch({ type: 'SET_POPUP_ERROR', payload: ERROR_MESSAGES[ERROR_IDS.VIDEO_LOAD_FAIL] });
        cleanup();
        return;
      }
      dispatch({
        type: 'SET_VIDEO_METADATA',
        payload: {
          duration: video.duration,
          width: video.videoWidth,
          height: video.videoHeight
        },
      });
      dispatch({ type: 'SET_VIDEO_BUFFER_PROGRESS', payload: 50 });
    };
  
    const onCanPlayThrough = async () => {
      if (cancelled) return;
      dispatch({ type: 'SET_VIDEO_BUFFER_PROGRESS', payload: 100 });
      await new Promise(res => setTimeout(res, 500));
      if (!cancelled) {
        dispatch({ type: 'SET_STATUS', payload: AppStatus.MODE_SELECT });
      }
    };
  
    const onError = (e: Event) => {
      console.error('Video element error:', e);
      dispatch({ type: 'SET_POPUP_ERROR', payload: ERROR_MESSAGES[ERROR_IDS.VIDEO_LOAD_FAIL] });
    };
  
    video.addEventListener('loadedmetadata', onMetadataLoaded);
    video.addEventListener('canplaythrough', onCanPlayThrough);
    video.addEventListener('error', onError);
    
    video.preload = 'auto';
    video.src = state.videoPreviewUrl;
    document.body.appendChild(video).style.display = 'none';
    video.load();
  
    return () => {
      cancelled = true;
      cleanup();
    };
  }, [state.appStatus, state.videoPreviewUrl]);

  // File Upload Handler
  useEffect(() => {
    if (state.appStatus === AppStatus.UPLOADING && state.videoFile) {
        const abortController = new AbortController();
        dispatch({ type: 'SET_UPLOAD_ABORT_CONTROLLER', payload: abortController });
        
        const uploadFile = async () => {
            try {
                const uri = await uploadFileToGemini(
                  state.videoFile!, 
                  (msg, pct) => {
                    dispatch({ type: 'SET_UPLOAD_PROGRESS', payload: { percentage: pct, message: msg } });
                  },
                  abortController.signal
                );
                dispatch({ type: 'SET_UPLOAD_ABORT_CONTROLLER', payload: null });
                dispatch({ type: 'SET_GEMINI_FILE_URI', payload: uri });
                dispatch({ type: 'SET_STATUS', payload: AppStatus.PREPARING_VIDEO });
            } catch (error) {
                console.error(error);
                dispatch({ type: 'SET_UPLOAD_ABORT_CONTROLLER', payload: null });
                
                // Don't show error if it was a cancellation
                if (error instanceof Error && error.message === ERROR_IDS.OPERATION_CANCELLED) {
                  return;
                }
                
                dispatch({ type: 'SET_POPUP_ERROR', payload: ERROR_MESSAGES[ERROR_IDS.UPLOAD_FAIL] });
                dispatch({ type: 'SET_STATUS', payload: AppStatus.UPLOAD }); 
            }
        };
        uploadFile();
        
        return () => {
          // Cleanup: abort if component unmounts during upload
          abortController.abort();
        };
    }
  }, [state.appStatus, state.videoFile]);

  const validateFile = useCallback((file: File): string | null => {
    if (file.size > MAX_FILE_SIZE_BYTES) return ERROR_MESSAGES[ERROR_IDS.FILE_TOO_LARGE];
    if (!SUPPORTED_VIDEO_FORMATS.includes(file.type)) return ERROR_MESSAGES[ERROR_IDS.UNSUPPORTED_FORMAT];
    return null;
  }, []);

  const handleFileSelect = useCallback((file: File) => {
    const error = validateFile(file);
    if (error) {
      dispatch({ type: 'SET_POPUP_ERROR', payload: error });
      return;
    }
    if (state.videoPreviewUrl) URL.revokeObjectURL(state.videoPreviewUrl);
    
    const previewUrl = URL.createObjectURL(file);
    dispatch({ 
        type: 'SET_VIDEO', 
        payload: { file, url: previewUrl }
    });

  }, [validateFile, state.videoPreviewUrl]);

  const handleModeSelect = useCallback((mode: AnalysisMode) => {
    if (!state.videoMetadata) {
        console.warn("Attempted to select mode before video metadata was ready.");
        return;
    }
    dispatch({ type: 'SELECT_MODE', payload: mode });
  }, [state.videoMetadata]);

  const handleBackToDashboard = useCallback(() => {
    dispatch({ type: 'DESELECT_MODE' });
    if (!state.videoFile) {
        // If viewing history item without a live file, go back to history list
        dispatch({ type: 'SET_STATUS', payload: AppStatus.HISTORY });
    }
  }, [state.videoFile]);

  const handleSaveAnalysis = useCallback(async (data: any) => {
      if (!state.selectedMode) return;
      try {
          await dbService.saveAnalysis(state.selectedMode, state.videoFile?.name || 'Unknown File', data);
          // Optional: Add toast notification logic here
          // alert('Saved to database!'); // Too intrusive, but confirms functionality for now.
      } catch (e) {
          console.error("Save failed", e);
          dispatch({ type: 'SET_POPUP_ERROR', payload: "Failed to save analysis to local database." });
      }
  }, [state.selectedMode, state.videoFile]);

  const handleLoadAnalysis = useCallback((saved: SavedAnalysis) => {
      dispatch({ type: 'LOAD_SAVED_ANALYSIS', payload: saved });
      dispatch({ type: 'SET_STATUS', payload: AppStatus.RESULTS });
  }, []);

  const createJobRunner = useCallback(<T,>(
    mode: AnalysisMode,
    jobFunction: (
      controller: AbortController,
      updateProgress: (message: string, percentage: number) => void
    ) => Promise<T>
  ) => {
    return async () => {
      const controller = new AbortController();
      dispatch({
        type: 'UPDATE_JOB',
        payload: {
          mode,
          updates: { status: 'processing', progressPercentage: 0, abortController: controller },
        },
      });
      dispatch({ type: 'DESELECT_MODE' });

      const updateProgress = (message: string, percentage: number) => {
        dispatch({
          type: 'UPDATE_JOB',
          payload: { mode, updates: { progressMessage: message, progressPercentage: percentage } },
        });
      };

      try {
        const result = await jobFunction(controller, updateProgress);
        dispatch({
          type: 'UPDATE_JOB',
          payload: { mode, updates: { status: 'results', result, progressPercentage: 100 } },
        });
      } catch (error) {
        let errorMessage = ERROR_MESSAGES.UNKNOWN;
        if (error instanceof Error) {
            errorMessage = ERROR_MESSAGES[error.message] || error.message;
        }

        if (error instanceof Error && error.message !== ERROR_IDS.OPERATION_CANCELLED) {
          dispatch({ type: 'SET_POPUP_ERROR', payload: errorMessage });
          
          dispatch({
            type: 'UPDATE_JOB',
            payload: { mode, updates: { status: 'configuring', progressPercentage: 0, progressMessage: PROGRESS_MESSAGES.DEFAULT, abortController: null } },
          });

          dispatch({ type: 'SELECT_MODE', payload: mode });
          
        } else { // Operation was cancelled
          dispatch({
            type: 'UPDATE_JOB',
            payload: { mode, updates: { ...initialJobState } },
          });
        }
      }
    };
  }, []);

  const handleSynopsisGeneration = useCallback(
    async (writer: string, director: string, keywords: string, language: string) => {
      if (!state.videoFile || !state.geminiFileUri) return;

      const runner = createJobRunner<Synopsis>('synopsis', async (controller, updateProgress) => {
        updateProgress(PROGRESS_MESSAGES.ANALYZING, 15);

        const analysisResult = await analyzeVideoContent(
          state.geminiFileUri!,
          state.videoFile!.type,
          controller.signal,
          (msg, pct) => updateProgress(msg, 15 + pct * 0.7)
        );

        updateProgress(PROGRESS_MESSAGES.GENERATING_SYNOPSIS, 85);
        return await generateSynopsisFromAnalysis(
          analysisResult,
          writer,
          director,
          language,
          state.videoFile!.name,
          keywords,
          controller.signal,
          state.synopsisConfig
        );
      });

      await runner();
    },
    [state.videoFile, state.geminiFileUri, state.synopsisConfig, createJobRunner]
  );

  const handleBioGeneration = useCallback(
    async (talents: { name: string; context: string }[], language: string, autoDetect: boolean) => {
      if (!state.videoFile || !state.geminiFileUri) return;

      const runner = createJobRunner<Bio[]>('bio', async (controller, updateProgress) => {
        let finalTalents = talents;

        if (autoDetect) {
          updateProgress(PROGRESS_MESSAGES.IDENTIFYING_TALENT, 10);
          const detectedNames = await extractTalentFromVideo(state.geminiFileUri!, state.videoFile!.type);
          updateProgress(PROGRESS_MESSAGES.IDENTIFYING_TALENT, 50);

          if (detectedNames.length === 0) throw new Error(ERROR_IDS.NO_TALENT_FOUND);
          finalTalents = detectedNames.map(name => ({ name, context: 'On-screen talent' }));
        }

        const uniqueTalents = finalTalents.filter(
          (t, i, self) => i === self.findIndex(s => s.name.toLowerCase() === t.name.toLowerCase())
        );
        if (uniqueTalents.length === 0) throw new Error('No unique talent names provided.');

        let bioResults: Bio[] = uniqueTalents.map(t => ({
          name: t.name,
          fullName: '',
          title: '',
          biography: '',
          isLoading: true,
        }));

        updateProgress(PROGRESS_MESSAGES.GENERATING_BIOS, 50);

        const BATCH_SIZE = 3;
        for (let i = 0; i < uniqueTalents.length; i += BATCH_SIZE) {
          if (controller.signal.aborted) throw new Error(ERROR_IDS.OPERATION_CANCELLED);

          const batch = uniqueTalents.slice(i, i + BATCH_SIZE);
          const batchResults = await Promise.allSettled(
            batch.map(t => generateBio(t.name, t.context, language))
          );

          bioResults = bioResults.map(bio => {
            const batchIndex = batch.findIndex(b => b.name === bio.name);
            if (batchIndex === -1) return bio;

            const result = batchResults[batchIndex];
            if (result.status === 'fulfilled') {
              return { name: bio.name, ...result.value, isLoading: false };
            }
            return {
              ...bio,
              isLoading: false,
              fullName: bio.name,
              title: 'Generation Failed',
              biography: '',
              error: (result.reason as Error).message,
            };
          });

          const completed = i + batch.length;
          updateProgress(PROGRESS_MESSAGES.GENERATING_BIOS, (completed / uniqueTalents.length) * 100);
        }

        return bioResults;
      });

      await runner();
    },
    [state.videoFile, state.geminiFileUri, createJobRunner]
  );

  const handleGraphicsAnalysis = useCallback(async () => {
    if (!state.videoFile || !state.geminiFileUri || !state.videoMetadata) return;

    const runner = createJobRunner<GraphicsAnalysisResult>('graphics', async (controller, updateProgress) => {
      updateProgress('Analyzing graphics...', 30);
      const result = await analyzeGraphicsAndLowerThirds(
        state.geminiFileUri!,
        state.videoFile!.type,
        state.videoMetadata!.duration,
        state.videoFile!.name.replace(/\.[^/.]+$/, '')
      );

      // Without frame extraction, we don't generate thumbnails automatically here to save processing
      return result;
    });

    await runner();
  }, [state.videoFile, state.geminiFileUri, state.videoMetadata, createJobRunner]);

  const handleFaunaAnalysis = useCallback(async () => {
    if (!state.videoFile || !state.geminiFileUri || !state.videoMetadata) return;

    const runner = createJobRunner<SpeciesSighting[]>('fauna', async (controller, updateProgress) => {
      updateProgress('Identifying species...', 30);
      const sightings = await analyzeVideoForSpecies(
        state.geminiFileUri!,
        state.videoFile!.type,
        state.faunaConfig.primaryLanguage,
        state.faunaConfig.secondaryLanguage
      );

      return sightings.map((s, i) => ({ ...s, id: `species-${Date.now()}-${i}` }));
    });

    await runner();
  }, [state.videoFile, state.geminiFileUri, state.videoMetadata, state.faunaConfig, createJobRunner]);

  const handleTranscription = useCallback(async () => {
    if (!state.videoFile || !state.geminiFileUri) return;
    
    const runner = createJobRunner<TranscriptionResult>('transcribe', async (controller, updateProgress) => {
      
      updateProgress('Starting transcription job...', 10);
      
      const rawResult = await transcribeMedia(
        state.geminiFileUri!, 
        state.videoFile!.type,
        controller.signal, 
        updateProgress
      );
      
      const speakerIds = [...new Set(rawResult.segments.map(s => s.speaker))];
      const speakerMap: Record<string, string> = {};
      speakerIds.forEach((id: string) => {
        speakerMap[id] = id.replace(/_/g, ' ');
      });

      return { segments: rawResult.segments, speakerMap };
    });

    await runner();
  }, [state.videoFile, state.geminiFileUri, createJobRunner]);

  const handleUpdateSpeaker = useCallback((speakerId: string, newName: string) => {
    dispatch({ type: 'UPDATE_SPEAKER', payload: { speakerId, newName } });
  }, []);

  const handleShotListGeneration = useCallback(
    async (language: string, frameRate: number) => {
      if (!state.videoFile || !state.geminiFileUri || !state.videoMetadata) return;

      const runner = createJobRunner<ShotListResult>('shotlist', async (controller, updateProgress) => {
        updateProgress('Analyzing scenes...', 10);
        
        const shotsData = await generateShotList(
          state.geminiFileUri!,
          state.videoFile!.type,
          language,
          frameRate,
          controller.signal,
          updateProgress
        );

        const shotsWithThumbnails = shotsData.map((shot, index) => {
          return {
            ...shot,
            nr: index + 1,
            thumbnail: undefined // We are not extracting client-side frames anymore
          };
        });

        return { shots: shotsWithThumbnails, videoUrl: state.videoPreviewUrl!, frameRate };
      });

      await runner();
    },
    [state.videoFile, state.geminiFileUri, state.videoMetadata, state.videoPreviewUrl, createJobRunner]
  );

  const handleReset = useCallback(() => {
    dispatch({ type: 'RESET_ALL' });
  }, []);

  const handleCancel = useCallback(
    (mode: AnalysisMode) => {
      state.jobs[mode].abortController?.abort();
      dispatch({ type: 'UPDATE_JOB', payload: { mode, updates: { ...initialJobState } } });
      dispatch({ type: 'DESELECT_MODE' });
    },
    [state.jobs]
  );

  useEffect(() => {
    return () => {
      if (state.videoPreviewUrl) URL.revokeObjectURL(state.videoPreviewUrl);
    };
  }, [state.videoPreviewUrl]);

  const renderContent = () => {
    switch (state.appStatus) {
      case AppStatus.UPLOAD:
        return <FileUploadView onFileSelect={handleFileSelect} />;
      
      case AppStatus.UPLOADING:
         return (
          <ProcessingView
            message={state.uploadMessage}
            percentage={state.uploadProgress}
            onCancel={handleReset}
            onBack={handleReset}
          />
         );

      case AppStatus.PREPARING_VIDEO:
        return (
          <ProcessingView
            message={PROGRESS_MESSAGES.PREPARING_VIDEO}
            percentage={state.videoBufferProgress}
            onCancel={handleReset}
            onBack={handleReset}
          />
        );
      
      case AppStatus.MODE_SELECT:
        if (state.videoFile) {
          return (
            <ModeSelectView
              videoFile={state.videoFile}
              videoPreviewUrl={state.videoPreviewUrl}
              onModeSelect={handleModeSelect}
              onBack={handleReset}
              onViewHistory={() => dispatch({ type: 'SET_STATUS', payload: AppStatus.HISTORY })}
              jobs={state.jobs}
            />
          );
        }
        return <FileUploadView onFileSelect={handleFileSelect} />;

      case AppStatus.HISTORY:
        return <HistoryView onBack={() => dispatch({ type: 'SET_STATUS', payload: state.videoFile ? AppStatus.MODE_SELECT : AppStatus.UPLOAD })} onLoadAnalysis={handleLoadAnalysis} />;
      
      default:
        return null;
    }
  };

  const renderJobDetailView = useMemo(() => {
    if (!state.selectedMode) return null;
    const job = state.jobs[state.selectedMode];

    switch (job.status) {
      case 'configuring':
        switch (state.selectedMode) {
          case 'synopsis': return <SynopsisInputView onGenerate={handleSynopsisGeneration} synopsisConfig={state.synopsisConfig} onConfigChange={(config) => dispatch({ type: 'UPDATE_SYNOPSIS_CONFIG', payload: config })} onBack={handleBackToDashboard} />;
          case 'bio': return <BioInputView onGenerate={handleBioGeneration} onBack={handleBackToDashboard} />;
          case 'graphics': return <GraphicsInputView onGenerate={handleGraphicsAnalysis} onBack={handleBackToDashboard} />;
          case 'fauna': return <FaunaInputView onGenerate={handleFaunaAnalysis} config={state.faunaConfig} onConfigChange={(config) => dispatch({ type: 'UPDATE_FAUNA_CONFIG', payload: config })} onBack={handleBackToDashboard} />;
          case 'transcribe': return <TranscriptionInputView onStartTranscription={handleTranscription} onBack={handleBackToDashboard} />;
          case 'shotlist': return <ShotListInputView onStartAnalysis={handleShotListGeneration} onBack={handleBackToDashboard} />;
        }
        break;
      case 'processing': return <ProcessingView message={job.progressMessage} percentage={job.progressPercentage} onCancel={() => handleCancel(state.selectedMode!)} onBack={handleBackToDashboard} />;
      case 'results':
        switch (state.selectedMode) {
          case 'synopsis': return <SynopsisResultView synopsis={job.result as Synopsis} onReset={handleReset} onBack={handleBackToDashboard} onSave={handleSaveAnalysis} />;
          case 'bio': return <BioResultView bios={job.result as Bio[]} videoFileName={state.videoFile?.name || ''} onReset={handleReset} onBack={handleBackToDashboard} onSave={handleSaveAnalysis} />;
          case 'graphics': return <GraphicsResultView result={job.result as GraphicsAnalysisResult} videoFileName={state.videoFile?.name || ''} videoPreviewUrl={state.videoPreviewUrl} onReset={handleReset} onBack={handleBackToDashboard} onSave={handleSaveAnalysis} />;
          case 'fauna': return <FaunaResultView sightings={job.result as SpeciesSighting[]} videoFileName={state.videoFile?.name || ''} videoPreviewUrl={state.videoPreviewUrl} onReset={handleReset} onBack={handleBackToDashboard} config={state.faunaConfig} onSave={handleSaveAnalysis} />;
          case 'transcribe': return <TranscriptionResultView result={job.result as TranscriptionResult} videoPreviewUrl={state.videoPreviewUrl} onReset={handleReset} onUpdateSpeaker={handleUpdateSpeaker} onBack={handleBackToDashboard} onSave={handleSaveAnalysis} />;
          case 'shotlist': return <ShotListResultView result={job.result as ShotListResult} onReset={handleReset} onBack={handleBackToDashboard} onSave={handleSaveAnalysis} />;
        }
        break;
    }
    return null;
  }, [ state.selectedMode, state.jobs, state.synopsisConfig, state.faunaConfig, state.videoFile, state.videoPreviewUrl, handleSynopsisGeneration, handleBioGeneration, handleGraphicsAnalysis, handleFaunaAnalysis, handleTranscription, handleShotListGeneration, handleBackToDashboard, handleCancel, handleReset, handleUpdateSpeaker, handleSaveAnalysis ]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-900 to-slate-900 text-white p-4 sm:p-6 lg:p-8">
       <Suspense>
        {state.popupErrorMessage && (
          <ErrorPopup 
            errorMessage={state.popupErrorMessage}
            onClose={() => dispatch({ type: 'SET_POPUP_ERROR', payload: null })}
          />
        )}
      </Suspense>

      <header className="text-center mb-8">
        <h1 className="text-4xl sm:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-indigo-500 to-purple-600">
          Terra Mater Studios Clip Analyser
        </h1>
        <p className="mt-2 text-lg text-gray-400">Upload a video and choose your analysis type</p>
      </header>
      <main className="max-w-5xl mx-auto">
        <div className="bg-gray-800/80 backdrop-blur-sm p-6 sm:p-8 rounded-2xl shadow-2xl border border-gray-700/50">
          <Suspense fallback={<div className="text-center py-8">Loading...</div>}>
            {(state.selectedMode || state.appStatus === AppStatus.RESULTS) ? renderJobDetailView : renderContent()}
          </Suspense>
        </div>
      </main>
    </div>
  );
};

export default App;
