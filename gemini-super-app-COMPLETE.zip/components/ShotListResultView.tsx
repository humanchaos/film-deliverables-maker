import React, { useState, useRef, useEffect } from 'react';
import { ShotListResult } from '../types';
import { generateCSV, downloadFile } from '../utils/tableUtils';
import { parseTimecode } from '../utils/tableUtils';
import { Check, Database, ChevronDown, ChevronUp } from 'lucide-react';
import VideoThumbnail from './VideoThumbnail';

interface ShotListResultViewProps {
  result: ShotListResult;
  onReset: () => void;
  onBack: () => void;
  onSave: (data: ShotListResult) => Promise<void>;
  videoPreviewUrl: string | null;
}

const ShotListResultView: React.FC<ShotListResultViewProps> = ({
  result,
  onReset,
  onBack,
  onSave,
  videoPreviewUrl
}) => {
  const [expandedShot, setExpandedShot] = useState<number | null>(null);
  const [isSaved, setIsSaved] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Use the passed prop if available, otherwise fall back to result (though result.videoUrl might be stale/invalid for history)
  // Ideally, videoPreviewUrl is the source of truth for the currently live video.
  const activeVideoUrl = videoPreviewUrl || result.videoUrl;
  const isVideoAvailable = !!videoPreviewUrl; // Only consider live preview URL as valid for playback

  const toggleShot = (nr: number) => {
    setExpandedShot(expandedShot === nr ? null : nr);
  };

  useEffect(() => {
    if (expandedShot === null || !videoRef.current || !activeVideoUrl) return;
    
    const shot = result.shots.find(s => s.nr === expandedShot);
    if (shot) {
        const time = parseTimecode(shot.tcIn, result.frameRate);
        videoRef.current.currentTime = time;
        // Only attempt to play if we are fairly sure the URL is valid
        if (isVideoAvailable) {
            videoRef.current.play().catch(e => console.log("Autoplay prevented", e));
        }
    }
  }, [expandedShot, activeVideoUrl, result.frameRate, result.shots, isVideoAvailable]);


  const handleDownloadCSV = () => {
    const headers = ['Shot #', 'Timecode In', 'Timecode Out', 'Duration', 'Description', 'Action', 'Audio'];
    const rows = result.shots.map(shot => [shot.nr, shot.tcIn, shot.tcOut, shot.duration, shot.description, shot.action, shot.audio]);
    const csvContent = generateCSV(headers, rows);
    downloadFile(csvContent, 'shot_list.csv', 'text/csv');
  };

  const handleSaveToDatabase = async () => {
    setIsSaving(true);
    await onSave(result);
    setIsSaved(true);
    setIsSaving(false);
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-cyan-900/30 to-sky-900/30 border border-cyan-500/30 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-2xl font-bold text-white mb-2">Shot List Complete</h3>
            <p className="text-gray-400">{result.shots.length} shots identified</p>
          </div>
          <div className="flex gap-2">
            <button onClick={onBack} className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg font-semibold">Back</button>
            <button onClick={onReset} className="px-4 py-2 bg-red-800 hover:bg-red-700 text-white rounded-lg font-semibold">New Video</button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <button onClick={handleDownloadCSV} className="w-full px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2-2z" /></svg>
            Download CSV
          </button>
          <button
            onClick={handleSaveToDatabase}
            disabled={isSaved || isSaving}
            className="w-full px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2 disabled:bg-gray-500 disabled:cursor-not-allowed"
          >
            {isSaved ? (
            <><Check size={18} />Saved</>
          ) : (
            <><Database size={18} />{isSaving ? 'Saving...' : 'Save to Database'}</>
          )}
          </button>
        </div>
      </div>

      <div className="bg-gray-900/50 rounded-lg border border-gray-700 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead className="bg-gray-800 border-b border-gray-700">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300 border-r border-gray-700">Shot #</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300 border-r border-gray-700">Preview</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300 whitespace-nowrap border-r border-gray-700">TC In</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300 whitespace-nowrap border-r border-gray-700">TC Out</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300 border-r border-gray-700">Duration</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300 border-r border-gray-700">Description</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300 border-r border-gray-700">Action</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300">Audio</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-700">
              {result.shots.map((shot) => (
                <React.Fragment key={shot.nr}>
                    <tr 
                        className={`hover:bg-gray-800/50 transition-colors cursor-pointer ${expandedShot === shot.nr ? 'bg-cyan-900/20' : ''}`} 
                        onClick={() => toggleShot(shot.nr)}
                        style={{ contentVisibility: 'auto' }}
                    >
                    <td className="px-4 py-3 text-sm text-gray-300 font-semibold border-r border-gray-700 align-top">
                        <div className="flex items-center gap-2">
                            {expandedShot === shot.nr ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                            {shot.nr}
                        </div>
                    </td>
                    <td className="px-4 py-3 border-r border-gray-700 align-top w-32">
                         <VideoThumbnail videoUrl={activeVideoUrl} timecode={shot.tcIn} className="w-24 h-16 rounded" />
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-400 font-mono whitespace-nowrap border-r border-gray-700 align-top">{shot.tcIn}</td>
                    <td className="px-4 py-3 text-sm text-gray-400 font-mono whitespace-nowrap border-r border-gray-700 align-top">{shot.tcOut}</td>
                    <td className="px-4 py-3 text-sm text-gray-400 font-mono border-r border-gray-700 align-top">{shot.duration}</td>
                    <td className="px-4 py-3 text-sm text-gray-300 border-r border-gray-700 align-top">{shot.description}</td>
                    <td className="px-4 py-3 text-sm text-gray-300 border-r border-gray-700 align-top">{shot.action}</td>
                    <td className="px-4 py-3 text-sm text-gray-300 align-top">{shot.audio}</td>
                    </tr>
                    {expandedShot === shot.nr && (
                        <tr className="bg-black/40 animate-fade-in">
                            <td colSpan={8} className="p-4 border-t border-gray-700">
                                {isVideoAvailable ? (
                                    <div className="aspect-video w-full max-w-3xl mx-auto bg-black rounded-lg overflow-hidden border border-gray-600 shadow-xl">
                                        <video 
                                            ref={videoRef}
                                            src={activeVideoUrl}
                                            controls
                                            className="w-full h-full"
                                        />
                                    </div>
                                ) : (
                                    <div className="aspect-video w-full max-w-3xl mx-auto bg-gray-900 rounded-lg overflow-hidden border border-gray-700 shadow-xl flex items-center justify-center flex-col gap-3">
                                        <svg className="w-16 h-16 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M6 6l12 12" />
                                        </svg>
                                        <p className="text-gray-400">Video preview not available for saved history items.</p>
                                    </div>
                                )}
                            </td>
                        </tr>
                    )}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ShotListResultView;