import React, { useState, useEffect, useRef } from 'react';
import { thumbnailGenerator } from '../utils/thumbnailUtils';

interface VideoThumbnailProps {
  videoUrl: string | null;
  timecode: string | number;
  alt?: string;
  className?: string;
}

const VideoThumbnail: React.FC<VideoThumbnailProps> = ({ videoUrl, timecode, alt = 'Video thumbnail', className = '' }) => {
  const [thumbnail, setThumbnail] = useState<string | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  const imgRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { rootMargin: '50px' }
    );

    if (imgRef.current) {
      observer.observe(imgRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    // If no video URL is provided, we can't generate a thumbnail.
    if (!isVisible || !videoUrl || thumbnail) return;

    let isMounted = true;
    thumbnailGenerator.generateThumbnail(videoUrl, timecode).then((dataUrl) => {
      if (isMounted) setThumbnail(dataUrl);
    });

    return () => { isMounted = false; };
  }, [isVisible, videoUrl, timecode, thumbnail]);

  return (
    <div ref={imgRef} className={`relative overflow-hidden bg-gray-800 rounded-md ${className}`} style={{ minHeight: '60px', minWidth: '100px' }}>
      {thumbnail ? (
        <img src={thumbnail} alt={alt} className="w-full h-full object-cover animate-fade-in" />
      ) : !videoUrl ? (
         // Fallback when video URL is missing (e.g. history mode)
         <div className="absolute inset-0 flex items-center justify-center bg-gray-800/80">
            <span className="text-[10px] text-gray-500 uppercase font-medium tracking-wider">No Preview</span>
         </div>
      ) : (
        // Loading state
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-4 h-4 border-2 border-gray-600 border-t-gray-400 rounded-full animate-spin"></div>
        </div>
      )}
    </div>
  );
};

export default VideoThumbnail;