
import React, { useState } from 'react';
import { TranscriptionResult } from '../types';
import { generateCSV, downloadFile, copyToClipboard } from '../utils/tableUtils';
import { Check, Database, FileText } from 'lucide-react';
import VideoThumbnail from './VideoThumbnail';

interface TranscriptionResultViewProps {
  result: TranscriptionResult;
  videoPreviewUrl: string | null;
  onReset: () => void;
  onUpdateSpeaker: (speaker: string, newName: string) => void;
  onBack: () => void;
  onSave: (data: TranscriptionResult) => Promise<void>;
}

const TranscriptionResultView: React.FC<TranscriptionResultViewProps> = ({
  result,
  videoPreviewUrl,
  onReset,
  onUpdateSpeaker,
  onBack,
  onSave,
}) => {
  const [isCopied, setIsCopied] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const handleCopy = async () => {
    const text = result.segments
      .map(seg => {
        const speakerName = result.speakerMap[seg.speaker] || seg.speaker;
        return `${seg.startTime} - ${seg.endTime}\n${speakerName}: ${seg.transcript}`;
      })
      .join('\n\n');
    
    if (await copyToClipboard(text)) {
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    }
  };

  const handleDownloadCSV = () => {
    const headers = ['Start Time', 'End Time', 'Speaker', 'Transcript'];
    const rows = result.segments.map(seg => [
        seg.startTime,
        seg.endTime,
        result.speakerMap[seg.speaker] || seg.speaker,
        seg.transcript
      ]);
    const csvContent = generateCSV(headers, rows);
    downloadFile(csvContent, 'transcription.csv', 'text/csv');
  };

  const handleDownloadScript = () => {
    let scriptContent = `TRANSCRIPT SCRIPT EXPORT\n----------------\n\n`;
    
    result.segments.forEach(seg => {
      const speakerName = result.speakerMap[seg.speaker] || seg.speaker;
      
      // Format time from HH:MM:SS.mmm to MM:SS for cleaner script look
      let formattedTime = seg.startTime;
      const timeParts = seg.startTime.split(':');
      if (timeParts.length >= 3) {
         // Take MM:SS part
         formattedTime = `${timeParts[1]}:${timeParts[2].split('.')[0]}`;
      }

      scriptContent += `OT ${speakerName}\n`;
      scriptContent += `${formattedTime}\n`;
      scriptContent += `${seg.transcript}\n\n`;
    });

    downloadFile(scriptContent, 'tv_script_layout.txt', 'text/plain');
  };

  const handleSaveToDatabase = async () => {
    setIsSaving(true);
    await onSave(result);
    setIsSaved(true);
    setIsSaving(false);
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-pink-900/30 to-rose-900/30 border border-pink-500/30 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-2xl font-bold text-white mb-2">Transcription Complete</h3>
            <p className="text-gray-400">{result.segments.length} segments transcribed</p>
          </div>
          <div className="flex gap-2">
            <button onClick={onBack} className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg font-semibold">Back</button>
            <button onClick={onReset} className="px-4 py-2 bg-red-800 hover:bg-red-700 text-white rounded-lg font-semibold">New Video</button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
          <button onClick={handleCopy} className="w-full px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2">
            {isCopied ? (
              <><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>Copied!</>
            ) : (
              <><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>Copy Text</>
            )}
          </button>
          <button onClick={handleDownloadCSV} className="w-full px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2-2z" /></svg>
            Download CSV
          </button>
          <button onClick={handleDownloadScript} className="w-full px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2">
            <FileText size={20} />
            Download Script
          </button>
          <button
            onClick={handleSaveToDatabase}
            disabled={isSaved || isSaving}
            className="w-full px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2 disabled:bg-gray-500 disabled:cursor-not-allowed"
          >
            {isSaved ? (
            <><Check size={18} />Saved</>
          ) : (
            <><Database size={18} />{isSaving ? 'Saving...' : 'Save to DB'}</>
          )}
          </button>
        </div>
      </div>

      <div className="bg-gray-900/50 rounded-lg border border-gray-700 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead className="bg-gray-800 border-b border-gray-700">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300 border-r border-gray-700 last:border-r-0">Preview</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300 whitespace-nowrap border-r border-gray-700 last:border-r-0">Start Time</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300 whitespace-nowrap border-r border-gray-700 last:border-r-0">End Time</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300 border-r border-gray-700 last:border-r-0">Speaker</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300">Transcript</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-700">
              {result.segments.map((segment, index) => (
                <tr key={index} className="hover:bg-gray-800/50 transition-colors" style={{ contentVisibility: 'auto' }}>
                   <td className="px-4 py-2 border-r border-gray-700 last:border-r-0 w-32">
                     <VideoThumbnail videoUrl={videoPreviewUrl} timecode={segment.startTime} className="w-24 h-16 rounded" />
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-400 font-mono whitespace-nowrap border-r border-gray-700 last:border-r-0">{segment.startTime}</td>
                  <td className="px-4 py-3 text-sm text-gray-400 font-mono whitespace-nowrap border-r border-gray-700 last:border-r-0">{segment.endTime}</td>
                  <td className="px-4 py-3 border-r border-gray-700 last:border-r-0">
                    <input
                      type="text"
                      value={result.speakerMap[segment.speaker] || ''}
                      onChange={(e) => onUpdateSpeaker(segment.speaker, e.target.value)}
                      placeholder={segment.speaker}
                      className="w-full px-2 py-1 bg-gray-800 border border-gray-600 rounded text-sm text-gray-300 focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                    />
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-300">{segment.transcript}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default TranscriptionResultView;
