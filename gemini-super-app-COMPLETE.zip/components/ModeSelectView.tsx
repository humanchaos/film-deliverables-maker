
import React from 'react';
import { AnalysisMode } from '../types';
import { History } from 'lucide-react';

interface JobStatus {
  status: 'idle' | 'configuring' | 'processing' | 'results';
  progressPercentage?: number;
}

interface ModeSelectViewProps {
  videoFile: File;
  videoPreviewUrl: string | null;
  onModeSelect: (mode: AnalysisMode) => void;
  onBack: () => void;
  onViewHistory: () => void; // New prop for history
  jobs: Record<AnalysisMode, JobStatus>;
}

const ModeCard: React.FC<{
  mode: AnalysisMode;
  job: JobStatus;
  onSelect: (mode: AnalysisMode) => void;
  title: string;
  description: string;
  icon: React.ReactNode;
  className: string;
}> = ({ mode, job, onSelect, title, description, icon, className }) => {
  let statusIndicator: React.ReactNode = null;

  switch (job.status) {
    case 'configuring':
      // No indicator for configuring state
      break;
    case 'processing':
      statusIndicator = (
        <div className="absolute top-2 right-2 flex items-center gap-1 bg-gray-900/80 text-xs text-indigo-300 px-2 py-1 rounded-full">
           <div className="w-3 h-3 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin"></div>
          {job.progressPercentage?.toFixed(0)}%
        </div>
      );
      break;
    case 'results':
       statusIndicator = (
        <div className="absolute top-2 right-2 flex items-center gap-1 bg-green-500/20 text-xs text-green-300 px-2 py-1 rounded-full">
          <span className="w-2 h-2 bg-green-400 rounded-full"></span>
          Done
        </div>
      );
      break;
  }

  const titleForState = 
    job.status === 'results' ? `${title}: View Results` :
    title;

  return (
    <button
      onClick={() => onSelect(mode)}
      className={`group relative bg-gradient-to-br border rounded-xl p-6 text-left transition-all duration-200 transform hover:scale-105 ${className}`}
    >
      {statusIndicator}
      <div className="flex items-start gap-4">
        <div className="flex-shrink-0 w-12 h-12 bg-black/20 rounded-lg flex items-center justify-center group-hover:bg-black/30 transition-colors">
          {icon}
        </div>
        <div className="flex-1">
          <h4 className="text-lg font-bold text-white mb-2 group-hover:text-purple-300 transition-colors">
            {titleForState}
          </h4>
          <p className="text-sm text-gray-400 leading-relaxed">
            {description}
          </p>
        </div>
      </div>
    </button>
  );
};


const ModeSelectView: React.FC<ModeSelectViewProps> = ({
  videoFile,
  videoPreviewUrl,
  onModeSelect,
  onBack,
  onViewHistory,
  jobs,
}) => {
  
  const modes: { mode: AnalysisMode; title: string; description: string; icon: React.ReactNode; className: string }[] = [
    {
      mode: 'synopsis',
      title: 'Generate Synopsis',
      description: 'Create a professional film synopsis with title, logline, summary, themes, and target audience',
      icon: <svg className="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2-2z" /></svg>,
      className: "from-purple-600/20 to-indigo-600/20 hover:from-purple-600/30 hover:to-indigo-600/30 border-purple-500/30 hover:border-purple-400"
    },
    {
      mode: 'bio',
      title: 'Generate Talent Bios',
      description: 'Automatically identify talent and generate professional biographies for everyone in the video',
      icon: <svg className="w-6 h-6 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>,
      className: "from-indigo-600/20 to-blue-600/20 hover:from-indigo-600/30 hover:to-blue-600/30 border-indigo-500/30 hover:border-indigo-400"
    },
    {
      mode: 'graphics',
      title: 'Find Graphics & Lower Thirds',
      description: 'Detect all on-screen graphics, title cards, and lower thirds with precise timecode logs',
      icon: <svg className="w-6 h-6 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4M4 20h16a1 1 0 001-1V5a1 1 0 00-1-1H4a1 1 0 00-1 1v14a1 1 0 001 1z" /></svg>,
      className: "from-emerald-600/20 to-teal-600/20 hover:from-emerald-600/30 hover:to-teal-600/30 border-emerald-500/30 hover:border-emerald-400"
    },
    {
      mode: 'fauna',
      title: 'Identify Animal Species',
      description: 'Analyze video to identify and catalog all animal species with scientific classifications',
      icon: <svg className="w-6 h-6 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10l-2 1m0 0l-2-1m2 1v2.5M20 7l-2 1m2-1l-2-1m2 1v2.5M14 4l-2-1-2 1M4 7l2-1M4 7l2 1M4 7v2.5M12 21l-2-1m2 1l2-1m-2 1v-2.5M6 18l-2-1v-2.5M18 18l2-1v-2.5" /></svg>,
      className: "from-amber-600/20 to-orange-600/20 hover:from-amber-600/30 hover:to-orange-600/30 border-amber-500/30 hover:border-amber-400"
    },
    {
      mode: 'transcribe',
      title: 'Transcribe Audio/Video',
      description: 'Generate complete time-coded transcription with speaker identification and downloadable CSV',
      icon: <svg className="w-6 h-6 text-pink-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2-2z" /></svg>,
      className: "from-pink-600/20 to-rose-600/20 hover:from-pink-600/30 hover:to-rose-600/30 border-pink-500/30 hover:border-pink-400"
    },
    {
      mode: 'shotlist',
      title: 'Generate Shot List',
      description: 'Create detailed shot-by-shot breakdown with descriptions, timecodes, and thumbnails',
      icon: <svg className="w-6 h-6 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>,
      className: "from-cyan-600/20 to-sky-600/20 hover:from-cyan-600/30 hover:to-sky-600/30 border-cyan-500/30 hover:border-cyan-400"
    }
  ];

  return (
    <div className="space-y-6">
      <div className="bg-gray-900/50 rounded-lg p-4 border border-gray-700 flex items-center justify-between">
        <div className="flex items-center gap-4">
          {videoPreviewUrl && <video src={videoPreviewUrl} className="w-32 h-20 object-cover rounded bg-black" muted />}
          <div className="flex-1 min-w-0">
            <p className="text-gray-300 font-medium truncate">{videoFile.name}</p>
            <p className="text-sm text-gray-500">{(videoFile.size / (1024 * 1024)).toFixed(2)} MB</p>
          </div>
        </div>
        <div className="flex gap-3">
            <button 
                onClick={onViewHistory}
                className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-gray-200 rounded-lg flex items-center gap-2 transition-colors"
            >
                <History size={18} />
                Library
            </button>
            <button onClick={onBack} className="px-4 py-2 border border-gray-600 hover:bg-gray-700 text-gray-300 rounded-lg transition-colors">
                New Upload
            </button>
        </div>
      </div>

      <div>
        <h3 className="text-xl font-bold text-gray-200 mb-4 text-center">Choose Analysis Type</h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {modes.map(modeInfo => (
            <ModeCard
              key={modeInfo.mode}
              mode={modeInfo.mode}
              job={jobs[modeInfo.mode]}
              onSelect={onModeSelect}
              title={modeInfo.title}
              description={modeInfo.description}
              icon={modeInfo.icon}
              className={modeInfo.className}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default ModeSelectView;
