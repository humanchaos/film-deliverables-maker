
import React, { useState, useMemo } from 'react';
import { SpeciesSighting, FaunaConfig } from '../types';
import { Download, ArrowLeft, Copy, Check, Filter, Database } from 'lucide-react';
import { generateCSV, downloadFile, copyToClipboard, parseTimecode } from '../utils/tableUtils';
import VideoThumbnail from './VideoThumbnail';


interface FaunaResultViewProps {
  sightings: SpeciesSighting[];
  videoFileName: string;
  videoPreviewUrl: string | null; // Added prop
  onReset: () => void;
  onBack: () => void;
  config: FaunaConfig;
  onSave: (data: SpeciesSighting[]) => Promise<void>;
}

interface SpeciesEntry {
  commonName: string;
  latinName: string;
  germanName: string;
  firstTimecode: string;
  thumbnail?: string;
  allSightings: SpeciesSighting[];
}

const FaunaResultView: React.FC<FaunaResultViewProps> = ({
  sightings,
  videoFileName,
  videoPreviewUrl,
  onReset,
  onBack,
  config,
  onSave,
}) => {
  const [copied, setCopied] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [filterCategory, setFilterCategory] = useState<string>('all');

  const programTitle = videoFileName.replace(/\.[^/.]+$/, '');

  // Group sightings by species and get first appearance
  const speciesList = useMemo((): SpeciesEntry[] => {
    const speciesMap = new Map<string, SpeciesEntry>();

    sightings.forEach(sighting => {
      const key = sighting.latinName || sighting.commonName;
      
      if (!speciesMap.has(key)) {
        speciesMap.set(key, {
          commonName: sighting.commonName,
          latinName: sighting.latinName,
          germanName: sighting.germanName || '',
          firstTimecode: sighting.timecode,
          thumbnail: sighting.thumbnail,
          allSightings: [sighting],
        });
      } else {
        const entry = speciesMap.get(key)!;
        entry.allSightings.push(sighting);
        
        if (parseTimecode(sighting.timecode) < parseTimecode(entry.firstTimecode)) {
          entry.firstTimecode = sighting.timecode;
          entry.thumbnail = sighting.thumbnail;
        }
      }
    });
    
    return Array.from(speciesMap.values()).sort((a, b) => parseTimecode(a.firstTimecode) - parseTimecode(b.firstTimecode));
  }, [sightings]);

  const categories = useMemo(() => Array.from(new Set(sightings.map(s => s.category).filter(Boolean))).sort() as string[], [sightings]);

  const filteredSpeciesList = useMemo(() => {
    if (filterCategory === 'all') return speciesList;
    return speciesList.filter(species =>
      species.allSightings.some(s => s.category === filterCategory)
    );
  }, [speciesList, filterCategory]);

  const generateTableText = (): string => {
    let output = `SPECIES LIST / ARTENLISTE\n${programTitle.toUpperCase()}\n\n`;
    output += `┌───────────────────┬──────────────────────────┬──────────────────────────┬──────────────────┐\n`;
    output += `│ COMMON NAME       │ LATIN NAME               │ ${config.secondaryLanguage.toUpperCase().substring(0,15).padEnd(15)} │ 1st APPEARANCE   │\n`;
    output += `├───────────────────┼──────────────────────────┼──────────────────────────┼──────────────────┤\n`;
    filteredSpeciesList.forEach(s => {
      output += `│ ${s.commonName.substring(0,17).padEnd(17)} │ ${s.latinName.substring(0,24).padEnd(24)} │ ${(s.germanName || '').substring(0,24).padEnd(24)} │ ${s.firstTimecode.padEnd(16)} │\n`;
    });
    output += `└───────────────────┴──────────────────────────┴──────────────────────────┴──────────────────┘\n`;
    return output;
  };

  const handleCopyTable = async () => {
    if (await copyToClipboard(generateTableText())) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownloadCSV = () => {
    const headers = ['Common Name', 'Latin Name', `${config.secondaryLanguage.toUpperCase()} NAME`, 'First Timecode', 'Total Sightings', 'Category', 'All Timecodes'];
    const rows = filteredSpeciesList.map(s => [s.commonName, s.latinName, s.germanName, s.firstTimecode, s.allSightings.length, s.allSightings[0].category || '', s.allSightings.map(s => s.timecode).join('; ')]);
    const csv = generateCSV(headers, rows);
    downloadFile(csv, `${programTitle}_species_list.csv`, 'text/csv');
  };

  const handleSaveToDatabase = async () => {
    setIsSaving(true);
    await onSave(sightings);
    setIsSaved(true);
    setIsSaving(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <button onClick={onBack} className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors"><ArrowLeft size={20} />Back</button>
        <div className="flex gap-2">
          <button onClick={handleCopyTable} className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 rounded-lg">{copied ? <Check size={18} /> : <Copy size={18} />}{copied ? 'Copied!' : 'Copy Table'}</button>
          <button onClick={handleDownloadCSV} className="flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 rounded-lg"><Download size={18} />Export CSV</button>
          <button onClick={handleSaveToDatabase} disabled={isSaved || isSaving} className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 rounded-lg disabled:bg-gray-500 disabled:cursor-not-allowed">{isSaved ? <Check size={18} /> : <Database size={18} />}{isSaved ? 'Saved' : isSaving ? 'Saving...' : 'Save'}</button>
        </div>
      </div>

      <div className="text-center">
        <h2 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-emerald-500">Species List / Artenliste</h2>
        <p className="text-gray-400 mt-2 font-semibold">{programTitle.toUpperCase()}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gray-700/50 p-4 rounded-lg text-center"><div className="text-3xl font-bold text-green-400">{filteredSpeciesList.length}</div><div className="text-gray-400 text-sm mt-1">Unique Species</div></div>
        <div className="bg-gray-700/50 p-4 rounded-lg text-center"><div className="text-3xl font-bold text-emerald-400">{sightings.length}</div><div className="text-gray-400 text-sm mt-1">Total Sightings</div></div>
        <div className="bg-gray-700/50 p-4 rounded-lg text-center"><div className="text-3xl font-bold text-teal-400">{categories.length}</div><div className="text-gray-400 text-sm mt-1">Categories</div></div>
      </div>

      {categories.length > 0 && <div className="flex items-center gap-3"><Filter size={18} className="text-gray-400" /><select value={filterCategory} onChange={e => setFilterCategory(e.target.value)} className="bg-gray-700 text-white px-4 py-2 rounded-lg border border-gray-600 focus:outline-none focus:ring-2 focus:ring-green-500"><option value="all">All Categories ({speciesList.length})</option>{categories.map(cat => { const count = speciesList.filter(s => s.allSightings.some(sight => sight.category === cat)).length; return <option key={cat} value={cat}>{cat} ({count})</option>;})}</select></div>}

      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-gray-700/50">
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300 border-b border-gray-600 border-r border-gray-700 last:border-r-0">Preview</th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300 border-b border-gray-600 border-r border-gray-700 last:border-r-0">COMMON NAME</th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300 border-b border-gray-600 border-r border-gray-700 last:border-r-0">LATIN NAME</th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300 border-b border-gray-600 border-r border-gray-700 last:border-r-0">{config.secondaryLanguage.toUpperCase()} NAME</th>
              <th className="px-4 py-3 text-center text-sm font-semibold text-gray-300 border-b border-gray-600 border-r border-gray-700 last:border-r-0">FIRST TIMECODE</th>
              <th className="px-4 py-3 text-center text-sm font-semibold text-gray-300 border-b border-gray-600">SIGHTINGS</th>
            </tr>
          </thead>
          <tbody>
            {filteredSpeciesList.map((species, index) => (
              <tr key={index} className={`${index % 2 === 0 ? 'bg-gray-800/40' : 'bg-gray-800/20'} hover:bg-gray-700/30 transition-colors`}>
                <td className="px-4 py-2 border-b border-gray-700/50 border-r border-gray-700 last:border-r-0 w-32">
                   <VideoThumbnail videoUrl={videoPreviewUrl} timecode={species.firstTimecode} className="w-24 h-16 rounded-md" />
                </td>
                <td className="px-4 py-3 text-sm text-gray-300 border-b border-gray-700/50 border-r border-gray-700 last:border-r-0">{species.commonName}</td>
                <td className="px-4 py-3 text-sm text-gray-300 border-b border-gray-700/50 italic border-r border-gray-700 last:border-r-0">{species.latinName}</td>
                <td className="px-4 py-3 text-sm text-gray-300 border-b border-gray-700/50 border-r border-gray-700 last:border-r-0">{species.germanName || '-'}</td>
                <td className="px-4 py-3 text-sm text-center font-mono text-gray-400 border-b border-gray-700/50 border-r border-gray-700 last:border-r-0">{species.firstTimecode}</td>
                <td className="px-4 py-3 text-sm text-center border-b border-gray-700/50"><span className="inline-block px-2 py-1 bg-green-500/20 text-green-300 rounded text-xs font-medium">{species.allSightings.length}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex justify-center gap-4 pt-6 border-t border-gray-700/50"><button onClick={onReset} className="px-6 py-3 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors font-medium">Analyze Another Video</button></div>
    </div>
  );
};

export default FaunaResultView;
