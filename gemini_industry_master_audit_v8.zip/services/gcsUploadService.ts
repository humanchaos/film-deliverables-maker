import { ERROR_IDS, UploadProgress } from '../types';

export interface GCSUploadOptions {
    file: File;
    bucketName: string; // Kept for interface compatibility, but unused (backend decides bucket)
    apiKey: string;     // Unused
    accessToken?: string; // Unused
    onProgress: (progress: UploadProgress) => void;
    signal?: AbortSignal;
}

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8080';

// Chunk size for GCS: 8MB (must be multiple of 256KB)
const GCS_CHUNK_SIZE = 8 * 1024 * 1024;

// DEBUGGING: Log environment info to help diagnose Vercel issues
console.log("[Config Debug]", {
    NODE_ENV: import.meta.env.MODE,
    VITE_API_URL: import.meta.env.VITE_API_URL ? 'Defined' : 'Undefined',
    Constructed_API_URL: API_URL,
    Hostname: window.location.hostname
});

function formatBytes(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * Upload a file to GCS using a Backend-Signed Resumable Upload URL.
 * This supports chunked uploads for large files (1GB+).
 * Returns the gs:// URI (e.g., gs://my-bucket/my-video.mp4)
 */
export async function uploadFileToGCS(options: GCSUploadOptions): Promise<string> {
    const { file, onProgress, signal } = options;

    try {
        // Phase 1: Get Resumable Upload URL from Backend
        onProgress({
            phase: 'initializing',
            message: 'Requesting secure upload link...',
            percentage: 1,
            bytesUploaded: 0,
            totalBytes: file.size,
        });

        // SAFETY CHECK: Warn if using localhost backend on deployed frontend
        if (API_URL.includes('localhost') && !window.location.hostname.includes('localhost')) {
            console.error("CONFIGURATION ERROR: Deployed frontend is trying to reach localhost backend.", { API_URL, origin: window.location.origin });
            throw new Error(`Configuration Error: Backend URL not set. Please set VITE_API_URL in Vercel. (Current: ${API_URL})`);
        }

        const urlResponse = await fetch(`${API_URL}/api/upload-url`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                fileName: file.name,
                contentType: file.type,
                resumable: true // Signal backend we want a resumable session
            }),
            signal
        });

        if (!urlResponse.ok) {
            const errText = await urlResponse.text();
            throw new Error(`Failed to get upload URL: ${urlResponse.status} ${errText}`);
        }

        const { uploadUrl, gcsUri } = await urlResponse.json();

        // Phase 2: Chunked Upload to GCS
        onProgress({
            phase: 'uploading',
            message: 'Starting chunked upload...',
            percentage: 2,
            bytesUploaded: 0,
            totalBytes: file.size,
        });

        const totalBytes = file.size;
        const totalChunks = Math.ceil(totalBytes / GCS_CHUNK_SIZE);
        let bytesUploaded = 0;

        for (let chunkIndex = 0; chunkIndex < totalChunks; chunkIndex++) {
            if (signal?.aborted) throw new Error(ERROR_IDS.OPERATION_CANCELLED);

            const start = chunkIndex * GCS_CHUNK_SIZE;
            const end = Math.min(start + GCS_CHUNK_SIZE, totalBytes);
            const chunkSize = end - start;

            // Read chunk from file
            const chunk = file.slice(start, end);
            const chunkBuffer = await chunk.arrayBuffer();

            // Build Content-Range header
            const contentRange = `bytes ${start}-${end - 1}/${totalBytes}`;

            // Upload chunk with retry
            let lastError: Error | null = null;
            for (let retry = 0; retry <= 3; retry++) {
                try {
                    const response = await fetch(uploadUrl, {
                        method: 'PUT',
                        headers: {
                            'Content-Length': chunkSize.toString(),
                            'Content-Range': contentRange,
                        },
                        body: chunkBuffer,
                        signal,
                    });

                    // GCS returns:
                    // - 308 Resume Incomplete: Chunk received, continue
                    // - 200/201: Upload complete
                    if (response.status === 308 || response.ok) {
                        bytesUploaded = end;

                        const percent = Math.round((bytesUploaded / totalBytes) * 99);
                        onProgress({
                            phase: 'uploading',
                            message: `Uploading to Cloud Storage: ${formatBytes(bytesUploaded)} / ${formatBytes(totalBytes)}`,
                            percentage: percent,
                            bytesUploaded,
                            totalBytes,
                        });

                        break; // Success, move to next chunk
                    }

                    // Handle errors
                    const errorText = await response.text();
                    throw new Error(`GCS Chunk Upload Failed: ${response.status} ${errorText}`);

                } catch (error) {
                    lastError = error as Error;
                    if (signal?.aborted) throw new Error(ERROR_IDS.OPERATION_CANCELLED);

                    if (retry < 3) {
                        const delay = 1000 * Math.pow(2, retry);
                        console.warn(`GCS Chunk ${chunkIndex + 1} failed, retrying in ${delay}ms...`, error);
                        await new Promise(r => setTimeout(r, delay));
                    }
                }
            }

            if (lastError && !signal?.aborted) {
                throw lastError;
            }
        }

        // Phase 3: Complete
        onProgress({
            phase: 'processing',
            message: 'Upload complete. Processing...',
            percentage: 100,
            bytesUploaded: totalBytes,
            totalBytes: totalBytes,
        });

        return gcsUri;

    } catch (error: any) {
        console.error('GCS Upload Failed:', error);
        if (signal?.aborted || error.message === ERROR_IDS.OPERATION_CANCELLED) {
            throw new Error(ERROR_IDS.OPERATION_CANCELLED);
        }
        throw new Error(`Failed to upload video: ${error.message}`);
    }
}
