import { Storage } from '@google-cloud/storage';
import { GoogleAIFileManager, FileState } from "@google/generative-ai/server";
import { GoogleGenerativeAI } from "@google/generative-ai";
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import * as https from 'https';
import { db } from '../config/firebase';
import { config } from '../config/env';
import { JobDocument, FullAnalysisResult } from '../types';
import * as geminiService from './geminiService';
import * as videoIntelligenceService from './videoIntelligenceService';
import { logger } from '../utils/logger';
import { pipeline } from 'stream/promises';

const storage = new Storage();
if (!config.geminiApiKey) {
    logger.warn("GEMINI_API_KEY is missing. Gemini File Manager will fail.");
}
const fileManager = new GoogleAIFileManager(config.geminiApiKey || '');

/**
 * Main Orchestrator for Video Analysis.
 */
export async function performAnalysis(jobId: string, job: JobDocument): Promise<Partial<FullAnalysisResult>> {
    logger.info(`Starting Analysis Coordinator for Job ${jobId}`);

    const { gcsUri, analysisConfig } = job.input;
    // Removed tempFilePath logic (No Disk Usage)
    let geminiFileUri: string | null = null;
    let geminiFileName: string | null = null;
    const results: Partial<FullAnalysisResult> = {};

    try {
        // 1. PREPARATION: Stream to Gemini (if needed)
        const needsGemini = analysisConfig.synopsis || analysisConfig.fauna ||
            analysisConfig.graphics || analysisConfig.transcription || analysisConfig.cast;

        if (needsGemini) {
            await updateProgress(jobId, 'preparing', 5, 'Streaming video from GCS to Gemini...');

            // STREAMING UPLOAD (No Disk Buffer)
            const uploadResult = await streamGcsToGeminiChunked(gcsUri, 'video/mp4', config.geminiApiKey || '', jobId);

            geminiFileUri = uploadResult.uri;
            geminiFileName = uploadResult.name; // "files/..." name

            await updateProgress(jobId, 'preparing', 15, 'Waiting for Gemini processing...');
            await waitForGeminiFileActive(geminiFileName);
        }

        // 2. PARALLEL EXECUTION
        const promises: Promise<any>[] = [];

        // --- A. Video Intelligence (Pro Mode) ---
        if (analysisConfig.videoIntelligence) {
            promises.push((async () => {
                try {
                    await updateModuleStatus(jobId, 'shotList', 'processing', 0);
                    // 1. Get raw annotations
                    const result = await videoIntelligenceService.annotateVideo(gcsUri, ['SHOT_CHANGE_DETECTION', 'LABEL_DETECTION'] as any);

                    // 2. Transform into Frontend-Ready "Shot" Objects
                    // VI API returns shots with startTimeOffset strings (e.g. "10.5s")
                    const formattedShots = mapVideoIntelligenceToShots(result, job.input.duration || 0);

                    // 3. Assign to Results
                    results.shotList = formattedShots;

                    await updateModuleStatus(jobId, 'shotList', 'completed', 100);
                } catch (e: any) {
                    logger.error("Video Intelligence Failed", e);
                    await updateModuleStatus(jobId, 'shotList', 'failed', 0, e.message);
                }
            })());
        }

        // --- B. Gemini Modules ---
        if (geminiFileUri) {
            // 1. Synopsis
            if (analysisConfig.synopsis) {
                promises.push(runModule(jobId, 'synopsis', async () => {
                    const analysis = await geminiService.analyzeVideoContent(geminiFileUri!, 'video/mp4');
                    return geminiService.generateSynopsisFromAnalysis(
                        analysis, 'AI Writer', 'AI Director', 'English', '', job.input.analysisConfig as any // reusing config
                    );
                }, results));
            }

            // 2. Fauna
            if (analysisConfig.fauna) {
                promises.push(runModule(jobId, 'fauna', async () => {
                    return geminiService.analyzeVideoForSpecies(geminiFileUri!, 'video/mp4', 'English', 'German', job.input.duration || 0);
                }, results));
            }

            // 3. Graphics
            if (analysisConfig.graphics) {
                promises.push(runModule(jobId, 'graphics', async () => {
                    return geminiService.analyzeGraphicsAndLowerThirds(geminiFileUri!, 'video/mp4', job.input.duration || 0, 'Unknown Title');
                }, results));
            }

            // 4. Transcription
            if (analysisConfig.transcription) {
                promises.push(runModule(jobId, 'transcription', async () => {
                    return geminiService.transcribeMedia(geminiFileUri!, 'video/mp4', job.input.duration || 0);
                }, results));
            }
        }

        await Promise.all(promises);
        return results;

    } catch (error) {
        logger.error("Analysis Coordinator Critical Error", error);
        throw error;
    } finally {
        if (geminiFileName) {
            try {
                await fileManager.deleteFile(geminiFileName);
                logger.info(`Deleted Gemini file: ${geminiFileName}`);
            } catch (e) {
                logger.warn(`Failed to delete Gemini file: ${geminiFileName}`, e);
            }
        }
    }
}

// Helper to standardise module execution & error handling
async function runModule(jobId: string, moduleName: string, action: () => Promise<any>, resultsObj: any) {
    try {
        await updateModuleStatus(jobId, moduleName, 'processing', 0);
        const res = await action();
        resultsObj[moduleName] = res;
        await updateModuleStatus(jobId, moduleName, 'completed', 100);
    } catch (e: any) {
        logger.error(`Module ${moduleName} Failed`, e);
        await updateModuleStatus(jobId, moduleName, 'failed', 0, e.message);
    }
}

// ---------------------------------------------------------------------------
// STREAMING UPLOAD IMPLEMENTATION
// ---------------------------------------------------------------------------

const GEMINI_CHUNK_SIZE = 32 * 1024 * 1024; // 32MB

async function streamGcsToGeminiChunked(
    gcsUri: string,
    mimeType: string,
    apiKey: string,
    jobId?: string
): Promise<{ name: string; uri: string }> {
    const matches = gcsUri.match(/gs:\/\/([^\/]+)\/(.+)/);
    if (!matches) throw new Error(`Invalid GCS URI: ${gcsUri}`);

    const bucket = storage.bucket(matches[1]);
    const gcsFile = bucket.file(matches[2]);
    const [metadata] = await gcsFile.getMetadata();
    const fileSize = parseInt(metadata.size as string, 10);

    // 1. Initialize resumable session
    const initRes = await fetch(
        `https://generativelanguage.googleapis.com/upload/v1beta/files?key=${apiKey}`,
        {
            method: 'POST',
            headers: {
                'X-Goog-Upload-Protocol': 'resumable',
                'X-Goog-Upload-Command': 'start',
                'X-Goog-Upload-Header-Content-Length': fileSize.toString(),
                'X-Goog-Upload-Header-Content-Type': mimeType,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ file: { display_name: matches[2] } })
        }
    );

    const uploadUrl = initRes.headers.get('x-goog-upload-url');
    if (!uploadUrl) throw new Error('No upload URL received from Gemini.');

    // 2. Upload in chunks with progress
    const totalChunks = Math.ceil(fileSize / GEMINI_CHUNK_SIZE);

    for (let i = 0; i < totalChunks; i++) {
        const start = i * GEMINI_CHUNK_SIZE;
        const end = Math.min(start + GEMINI_CHUNK_SIZE, fileSize);
        const isLast = i === totalChunks - 1;

        // Read chunk from GCS
        // Note: Explicitly handling buffer memory
        let chunkBuffer: Buffer | null = await readGcsRange(gcsFile, start, end - 1);

        const response = await fetch(uploadUrl, {
            method: 'POST',
            headers: {
                'X-Goog-Upload-Command': isLast ? 'upload, finalize' : 'upload',
                'X-Goog-Upload-Offset': start.toString(),
                'Content-Length': chunkBuffer.length.toString(),
            },
            // @ts-ignore
            body: chunkBuffer
        });

        // Memory Management: Clear buffer immediately after send
        chunkBuffer = null;

        if (!response.ok) throw new Error(`Gemini Chunk Upload ${i} failed: ${response.status}`);

        // Update progress
        if (jobId) {
            const pct = Math.round((end / fileSize) * 100);
            // Map upload progress to 5-25% of overall progress
            await updateProgress(jobId, 'preparing', 5 + (pct * 0.20), `Uploading to AI: ${pct}%`);
        }

        if (isLast) {
            const result = await response.json();
            // @ts-ignore
            return result.file;
        }
    }

    throw new Error('Gemini Upload failed to finalize.');
}

async function readGcsRange(file: any, start: number, end: number): Promise<Buffer> {
    const chunks: Buffer[] = [];
    const stream = file.createReadStream({ start, end });
    for await (const chunk of stream) chunks.push(Buffer.from(chunk));
    return Buffer.concat(chunks);
}

// Optimized Waiter with 60m Timeout
async function waitForGeminiFileActive(name: string) {
    logger.info(`Waiting for Gemini file ${name} to be ACTIVE...`);
    const startTime = Date.now();
    const TIMEOUT_MS = 60 * 60 * 1000; // Increased to 60 Minutes (Fix 2)

    let file = await fileManager.getFile(name);
    while (file.state === FileState.PROCESSING) {
        if (Date.now() - startTime > TIMEOUT_MS) throw new Error(`Timeout waiting for Gemini processing on ${name}`);
        await new Promise(r => setTimeout(r, 5000)); // 5s poll
        file = await fileManager.getFile(name);
    }
    if (file.state === FileState.FAILED) throw new Error("Gemini Processing Failed");
    logger.info("Gemini File ACTIVE");
}

async function updateProgress(jobId: string, stage: string, percentage: number, message: string) {
    await db.collection('jobs').doc(jobId).update({
        'progress.overall': percentage,
        'progress.currentStage': message,
        updatedAt: new Date()
    });
}

async function updateModuleStatus(jobId: string, module: string, status: string, progress: number, error?: string) {
    const update: any = { [`progress.modules.${module}.status`]: status, [`progress.modules.${module}.progress`]: progress };
    if (error) update[`progress.modules.${module}.error`] = error;
    await db.collection('jobs').doc(jobId).update(update);
}

export const canRunServerSide = (job: JobDocument) => {
    // If we have a GCS URI and a valid Job ID, we are authorized by the system
    // The Worker Service Account handles the Google API auth, not the user.
    return !!job.input.gcsUri;
};

// ---------------------------------------------------------------------------
// DATA MAPPING HELPERS
// ---------------------------------------------------------------------------

function mapVideoIntelligenceToShots(result: any, duration: number): any[] {
    if (!result.shotAnnotations && !result.shotChangeAnnotations) return [];

    // Some versions use shotAnnotations, others shotChangeAnnotations
    const shotsRaw = result.shotAnnotations || result.shotChangeAnnotations || [];

    return shotsRaw.map((shot: any, index: number) => {
        // VI API returns "10s" or "10.5s" strings
        const startSec = parseOffset(shot.startTimeOffset);
        const endSec = parseOffset(shot.endTimeOffset);
        const shotDuration = endSec - startSec;

        return {
            tcIn: secondsToTimecode(startSec),
            tcOut: secondsToTimecode(endSec),
            duration: secondsToTimecode(shotDuration),
            description: `Shot ${index + 1} (Auto-detected)`,
            action: "Visual scene change detected",
            audio: "", // VI API doesn't give audio context in this mode
        };
    });
}

function parseOffset(offset: string | undefined | null): number {
    if (!offset) return 0;
    // Format is usually "12.345s"
    return parseFloat(offset.replace('s', ''));
}

function secondsToTimecode(totalSeconds: number, frameRate: number = 25): string {
    if (isNaN(totalSeconds)) return "00:00:00:00";

    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = Math.floor(totalSeconds % 60);
    const frames = Math.round((totalSeconds % 1) * frameRate);

    const pad = (n: number) => n.toString().padStart(2, '0');
    return `${pad(hours)}:${pad(minutes)}:${pad(seconds)}:${pad(frames)}`;
}
