import { Request, Response } from 'express';
import { db } from '../config/firebase';
import { logger } from '../utils/logger';
import { Timestamp, FieldValue } from 'firebase-admin/firestore';
import { JobDocument } from '../types';
import { performAnalysis } from '../services/analysisCoordinator';
import { storageService } from '../services/storageService';
import { transcoderService } from '../services/transcoderService';
import { CloudTasksClient } from '@google-cloud/tasks';
import { config } from '../config/env';

const tasksClient = new CloudTasksClient();

export const processJob = async (req: Request, res: Response) => {
    const { jobId, type, gcsUri, proxyJobName, moduleName } = req.body;

    if (!jobId) {
        logger.error('Worker received request without jobId');
        return res.status(400).send('Missing jobId');
    }

    logger.info(`Worker received task: ${type || 'initialize'} for ${jobId}`);

    try {
        // -------------------------------------------------------------------
        // 1. ORCHESTRATOR / INITIALIZER (Default entry point)
        // -------------------------------------------------------------------
        if (!type || type === 'initialize') {
            const jobRef = db.collection('jobs').doc(jobId);
            const jobDoc = await jobRef.get();

            if (!jobDoc.exists) {
                logger.error(`Job ${jobId} not found`);
                return res.status(404).send('Job not found');
            }
            const job = jobDoc.data() as JobDocument;

            // Idempotency check: If job is already 'completed' or 'failed', stop.
            if (job.status === 'completed' || job.status === 'failed') {
                return res.status(200).send('Job already finished');
            }

            // A. Check if Transcode Needed
            if (!proxyJobName) {
                // If we already have a proxy job recorded, use it (retry case)
                if (job.transcoderJobName) {
                    await enqueueTask({
                        jobId,
                        type: 'initialize',
                        proxyJobName: job.transcoderJobName
                    }, 10);
                    return res.send({ status: 'polling_existing_transcode' });
                }

                // Start New Transcode
                const masterUri = job.input.gcsUri;
                const proxyUri = `gs://${process.env.GCS_RESULTS_BUCKET || 'gemini-video-results'}/jobs/${jobId}/proxy/`;

                logger.info(`Starting transcoding for ${jobId}`, { masterUri, proxyUri });

                try {
                    const jobName = await transcoderService.createProxyJob(masterUri, proxyUri);

                    await jobRef.update({
                        status: 'transcoding',
                        transcoderJobName: jobName,
                        updatedAt: Timestamp.now(),
                        'progress.currentStage': 'Transcoding video...'
                    });

                    // Poll status
                    await enqueueTask({ jobId, type: 'initialize', proxyJobName: jobName }, 30);
                    return res.send({ status: 'transcode_started', jobName });
                } catch (e: any) {
                    logger.error("Transcode start failed", e);
                    // Fallback?? Or Fail?
                    // For now fail.
                    await jobRef.update({
                        status: 'failed',
                        error: { code: 'TRANSCODE_ERROR', message: e.message }
                    });
                    return res.status(500).send('Transcode failed');
                }
            }

            // B. Poll Transcode Status
            const status = await transcoderService.getJobStatus(proxyJobName);
            logger.info(`Transcode status for ${jobId}: ${status}`);

            if (status === 'SUCCEEDED') {
                const proxyFileUri = `gs://${process.env.GCS_RESULTS_BUCKET || 'gemini-video-results'}/jobs/${jobId}/proxy/proxy.mp4`;

                // FAN OUT
                // We determine which modules to run based on job.input.analysisConfig
                // But for simplicity/robustness, we can just run the active ones.
                const config = job.input.analysisConfig;
                const modules = [];
                if (config.transcription) modules.push('transcription');
                if (config.shotList || config.videoIntelligence) modules.push('shotList'); // Map both to shotList module handling
                if (config.fauna) modules.push('fauna');
                if (config.synopsis) modules.push('synopsis');
                if (config.graphics) modules.push('graphics');
                if (config.cast) modules.push('cast');

                logger.info(`Fanning out tasks for: ${modules.join(', ')}`);

                await Promise.all(modules.map(mod =>
                    enqueueTask({
                        type: 'module_process',
                        jobId,
                        gcsUri: proxyFileUri,
                        moduleName: mod
                    })
                ));

                await jobRef.update({
                    status: 'processing',
                    'progress.currentStage': 'Analyzing video modules...',
                    updatedAt: Timestamp.now()
                });

                return res.send({ status: 'fanned_out' });

            } else if (status === 'FAILED') {
                await jobRef.update({
                    status: 'failed',
                    error: { code: 'TRANSCODE_FAILED', message: 'Video transcoding failed' }
                });
                return res.status(200).send('Transcode failed'); // 200 to stop retry
            } else {
                // PENDING or PROCESSING -> Wait more
                // SAFETY GUARD: If transcoding takes > 20 minutes, something is likely wrong with the GCP Job
                const lastUpdate = job.updatedAt?.toMillis() || Date.now();
                const diffMin = (Date.now() - lastUpdate) / 1000 / 60;

                if (diffMin > 20) {
                    logger.error(`Transcode timeout for ${jobId} after ${Math.round(diffMin)} minutes`);
                    await jobRef.update({
                        status: 'failed',
                        error: { code: 'TRANSCODE_TIMEOUT', message: 'Video transcoding timed out after 20 minutes.' }
                    });
                    return res.status(200).send('Transcode timed out');
                }

                await enqueueTask(req.body, 30);
                return res.send({ status: 'waiting_transcode' });
            }
        }

        // -------------------------------------------------------------------
        // 2. MODULE PROCESSOR
        // -------------------------------------------------------------------
        if (type === 'module_process') {
            await processModule(jobId, moduleName, gcsUri);
            return res.status(200).send(`Module ${moduleName} processed`);
        }

    } catch (error: any) {
        logger.error(`Worker failed processing job: ${jobId}`, error);

        // Retry logic handled by Cloud Tasks configuration mostly, but we can signal error
        if (error.code === 429 || error.code === 503) {
            return res.status(500).send('Transient failure');
        }
        // If it's a critical error in orchestration, we might want to log it and stop
        return res.status(500).send(error.message);
    }
};

async function enqueueTask(payload: any, delaySeconds = 0) {
    if (!config.projectId || !config.queueName || !config.location || !config.workerUrl) {
        logger.warn(`Cloud Tasks not configured. Mocking enqueue: ${JSON.stringify(payload)}`);
        // If local, we can't really "wait". In a real local env, we might validly just return.
        // But "Boring Reliability" usually implies Prod.
        return;
    }

    const parent = tasksClient.queuePath(config.projectId, config.location, config.queueName);

    // Construct the correct URL. The worker is existing at /workers/process (likely verified via existing jobs.ts)
    const url = config.workerUrl.endsWith('/workers/process')
        ? config.workerUrl
        : `${config.workerUrl}/workers/process`;

    const taskRequest = {
        httpMethod: 'POST',
        url,
        body: Buffer.from(JSON.stringify(payload)).toString('base64'),
        headers: { 'Content-Type': 'application/json' },
        oidcToken: config.serviceAccountEmail ? { serviceAccountEmail: config.serviceAccountEmail } : undefined
    };

    const task: any = { httpRequest: taskRequest };
    if (delaySeconds > 0) {
        task.scheduleTime = { seconds: Date.now() / 1000 + delaySeconds };
    }

    await tasksClient.createTask({ parent, task });
}

async function processModule(jobId: string, moduleName: string, gcsUri: string) {
    const jobRef = db.collection('jobs').doc(jobId);
    const jobDoc = await jobRef.get();
    if (!jobDoc.exists) return; // Should not happen

    const job = jobDoc.data() as JobDocument;

    // Create a modified job object that ONLY enables the specific module
    // This allows re-using performAnalysis without major refactor
    const specificJob = {
        ...job,
        input: {
            ...job.input,
            gcsUri: gcsUri, // Use PROXY URI
            analysisConfig: {
                // Disable all others, enable only this one
                transcription: moduleName === 'transcription',
                shotList: moduleName === 'shotList',
                videoIntelligence: moduleName === 'shotList', // Mapping
                fauna: moduleName === 'fauna',
                synopsis: moduleName === 'synopsis',
                graphics: moduleName === 'graphics',
                cast: moduleName === 'cast'
            }
        }
    };

    logger.info(`Processing module ${moduleName} for ${jobId} with proxy ${gcsUri}`);

    // Perform Analysis (Now scoped to just this module effectively)
    const partialResults = await performAnalysis(jobId, specificJob as JobDocument);
    const data = partialResults[moduleName as keyof typeof partialResults];

    if (data) {
        // Offload Logic
        const pointer = await storageService.saveLargeResult(jobId, moduleName, data);

        // Update Job with Result/Pointer AND Status
        await jobRef.update({
            [`results.${moduleName}`]: pointer,
            [`progress.modules.${moduleName}.status`]: 'completed',
            [`progress.modules.${moduleName}.progress`]: 100,
            updatedAt: Timestamp.now()
        });
    }

    // Check Completion
    // We check if all requested modules in the ORIGINAL job config have results or are completed.
    // Note: This is racy if multiple modules finish exactly same time. 
    // Firestore transactions could solve this, or we just trust eventual consistency.
    // simpler: Check if all enabled keys in job.input.analysisConfig exist in the UPDATED document.

    const updatedDoc = await jobRef.get();
    const updatedJob = updatedDoc.data() as JobDocument;
    const originalConfig = updatedJob.input.analysisConfig;

    const requiredModules = [];
    if (originalConfig.transcription) requiredModules.push('transcription');
    if (originalConfig.shotList || originalConfig.videoIntelligence) requiredModules.push('shotList');
    if (originalConfig.fauna) requiredModules.push('fauna');
    if (originalConfig.synopsis) requiredModules.push('synopsis');
    if (originalConfig.graphics) requiredModules.push('graphics');
    if (originalConfig.cast) requiredModules.push('cast');

    const allDone = requiredModules.every(mod => {
        const mStatus = updatedJob.progress?.modules?.[mod as keyof typeof updatedJob.progress.modules]?.status;
        return mStatus === 'completed' || mStatus === 'failed';
    });

    if (allDone) {
        await jobRef.update({
            status: 'completed',
            'progress.overall': 100,
            'progress.currentStage': 'Analysis Complete', // Matches legacy string
            hasSubcollections: false
        });
        logger.info(`Job ${jobId} fully completed.`);
    }
}

