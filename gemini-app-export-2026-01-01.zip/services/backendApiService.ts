
import { JobDocument, FullAnalysisResult } from '../types';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'https://gemini-video-backend-193471035724.europe-west3.run.app';

export class BackendApiService {
    /**
     * Creates a new analysis job.
     * @param gcsUri The GCS URI of the video file (must be gs://...).
     * @param mimeType The mime type (e.g., video/mp4).
     * @param duration Optional duration in seconds.
     */
    static async createJob(gcsUri: string, mimeType: string, duration: number = 0): Promise<string> {
        console.log(`[BackendAPI] Creating job for ${gcsUri}`);
        const response = await fetch(`${API_BASE_URL}/api/jobs`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                gcsUri,
                mimeType,
                duration,
                analysisConfig: {} // Config for all modules enabled by default
            })
        });

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Failed to create job: ${response.status} ${errorText}`);
        }

        const data = await response.json();
        return data.id;
    }

    /**
     * Fetches the current status of a job.
     */
    static async getJob(jobId: string): Promise<JobDocument> {
        const response = await fetch(`${API_BASE_URL}/api/jobs/${jobId}`);
        if (!response.ok) {
            throw new Error(`Failed to fetch job: ${response.status}`);
        }
        return await response.json();
    }

    /**
     * Polls the job status until it is completed or failed.
     * @param jobId The ID of the job to monitor.
     * @param onProgress Callback for progress updates.
     * @param signal AbortSignal to cancel polling.
     */
    static async pollJob(
        jobId: string,
        onProgress: (status: string, percentage: number) => void,
        signal?: AbortSignal
    ): Promise<FullAnalysisResult> {
        let attempts = 0;
        const maxAttempts = 360; // 30 minutes
        const delay = 5000;

        while (attempts < maxAttempts) {
            if (signal?.aborted) throw new Error('Operation cancelled');

            const job = await this.getJob(jobId);

            // Update Progress
            const stage = job.progress?.currentStage || 'Processing...';
            const percent = job.progress?.overall || 0;
            onProgress(stage, percent);

            if (job.status === 'completed') {
                if (!job.results) throw new Error('Job completed but results are missing.');
                return job.results as unknown as FullAnalysisResult;
            }

            if (job.status === 'failed') {
                throw new Error(job.error?.message || 'Job failed during processing');
            }

            attempts++;
            await new Promise(resolve => setTimeout(resolve, delay));
        }

        throw new Error('Analysis timed out');
    }
}
