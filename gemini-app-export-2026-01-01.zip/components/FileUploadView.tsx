import React, { useRef, useState, DragEvent, useEffect } from 'react';
import { getAllCachedUploads, CachedUpload } from '../services/uploadService';
import { FileVideo, ArrowRight, Settings } from 'lucide-react';

interface FileUploadViewProps {
  onFileSelect: (file: File) => void;
  onUriSelect?: (uri: string) => void;
  onOpenSettings?: () => void;
}

const FileUploadView: React.FC<FileUploadViewProps> = ({ onFileSelect, onUriSelect, onOpenSettings }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [recentUploads, setRecentUploads] = useState<CachedUpload[]>([]);

  useEffect(() => {
    // Load cached uploads on mount
    setRecentUploads(getAllCachedUploads());
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onFileSelect(file);
    }
  };

  const handleDragEnter = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const file = e.dataTransfer.files[0];
    if (file) {
      onFileSelect(file);
    }
  };

  return (
    <div
      className={`min-h-[80vh] flex flex-col items-center justify-center relative transition-colors duration-300 ${isDragging ? 'bg-zinc-900' : 'bg-transparent'}`}
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
    >
      {/* Settings Access */}
      {onOpenSettings && (
        <button
          onClick={onOpenSettings}
          className="absolute top-4 right-4 p-2 text-zinc-500 hover:text-[#ccff00] transition-colors z-50"
          title="Login & Settings"
        >
          <Settings className="w-6 h-6" />
        </button>
      )}
      {/* Main Content */}
      <div className="text-center space-y-2 z-10">
        <h1 className="text-[12rem] leading-none font-serif text-white tracking-tighter mix-blend-difference select-none">
          NEVER<span className="text-[#ccff00]">.</span>
        </h1>

        <div className="flex flex-col space-y-1 py-8">
          <p className="font-mono text-zinc-500 text-xl tracking-wider">Frame-accurate.</p>
          <p className="font-mono text-zinc-500 text-xl tracking-wider">Fully automatic.</p>
          <p className="font-mono text-zinc-500 text-xl tracking-wider">Industry Standard</p>
          <p className="font-mono text-zinc-500 text-xl tracking-wider">Deliverables.</p>
        </div>

        <p className="font-serif italic text-white text-4xl pt-8 pb-12 opacity-90">
          Go take a break.
        </p>

        <button
          onClick={() => fileInputRef.current?.click()}
          className="group bg-[#ccff00] hover:bg-[#bbe600] text-black font-mono text-sm tracking-widest px-8 py-4 uppercase transition-all duration-300 transform hover:scale-105 flex items-center gap-2 mx-auto"
        >
          Start Uploading
          <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="video/mp4,video/quicktime,video/webm,video/x-msvideo,video/x-matroska"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Drag Overlay Indicator */}
      {isDragging && (
        <div className="absolute inset-0 border-4 border-[#ccff00] bg-black/50 backdrop-blur-sm flex items-center justify-center pointer-events-none z-50">
          <p className="text-[#ccff00] font-mono text-2xl animate-pulse">DROP VIDEO FILE HERE</p>
        </div>
      )}

      {/* Recent Uploads Library - kept minimal at bottom */}
      {recentUploads.length > 0 && onUriSelect && (
        <div className="absolute bottom-8 w-full max-w-xl opacity-50 hover:opacity-100 transition-opacity">
          <div className="flex flex-col gap-2">
            <div className="text-center text-xs font-mono text-zinc-600 uppercase tracking-widest mb-2">Recent Sessions</div>
            <div className="flex flex-wrap justify-center gap-2">
              {recentUploads.slice(0, 3).map((upload) => (
                <button
                  key={`${upload.name}-${upload.timestamp}`}
                  onClick={() => onUriSelect(upload.uri)}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-400 text-xs hover:border-[#ccff00] hover:text-[#ccff00] transition-colors"
                >
                  <FileVideo size={12} />
                  <span className="truncate max-w-[100px]">{upload.name}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FileUploadView;
