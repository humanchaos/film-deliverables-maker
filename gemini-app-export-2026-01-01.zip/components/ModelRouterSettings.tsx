import React, { useState, useEffect } from 'react';
import { modelRouter } from '../services/llm/ModelRouter';
import { DeepSeekProvider } from '../services/llm/DeepSeekProvider';
import { Save, Server, Cpu, Key, AlertTriangle } from 'lucide-react';

export const ModelRouterSettings: React.FC = () => {
    const [deepSeekKey, setDeepSeekKey] = useState('');
    const [activeProvider, setActiveProvider] = useState(modelRouter.getActiveProvider().id);
    const [providers, setProviders] = useState(modelRouter.getAllProviders());

    useEffect(() => {
        const storedKey = localStorage.getItem('DEEPSEEK_API_KEY');
        if (storedKey) setDeepSeekKey(storedKey);
    }, []);

    const handleSaveKey = () => {
        if (deepSeekKey.trim()) {
            localStorage.setItem('DEEPSEEK_API_KEY', deepSeekKey);
            // Dynamically register/update
            modelRouter.registerProvider(new DeepSeekProvider(deepSeekKey));
            setProviders(modelRouter.getAllProviders());
            alert('DeepSeek Key Saved & Provider Registered!');
        }
    };

    const handleProviderChange = (id: string) => {
        modelRouter.setActiveProvider(id);
        setActiveProvider(id);
    };

    return (
        <div className="bg-gray-900 border border-gray-700 rounded-lg p-6 max-w-2xl mx-auto my-8">
            <div className="flex items-center gap-3 mb-6">
                <div className="bg-blue-500/20 p-3 rounded-full">
                    <Server className="text-blue-400" size={24} />
                </div>
                <div>
                    <h2 className="text-2xl font-bold text-white">Model Router ("The Switchboard")</h2>
                    <p className="text-gray-400 text-sm">Decouple your intelligence. Switch brains on the fly.</p>
                </div>
            </div>

            <div className="space-y-6">
                {/* Active Provider Selection */}
                <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
                    <label className="block text-gray-300 font-semibold mb-3 flex items-center gap-2">
                        <Cpu size={18} />
                        Active Intelligence Provider
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {providers.map(p => (
                            <button
                                key={p.id}
                                onClick={() => handleProviderChange(p.id)}
                                className={`p-4 rounded border text-left transition-all ${activeProvider === p.id
                                        ? 'bg-blue-900/40 border-blue-500 ring-1 ring-blue-500'
                                        : 'bg-gray-700 border-gray-600 hover:bg-gray-650'
                                    }`}
                            >
                                <div className="font-bold text-white">{p.name}</div>
                                <div className="text-xs text-gray-400 mt-1">{p.description}</div>
                            </button>
                        ))}
                    </div>
                </div>

                {/* API Key Management */}
                <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
                    <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                        <Key size={18} />
                        Provider Keys (Stored Locally)
                    </h3>

                    <div className="space-y-4">
                        <div>
                            <label className="block text-xs uppercase text-gray-500 font-bold mb-1">DeepSeek API Key</label>
                            <div className="flex gap-2">
                                <input
                                    type="password"
                                    value={deepSeekKey}
                                    onChange={(e) => setDeepSeekKey(e.target.value)}
                                    placeholder="sk-..."
                                    className="flex-1 bg-gray-900 border border-gray-600 rounded px-3 py-2 text-white placeholder-gray-600 focus:border-blue-500 focus:outline-none"
                                />
                                <button
                                    onClick={handleSaveKey}
                                    className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded flex items-center gap-2 font-bold"
                                >
                                    <Save size={18} />
                                    Save
                                </button>
                            </div>
                            <p className="text-xs text-gray-500 mt-1">
                                Using <code className="bg-gray-700 px-1 rounded">deepseek-chat</code> (V3) or <code className="bg-gray-700 px-1 rounded">deepseek-reasoner</code> (R1).
                            </p>
                        </div>
                    </div>
                </div>

                {activeProvider !== 'gemini' && (
                    <div className="bg-amber-900/30 border border-amber-500/30 rounded p-4 flex items-start gap-3">
                        <AlertTriangle className="text-amber-500 shrink-0 mt-0.5" size={20} />
                        <div>
                            <h4 className="text-amber-400 font-bold text-sm">Visual Fallback Active</h4>
                            <p className="text-amber-200/70 text-xs mt-1">
                                {providers.find(p => p.id === activeProvider)?.name} does not support Video Analysis.
                                Video tasks will automatically fall back to **Google Gemini**.
                            </p>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};
