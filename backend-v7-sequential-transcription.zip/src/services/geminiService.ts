import { GoogleGenerativeAI, SchemaType as Type } from "@google/generative-ai";
import { GoogleAIFileManager, FileState } from "@google/generative-ai/server";
import { Storage } from '@google-cloud/storage';
import { config } from '../config/env';
import {
    AnalysisResult,
    Synopsis,
    SynopsisConfig,
    GraphicsAnalysisResult,
    TranscriptionResult,
    SpeciesSighting
} from '../types';
import * as fs from 'fs';
import * as os from 'os';
import * as path from 'path';

// Initialize the Official SDK
const genAI = new GoogleGenerativeAI(config.geminiApiKey || '');
const fileManager = new GoogleAIFileManager(config.geminiApiKey || '');
const storage = new Storage();

// ═══════════════════════════════════════════════════════════════════════════════
// GEMINI FILES API UPLOAD (Download from GCS, upload to Gemini)
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Downloads a video from GCS and uploads it to Gemini Files API.
 * Returns the Gemini file URI for use in analysis.
 * Caches the URI in Firestore to avoid re-uploading.
 */
export async function uploadGCSVideoToGemini(gcsUri: string, mimeType: string, jobId: string): Promise<string> {
    console.log(`[GeminiUpload] Uploading ${gcsUri} to Gemini Files API...`);

    // Parse GCS URI: gs://bucket/path/to/file.mp4
    const match = gcsUri.match(/^gs:\/\/([^\/]+)\/(.+)$/);
    if (!match) {
        throw new Error(`Invalid GCS URI: ${gcsUri}`);
    }
    const [, bucket, filePath] = match;

    // Create temp file path
    const tempFileName = `gemini_upload_${jobId}_${Date.now()}${path.extname(filePath)}`;
    const tempFilePath = path.join(os.tmpdir(), tempFileName);

    try {
        // 1. Download from GCS to temp file
        console.log(`[GeminiUpload] Downloading from GCS to ${tempFilePath}...`);
        await storage.bucket(bucket).file(filePath).download({
            destination: tempFilePath
        });

        const stats = fs.statSync(tempFilePath);
        console.log(`[GeminiUpload] Downloaded ${(stats.size / 1024 / 1024).toFixed(2)} MB`);

        // 2. Upload to Gemini Files API
        console.log(`[GeminiUpload] Uploading to Gemini Files API...`);
        const uploadResult = await fileManager.uploadFile(tempFilePath, {
            mimeType: mimeType,
            displayName: `job_${jobId}_video`,
        });

        console.log(`[GeminiUpload] Upload started, file: ${uploadResult.file.name}`);

        // 3. Wait for file processing to complete
        let file = uploadResult.file;
        while (file.state === FileState.PROCESSING) {
            console.log(`[GeminiUpload] Waiting for file processing...`);
            await new Promise(r => setTimeout(r, 5000));
            const getFileResult = await fileManager.getFile(file.name);
            file = getFileResult;
        }

        if (file.state === FileState.FAILED) {
            throw new Error(`Gemini file processing failed: ${file.name}`);
        }

        console.log(`[GeminiUpload] File ready: ${file.uri}`);
        return file.uri;

    } finally {
        // Clean up temp file
        try {
            fs.unlinkSync(tempFilePath);
            console.log(`[GeminiUpload] Cleaned up temp file`);
        } catch (e) {
            // Ignore cleanup errors
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// UTILITY FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════════

function repairJson(jsonString: string): string {
    let fixed = jsonString.trim();
    // 1. Remove Markdown code blocks
    fixed = fixed.replace(/^```(json)?|```$/g, '');
    // 2. Extract JSON object/array if embedded in text
    const jsonMatch = fixed.match(/(\{[\s\S]*\}|\[[\s\S]*\])/);
    if (jsonMatch) {
        fixed = jsonMatch[0];
    }
    // 3. Fix trailing commas (common AI error)
    fixed = fixed.replace(/,(\s*[}\]])/g, '$1');
    return fixed;
}

function safeJsonParse<T>(jsonString: string): T {
    try {
        const cleanString = repairJson(jsonString);
        if (!cleanString) throw new Error("Empty JSON response");
        return JSON.parse(cleanString);
    } catch (e) {
        console.warn("Initial JSON parse failed, attempting aggressive repair...", e);
        try {
            let aggressiveFix = jsonString.replace(/,(\s*)/g, ',$1');
            aggressiveFix = aggressiveFix.replace(/([}\]])[\s\S]*$/, '$1');
            return JSON.parse(repairJson(aggressiveFix));
        } catch (e2) {
            console.error("Failed to parse JSON response:", jsonString, e2);
            throw new Error("INVALID_API_RESPONSE");
        }
    }
}

function formatDuration(seconds: number): string {
    if (isNaN(seconds) || seconds < 0) return "00:00:00";
    const totalSeconds = Math.floor(seconds);
    const h = Math.floor(totalSeconds / 3600), m = Math.floor((totalSeconds % 3600) / 60), s = totalSeconds % 60;
    return [h, m, s].map(v => String(v).padStart(2, '0')).join(':');
}

// ═══════════════════════════════════════════════════════════════════════════════
// SYNOPSIS GENERATION
// ═══════════════════════════════════════════════════════════════════════════════

export const analyzeVideoContent = async (
    fileUri: string,
    mimeType: string
): Promise<AnalysisResult> => {
    console.log(`[DEEP-DEBUG] analyzeVideoContent called`);
    console.log(`[DEEP-DEBUG] fileUri: ${fileUri}`);
    console.log(`[DEEP-DEBUG] mimeType: ${mimeType}`);
    console.log(`[DEEP-DEBUG] API Key present: ${!!config.geminiApiKey}`);
    console.log(`[DEEP-DEBUG] API Key first 10 chars: ${config.geminiApiKey?.substring(0, 10)}...`);

    try {
        const prompt = `
      You are an expert video analysis AI. Analyze the provided video file.
      Your task is to synthesize all information into a final, cohesive analysis in JSON format.
      - Transcribe spoken words if present.
      - Summarize the entire video in one sentence.
      - Create a single, chronological list of the most important key events.
      - Infer any potential dialogue or important sounds based on visual cues if audio is unclear.
      
      **CRITICAL:** Base all descriptions strictly on the video content. Do not invent details not present in the video.
    `;

        const modelConfig: any = {
            model: 'gemini-2.0-flash', // Updated to 2.0 Flash (1.5 models deprecated)
            generationConfig: {
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        summary: { type: Type.STRING, description: "A brief, one-sentence summary of the video's content." },
                        events: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    timestamp: { type: Type.STRING, description: "Approximate time or sequence of the event (e.g., '00:05', 'Beginning', 'Middle')." },
                                    description: { type: Type.STRING, description: "A detailed description of what is happening in the event." },
                                },
                                required: ['timestamp', 'description'],
                            },
                        },
                        inferred_dialogue: { type: Type.STRING, description: "An inferred transcription of what might be said, based on visual cues." },
                        transcription: { type: Type.STRING, description: "A transcription of the spoken content from the audio track. If no audio was provided, state that." },
                    },
                    required: ['summary', 'events', 'inferred_dialogue', 'transcription'],
                },
            }
        };

        console.log(`[DEEP-DEBUG] Getting model with config:`, JSON.stringify(modelConfig.model));
        const model = genAI.getGenerativeModel(modelConfig);

        console.log(`[DEEP-DEBUG] Calling generateContent with fileUri: ${fileUri.substring(0, 80)}...`);
        const result = await model.generateContent([
            { fileData: { fileUri: fileUri, mimeType: mimeType } },
            { text: prompt }
        ]);

        console.log(`[DEEP-DEBUG] generateContent returned successfully`);
        const rawText = result.response.text() || '';
        console.log(`[DEEP-DEBUG] Response text length: ${rawText.length}`);
        return safeJsonParse<AnalysisResult>(rawText);

    } catch (error: any) {
        console.error(`[DEEP-DEBUG] ✗✗✗ analyzeVideoContent FAILED ✗✗✗`);
        console.error(`[DEEP-DEBUG] Error name: ${error.name}`);
        console.error(`[DEEP-DEBUG] Error message: ${error.message}`);
        console.error(`[DEEP-DEBUG] Error code: ${error.code}`);
        console.error(`[DEEP-DEBUG] Error status: ${error.status}`);
        console.error(`[DEEP-DEBUG] Error details:`, JSON.stringify(error.errorDetails || error.details || 'none'));
        console.error(`[DEEP-DEBUG] Full error:`, error);
        throw new Error(error.message || "ANALYSIS_FAIL");
    }
};

export const generateSynopsisFromAnalysis = async (
    analysis: AnalysisResult,
    writer: string,
    director: string,
    language: string,
    keywords: string,
    synopsisConfig: SynopsisConfig
): Promise<Synopsis> => {

    try {
        const prompt = `
          You are a master screenwriter and film marketing expert. Your task is to transform raw video analysis data into a compelling, professional film synopsis and marketing profile. Your writing should be evocative and ready for a pitch deck.

          **Your Constraints:**
          - **Language:** Generate all content in: ${language}.
          - **Title:** Maximum ${synopsisConfig.titleMaxChars} characters.
          - **One Line (Logline):** Approximately ${synopsisConfig.loglineMaxWords} words.
          - **Paragraph (Summary):** Approximately ${synopsisConfig.summaryMaxWords} words.
          - **Key Themes:** Approximately ${synopsisConfig.keyThemesMaxWords} words.
          - **Target Audience:** Approximately ${synopsisConfig.targetAudienceMaxWords} words.
          
          **Video Analysis Data:**
          - Transcription: "${analysis.transcription}"
          - Summary: "${analysis.summary}"
          - Key Events: ${JSON.stringify(analysis.events.map(e => e.description))}
          - Inferred Dialogue: "${analysis.inferred_dialogue}"

          Your output must be a single JSON object with keys: "title", "oneLine", "paragraph", "fullSynopsis", "keyThemes", "targetAudience".
      `;

        const model = genAI.getGenerativeModel({
            model: 'gemini-2.0-flash',
            generationConfig: {
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        title: { type: Type.STRING },
                        oneLine: { type: Type.STRING },
                        paragraph: { type: Type.STRING },
                        fullSynopsis: { type: Type.STRING },
                        keyThemes: { type: Type.STRING },
                        targetAudience: { type: Type.STRING }
                    },
                    required: ['title', 'oneLine', 'paragraph', 'fullSynopsis', 'keyThemes', 'targetAudience']
                }
            }
        });

        const result = await model.generateContent(prompt);
        const aiGeneratedContent = safeJsonParse<any>(result.response.text() || '');

        return {
            ...aiGeneratedContent,
            writtenBy: writer,
            directedBy: director,
        };

    } catch (error: any) {
        console.error("Error generating synopsis with Gemini:", error);
        throw new Error("SYNOPSIS_FAIL");
    }
};

// ═══════════════════════════════════════════════════════════════════════════════
// GRAPHICS
// ═══════════════════════════════════════════════════════════════════════════════

export async function analyzeGraphicsAndLowerThirds(
    fileUri: string, mimeType: string, duration: number, filmTitle: string
): Promise<GraphicsAnalysisResult> {
    console.log(`[DEEP-DEBUG] analyzeGraphicsAndLowerThirds (GRAPHICS) called`);
    console.log(`[DEEP-DEBUG] fileUri: ${fileUri?.substring(0, 80)}...`);
    console.log(`[DEEP-DEBUG] mimeType: ${mimeType}, duration: ${duration}`);

    const prompt = `You are a post-production assistant with excellent OCR skills. Analyze the provided video file. Your task is to identify and transcribe all on-screen graphics (e.g., title cards, location indicators) and lower thirds. Output strictly JSON.`;

    try {
        console.log(`[DEEP-DEBUG] Creating gemini-2.0-flash model for graphics analysis`);
        const model = genAI.getGenerativeModel({
            model: 'gemini-2.0-flash', // Updated to 2.0 Flash
            generationConfig: {
                responseMimeType: 'application/json',
                temperature: 0.2,
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        programTitle: { type: Type.STRING },
                        runtime: { type: Type.STRING },
                        graphics: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT, properties: {
                                    description: { type: Type.STRING },
                                    timecodeIn: { type: Type.STRING },
                                    timecodeOut: { type: Type.STRING },
                                    cleanTimecodeIn: { type: Type.STRING },
                                    cleanTimecodeOut: { type: Type.STRING },
                                },
                                required: ["description", "timecodeIn", "timecodeOut"],
                            },
                        },
                        lowerThirds: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT, properties: {
                                    text: { type: Type.STRING },
                                    timecodeIn: { type: Type.STRING },
                                    timecodeOut: { type: Type.STRING }
                                },
                                required: ["text", "timecodeIn", "timecodeOut"],
                            },
                        },
                    },
                    required: ["programTitle", "runtime", "graphics", "lowerThirds"],
                },
            }
        });

        console.log(`[DEEP-DEBUG] Calling generateContent for graphics...`);
        const result = await model.generateContent([
            { fileData: { fileUri: fileUri, mimeType: mimeType } },
            { text: prompt }
        ]);

        console.log(`[DEEP-DEBUG] Graphics generateContent returned successfully`);
        const parsedResult = safeJsonParse<GraphicsAnalysisResult>(result.response.text() || '');
        console.log(`[DEEP-DEBUG] Graphics found ${parsedResult.graphics?.length || 0} graphics, ${parsedResult.lowerThirds?.length || 0} lower thirds`);
        parsedResult.programTitle = filmTitle;
        parsedResult.runtime = formatDuration(duration);
        return parsedResult;
    } catch (e: any) {
        console.error(`[DEEP-DEBUG] ✗✗✗ analyzeGraphicsAndLowerThirds (GRAPHICS) FAILED ✗✗✗`);
        console.error(`[DEEP-DEBUG] Error name: ${e.name}`);
        console.error(`[DEEP-DEBUG] Error message: ${e.message}`);
        console.error(`[DEEP-DEBUG] Error code: ${e.code}`);
        console.error(`[DEEP-DEBUG] Full error:`, e);
        throw new Error("Graphics analysis failed: " + e.message);
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// FAUNA FINDER
// ═══════════════════════════════════════════════════════════════════════════════

export async function analyzeVideoForSpecies(
    fileUri: string,
    mimeType: string,
    primaryLanguage: string,
    secondaryLanguage: string,
    videoDuration: number = 0
): Promise<Omit<SpeciesSighting, 'id' | 'thumbnail'>[]> {
    console.log(`[DEEP-DEBUG] analyzeVideoForSpecies (FAUNA) called`);
    console.log(`[DEEP-DEBUG] fileUri: ${fileUri?.substring(0, 80)}...`);
    console.log(`[DEEP-DEBUG] mimeType: ${mimeType}, duration: ${videoDuration}`);

    const prompt = `Analyze this video. Your task is to identify **every single animal sighting**. 
    Provide: 
    - 'commonName': The common name in ${primaryLanguage}.
    - 'latinName': The scientific name.
    - 'germanName': The common name in ${secondaryLanguage}.
    - 'timecode': The EXACT timecode.
    - 'category': (e.g., "Mammal", "Bird").
    - 'confidence': 0.0 to 1.0.
    - 'behavior': Brief description.
    - 'iucnStatus': IUCN status if known.
    - 'encounterGroup': Group ID if same individual seen multiple times.
    
    The final output must be a valid JSON object with a single key "sightings".`;

    try {
        console.log(`[DEEP-DEBUG] Creating gemini-2.0-flash model for fauna analysis`);
        const model = genAI.getGenerativeModel({
            model: 'gemini-2.0-flash',
            generationConfig: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        sightings: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    commonName: { type: Type.STRING },
                                    latinName: { type: Type.STRING },
                                    germanName: { type: Type.STRING },
                                    timecode: { type: Type.STRING },
                                    category: { type: Type.STRING },
                                    confidence: { type: Type.NUMBER },
                                    behavior: { type: Type.STRING },
                                    iucnStatus: { type: Type.STRING },
                                    encounterGroup: { type: Type.STRING },
                                },
                                required: ["commonName", "latinName", "timecode", "category", "confidence"],
                            },
                        },
                    },
                    required: ["sightings"],
                },
            },
        });

        console.log(`[DEEP-DEBUG] Calling generateContent for fauna...`);
        const result = await model.generateContent([
            { fileData: { fileUri: fileUri, mimeType: mimeType } },
            { text: prompt }
        ]);

        console.log(`[DEEP-DEBUG] Fauna generateContent returned successfully`);
        const parsed = safeJsonParse<any>(result.response.text() || '');
        console.log(`[DEEP-DEBUG] Fauna found ${parsed.sightings?.length || 0} sightings`);
        return parsed.sightings || [];

    } catch (e: any) {
        console.error(`[DEEP-DEBUG] ✗✗✗ analyzeVideoForSpecies (FAUNA) FAILED ✗✗✗`);
        console.error(`[DEEP-DEBUG] Error name: ${e.name}`);
        console.error(`[DEEP-DEBUG] Error message: ${e.message}`);
        console.error(`[DEEP-DEBUG] Error code: ${e.code}`);
        console.error(`[DEEP-DEBUG] Full error:`, e);
        throw new Error("Fauna analysis failed: " + e.message);
    }
}

export async function transcribeMedia(
    fileUri: string, mimeType: string, videoDuration: number = 0
): Promise<Omit<TranscriptionResult, 'speakerMap'>> {
    console.log(`[DEEP-DEBUG] transcribeMedia called`);
    console.log(`[DEEP-DEBUG] fileUri: ${fileUri?.substring(0, 80)}...`);
    console.log(`[DEEP-DEBUG] mimeType: ${mimeType}, duration: ${videoDuration}`);

    // For short videos (< 10 min), use single-pass
    if (videoDuration < 600 || videoDuration === 0) {
        console.log(`[DEEP-DEBUG] Using single-pass transcription (short video)`);
        return transcribeMediaSinglePass(fileUri, mimeType);
    }

    // For long videos, use segmented processing (5-minute segments)
    const SEGMENT_DURATION = 300; // 5 minutes
    const segments: { start: number; end: number }[] = [];
    for (let start = 0; start < videoDuration; start += SEGMENT_DURATION) {
        segments.push({ start, end: Math.min(start + SEGMENT_DURATION, videoDuration) });
    }

    const allSegments: any[] = [];
    // SEQUENTIAL PROCESSING: Avoid 429 rate limits on long videos
    // Changed from BATCH_SIZE=3/50ms to BATCH_SIZE=1/2000ms for rate limit safety
    const BATCH_SIZE = 1;  // Process one segment at a time
    const DELAY_BETWEEN_SEGMENTS_MS = 2000;  // 2 seconds between segments

    console.log(`[Transcribe] Processing ${segments.length} segments SEQUENTIALLY with ${DELAY_BETWEEN_SEGMENTS_MS}ms delays...`);

    for (let i = 0; i < segments.length; i += BATCH_SIZE) {
        const batch = segments.slice(i, i + BATCH_SIZE);
        const batchResults = await Promise.all(
            batch.map(seg => transcribeSegment(fileUri, mimeType, seg.start, seg.end))
        );

        batchResults.forEach(result => {
            if (result?.segments) {
                // Map 'text' to 'transcript' for consistency
                const mapped = result.segments.map((seg: any) => ({
                    startTime: seg.startTime,
                    endTime: seg.endTime,
                    speaker: seg.speaker,
                    transcript: seg.text || seg.transcript || ''
                }));
                allSegments.push(...mapped);
            }
        });

        // Rate limit protection: wait between segments
        if (i < segments.length - 1) {
            console.log(`[Transcribe] Segment ${i + 1}/${segments.length} done, waiting ${DELAY_BETWEEN_SEGMENTS_MS}ms...`);
            await new Promise(r => setTimeout(r, DELAY_BETWEEN_SEGMENTS_MS));
        }
    }

    return { segments: allSegments };
}

async function transcribeMediaSinglePass(
    fileUri: string, mimeType: string
): Promise<Omit<TranscriptionResult, 'speakerMap'>> {
    console.log(`[DEEP-DEBUG] transcribeMediaSinglePass called with fileUri: ${fileUri?.substring(0, 60)}...`);
    const prompt = `You are an expert audio transcription AI. Transcribe the provided media, identifying different speakers as SPEAKER_00, SPEAKER_01, etc. Provide the output as a time-coded transcript in a JSON object adhering to the schema.`;

    try {
        console.log(`[DEEP-DEBUG] Creating gemini-2.0-flash model for transcription`);
        const model = genAI.getGenerativeModel({
            model: 'gemini-2.0-flash',
            generationConfig: {
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        segments: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    startTime: { type: Type.STRING },
                                    endTime: { type: Type.STRING },
                                    speaker: { type: Type.STRING },
                                    text: { type: Type.STRING },
                                },
                                required: ["startTime", "endTime", "speaker", "text"],
                            },
                        },
                    },
                    required: ["segments"],
                },
            }
        });

        const result = await model.generateContent([
            { fileData: { fileUri: fileUri, mimeType: mimeType } },
            { text: prompt }
        ]);

        const parsed = safeJsonParse<any>(result.response.text() || '');

        // DEBUG: Log raw response to diagnose speaker/transcript field issues
        if (parsed.segments && parsed.segments.length > 0) {
            console.log(`[TRANSCRIPTION-DEBUG] First segment raw:`, JSON.stringify(parsed.segments[0]));
        }

        // Map 'text' field from Gemini schema to 'transcript' expected by frontend
        // Also validate speaker field to catch cases where Gemini puts transcript in speaker
        const mappedSegments = (parsed.segments || []).map((seg: any, idx: number) => {
            let speaker = seg.speaker || 'SPEAKER_00';
            let transcript = seg.text || seg.transcript || '';

            // FIX: If speaker looks like transcript (contains spaces or is too long), swap them
            if (speaker && (speaker.length > 20 || (speaker.includes(' ') && !speaker.startsWith('SPEAKER')))) {
                console.log(`[TRANSCRIPTION-DEBUG] Segment ${idx} has transcript in speaker field, swapping`);
                transcript = speaker;
                speaker = `SPEAKER_${String(idx % 10).padStart(2, '0')}`;
            }

            return {
                startTime: seg.startTime,
                endTime: seg.endTime,
                speaker: speaker,
                transcript: transcript
            };
        });

        return { segments: mappedSegments };

    } catch (error: any) {
        console.error(`[DEEP-DEBUG] ✗✗✗ transcribeMediaSinglePass FAILED ✗✗✗`);
        console.error(`[DEEP-DEBUG] Error name: ${error.name}`);
        console.error(`[DEEP-DEBUG] Error message: ${error.message}`);
        console.error(`[DEEP-DEBUG] Error code: ${error.code}`);
        console.error(`[DEEP-DEBUG] Full error:`, error);
        throw new Error("Transcription Failed: " + error.message);
    }
}

async function transcribeSegment(
    fileUri: string, mimeType: string, startSec: number, endSec: number
): Promise<{ segments: any[] }> {
    const fmtTime = (s: number) => {
        const m = Math.floor(s / 60);
        const sec = Math.floor(s % 60);
        return `${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
    };

    const prompt = `You are an expert audio transcription AI. 
    **CRITICAL:** Analyze ONLY the segment from ${fmtTime(startSec)} to ${fmtTime(endSec)}. Ignore anything outside this range.
    Transcribe the audio, identifying different speakers as SPEAKER_00, SPEAKER_01, etc.
    Output timecodes should be ABSOLUTE (relative to video start, e.g., if startSec is 300, timecodes start around 05:00).
    Output valid JSON.`;

    try {
        const model = genAI.getGenerativeModel({
            model: 'gemini-2.0-flash',
            generationConfig: {
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        segments: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    startTime: { type: Type.STRING },
                                    endTime: { type: Type.STRING },
                                    speaker: { type: Type.STRING },
                                    text: { type: Type.STRING },
                                },
                                required: ["startTime", "endTime", "speaker", "text"],
                            },
                        },
                    },
                    required: ["segments"],
                },
            }
        });

        const result = await model.generateContent([
            { fileData: { fileUri, mimeType } },
            { text: prompt }
        ]);

        return safeJsonParse<{ segments: any[] }>(result.response.text() || '');
    } catch (e) {
        console.warn(`Segment transcription failed for ${startSec}-${endSec}:`, e);
        return { segments: [] };
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// SHOT LIST ENRICHMENT (Add descriptions to Video Intelligence boundaries)
// ═══════════════════════════════════════════════════════════════════════════════

interface ShotBoundary {
    tcIn: string;
    tcOut: string;
    duration: string;
    description?: string;
    action?: string;
    audio?: string;
}

export async function enrichShotList(
    fileUri: string,
    mimeType: string,
    shots: ShotBoundary[],
    language: string = 'English'
): Promise<ShotBoundary[]> {
    console.log(`[ShotEnrich] Enriching ${shots.length} shots with Gemini descriptions...`);

    if (!shots || shots.length === 0) {
        return shots;
    }

    const shotListContext = JSON.stringify(shots.map((s, i) => ({
        id: i,
        start: s.tcIn,
        end: s.tcOut
    })));

    const prompt = `
    You are an expert film editor assistant. I have a list of ${shots.length} shots with exact timecodes.
    Your task is to watch the video and provide a brief but descriptive "Visual Description" and "Main Action" for EACH shot.
    - Be precise and specific about what you see.
    - Use professional film terminology.
    - Output MUST be a valid JSON array of objects, where each object corresponds to the input shot ID.
    - Language: ${language}

    Input Shot List:
    ${shotListContext}

    Output Schema:
    Array<{ id: number, description: string, action: string, audio: string }>
    `;

    try {
        const model = genAI.getGenerativeModel({
            model: 'gemini-2.0-flash',
            generationConfig: {
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            id: { type: Type.NUMBER },
                            description: { type: Type.STRING },
                            action: { type: Type.STRING },
                            audio: { type: Type.STRING }
                        },
                        required: ['id', 'description', 'action', 'audio']
                    }
                }
            }
        });

        const result = await model.generateContent([
            { fileData: { fileUri, mimeType } },
            { text: prompt }
        ]);

        const enrichments = safeJsonParse<{ id: number; description: string; action: string; audio: string }[]>(
            result.response.text() || '[]'
        );

        // DEBUG: Log enrichment IDs to diagnose mismatch
        if (enrichments && enrichments.length > 0) {
            console.log(`[ShotEnrich] Enrichments received: ${enrichments.length} items`);
            console.log(`[ShotEnrich] First enrichment id: ${enrichments[0]?.id}, Last enrichment id: ${enrichments[enrichments.length - 1]?.id}`);
        }

        // Ensure enrichments is an array before sorting
        const enrichmentsArray = Array.isArray(enrichments) ? enrichments : [];
        if (!Array.isArray(enrichments)) {
            console.warn(`[ShotEnrich] Enrichments was not an array, got: ${typeof enrichments}`);
        }

        // Sort enrichments by ID to ensure correct order
        const sortedEnrichments = enrichmentsArray.sort((a, b) => (a.id || 0) - (b.id || 0));

        // Merge enrichments by POSITION (not by ID matching) since Gemini may use 0-indexed or 1-indexed
        // This is more reliable: enrichment[0] matches shot[0], enrichment[1] matches shot[1], etc.
        const enrichedShots = shots.map((shot, index) => {
            // Use position-based matching: enrichment at same index matches shot at same index
            const enrichment = sortedEnrichments[index];

            return {
                ...shot,
                description: enrichment?.description || shot.description || `Shot ${index + 1}`,
                action: enrichment?.action || shot.action || '',
                audio: enrichment?.audio || shot.audio || ''
            };
        });

        console.log(`[ShotEnrich] ✓ Successfully enriched ${enrichedShots.length} shots`);
        return enrichedShots;

    } catch (error: any) {
        console.error(`[ShotEnrich] ✗ Enrichment failed:`, error.message);
        // Return original shots with placeholders if enrichment fails
        return shots;
    }
}
